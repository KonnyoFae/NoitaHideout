-- All travel consumers in one Lua VM share this context. Damage scripts in
-- other VMs resolve their own context directly from the game.
if NHTravelWorld then return NHTravelWorld end
local W={}
local scope
local scenesDefault="data/biome/_pixel_scenes.xml"
local function path(value)
    if type(value)=="string" and value:find("/",1,true) then return value end
end

-- Session numbers change on KeepPlayer map loads, including loads which leave NG+ unchanged.
-- Same-map east/west worlds deliberately share the original route table.
local function readWorld()
    local ng=tonumber(SessionNumbersGetValue and SessionNumbersGetValue("NEW_GAME_PLUS_COUNT")) or 0
    local base=ng==0 and "nh_travel." or ("nh_travel.ng"..ng..".")
    local map=path(SessionNumbersGetValue and SessionNumbersGetValue("BIOME_MAP"))
    if not map and not MagicNumbersGetValue then return base,false end
    local origin=GlobalsGetValue(base.."origin_map","")
    local configured
    if not map or (ng==0 and origin=="") then
        configured=path(MagicNumbersGetValue and MagicNumbersGetValue("BIOME_MAP"))
    end
    if ng>0 and not map then return base,false end
    map=map or configured
    if not map then return base,false end
    local scenes=path(SessionNumbersGetValue and SessionNumbersGetValue("BIOME_MAP_PIXEL_SCENES")) or scenesDefault
    -- An older NG+ save can first run this version inside an Apotheosis portal
    -- map. Leave the home slot unbound until its actual NG+ map is loaded.
    local portalMap=origin=="" and ng>0 and map:match("^mods/Apotheosis/files/entities/buildings/ending/portals/enter_plane_[^/]+_biome_map%.lua$")
    if origin=="" and not portalMap then
        -- Old saves can first load this release inside a plane. At NG zero the modded
        -- startup map is available from the configured magic numbers.
        origin=(ng==0 and configured) or map
        local originScenes=origin==map and scenes or scenesDefault
        GlobalsSetValue(base.."origin_scenes",originScenes)
        GlobalsSetValue(base.."origin_map",origin)
    end
    if map==origin and scenes==GlobalsGetValue(base.."origin_scenes",scenesDefault) then return base,false end
    return base.."plane."..#map.."."..map.."."..#scenes.."."..scenes..".",true
end

-- Pre- and post-update are distinct: other mods and the engine can move the
-- player or replace the map between them, even at the same frame number.
function W.duringUpdate(update)
    local scratch={}
    return function()
        local outer=scope
        scope=outer and {} or scratch
        scope.prefix,scope.player=nil,nil
        local ok,err=pcall(update)
        scope=outer
        if outer then outer.prefix,outer.player=nil,nil end
        if not ok then error(err,0) end
    end
end

function W.current(fresh)
    if not scope then return readWorld() end
    if fresh or not scope.prefix then
        local prefix,plane=readWorld()
        if scope.prefix~=prefix then scope.player=nil end
        scope.prefix,scope.plane=prefix,plane
    end
    return scope.prefix,scope.plane
end

function W.invalidateAccess()
    if scope then scope.player=nil end
end

-- Keep the actual transform in the key: travel can move the player inside
-- a single callback. An out-of-band query always reads a fresh location.
function W.access(player,hx,hy,resolve)
    local x,y=EntityGetTransform(player)
    if not scope then return resolve(player,x,y,hx,hy) end
    if player~=scope.player or x~=scope.x or y~=scope.y or hx~=scope.hx or hy~=scope.hy then
        scope.near,scope.station,scope.landmark,scope.remote=resolve(player,x,y,hx,hy)
        scope.player,scope.x,scope.y,scope.hx,scope.hy=player,x,y,hx,hy
    end
    return scope.near,scope.station,scope.landmark,scope.remote
end

function W.position(prefix,key)
    local x,y=GlobalsGetValue(prefix..key,""):match("^(-?%d+),(-?%d+)$")
    return tonumber(x),tonumber(y)
end

NHTravelWorld=W
return W
