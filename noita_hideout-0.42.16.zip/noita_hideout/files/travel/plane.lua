local W=dofile("mods/noita_hideout/files/travel/world.lua")
local cabin=dofile("mods/noita_hideout/files/travel/cabin.lua")
local P={}

-- Check the head, shoulders and feet on both sides of a standing player.
function P.landing(x,y)
    for _,dx in ipairs({0,10,-10,20,-20,32,-32}) do
        local sx=x+dx
        local hit,_,floor=RaytracePlatforms(sx,y-8,sx,y+48)
        if hit and floor then
            local clear=true
            for side=-4,4,2 do
                if RaytraceSurfacesAndLiquiform(sx+side,floor-20,sx+side,floor-1)
                    or not RaytracePlatforms(sx+side,floor-1,sx+side,floor+4) then clear=false; break end
            end
            if clear then return sx,floor-6 end
        end
    end
end

local function empty(left,top,width,height)
    local right,bottom=left+width-1,top+height-1
    if not DoesWorldExistAt(left,top,right,bottom) then return false end
    local cx,cy=(left+right)/2,(top+bottom)/2
    local radius=math.sqrt((right-cx)^2+(bottom-cy)^2)+64
    for _,id in ipairs(EntityGetInRadius(cx,cy,radius) or {}) do
        local x,y=EntityGetTransform(id)
        if x>=left and x<=right and y>=top and y<=bottom then return false end
        local box=EntityGetFirstComponentIncludingDisabled(id,"HitboxComponent")
        if box and x+ComponentGetValue2(box,"aabb_max_x")>=left and x+ComponentGetValue2(box,"aabb_min_x")<=right
            and y+ComponentGetValue2(box,"aabb_max_y")>=top and y+ComponentGetValue2(box,"aabb_min_y")<=bottom then return false end
    end
    -- A sparse grid of rays misses thin wires and lone pixels. Scan every row,
    -- including clearance outside the mask, immediately before placing it.
    for y=top,bottom do
        if RaytraceSurfacesAndLiquiform(left,y,right,y) then return false end
    end
    return true
end

function P.findDock(x,y)
    for _,rise in ipairs({48,144,240}) do
        for _,side in ipairs({0,-144,144}) do
            local left=math.floor(x+side-cabin.width/2)
            local top=math.floor(y-rise-cabin.height)
            if empty(left-12,top-12,cabin.width+24,cabin.height+24) then return left,top end
        end
    end
end

local function safeLanding(x,y)
    if x and DoesWorldExistAt(x-40,y-25,x+40,y+54) then return P.landing(x,y) end
end

function P.clearAvatar(x,y)
    if not DoesWorldExistAt(x-5,y-15,x+5,y+6) then return false end
    for dx=-4,4 do
        if RaytraceSurfacesAndLiquiform(x+dx,y-14,x+dx,y+5) then return false end
    end
    return true
end

function P.safePoint(player,prefix)
    local sx,sy=safeLanding(EntityGetTransform(player))
    if sx then return sx,sy end
    return safeLanding(W.position(prefix,"safe"))
end

-- Called from both the controller and the separate damage-callback Lua state.
function P.canRescue(player,reserve)
    local prefix,plane=W.current(reserve)
    if not plane then return true end
    local x,y=P.safePoint(player,prefix)
    if not x and GlobalsGetValue(prefix.."built","")==cabin.revision then
        x,y=W.position(prefix,"boarding")
        if not x then x,y=W.position(prefix,"summon_from") end
    end
    if not x then return false end
    if reserve then GlobalsSetValue(prefix.."rescue_from",("%d,%d"):format(x,y)) end
    return true
end
return P

