local M={radius=2048,ship={width=160,height=172,anchorX=20,groundY=168,boardingRight=49,hullBottom=85,empty=3,retiring=4}}
local prefix="cycle_storm.sites."
local keys={rig="rig_locations",well="well_locations",ship="ship_locations"}
local scanKey=prefix.."scan_until"

-- Oil and gas records store their expiry (-1 for idle rigs). Ship records
-- retain their ground anchor until the hull and its fixtures have been removed.
function M.each(kind,visit)
    for x,y,value in GlobalsGetValue(prefix..keys[kind],""):gmatch("(-?%d+),(-?%d+),(-?%d+)") do
        visit(tonumber(x),tonumber(y),tonumber(value))
    end
end

function M.shipState(x,y)
    local result
    M.each("ship",function(sx,sy,state)
        if sx==x and sy==y then result=state end
    end)
    return result
end

function M.setShip(x,y,newState)
    local entries,found={},false
    M.each("ship",function(sx,sy,state)
        if sx==x and sy==y then found=true; state=newState end
        if state~=nil then entries[#entries+1]=string.format("%d,%d,%d",sx,sy,state) end
    end)
    if not found and newState~=nil then entries[#entries+1]=string.format("%d,%d,%d",x,y,newState) end
    GlobalsSetValue(prefix..keys.ship,table.concat(entries,";"))
end

function M.shipOverlaps(left,top,right,bottom)
    local overlap=false
    M.each("ship",function(x,y)
        local sx,sy=x-M.ship.anchorX,y-M.ship.groundY
        if left<sx+M.ship.width and right>sx and top<sy+M.ship.height and bottom>sy then overlap=true end
    end)
    return overlap
end

-- The hull spans the full width. Below it only the port-side steps and anchor
-- contain material. Keep the player clear of both when removing a ship.
function M.nearShipStructure(x,y,px,py)
    local ship=M.ship
    local lx,ly=px-x+ship.anchorX,py-y+ship.groundY
    local margin=32
    if lx < -margin or ly < -margin then return false end
    return (lx<=ship.width+margin and ly<=ship.hullBottom+margin)
        or (lx<=ship.boardingRight+margin and ly<=ship.height+margin)
end

function M.nearby(px,py,frame)
    local matches={}
    for _,kind in ipairs({"ship","well","rig"}) do
        local nearest
        local count=0
        M.each(kind,function(x,y,value)
            local usable
            if kind=="ship" then
                usable=value<M.ship.empty
            else
                usable=value<0 or value>frame
            end
            local d=(x-px)^2+(y-py)^2
            if usable and d<=M.radius^2 then
                count=count+1
                if not nearest or d<nearest.d then nearest={kind=kind,x=x,y=y,d=d} end
            end
        end)
        if nearest then
            nearest.count=count
            matches[#matches+1]=nearest
        end
    end
    return matches
end

function M.active(frame)
    return (tonumber(GlobalsGetValue(scanKey,"0")) or 0)>frame
end

function M.scan(player,pay,report)
    local frame=GameGetFrameNum()
    if M.active(frame) then report("Radar already active."); return end
    local x,y=EntityGetTransform(player)
    if #M.nearby(x,y,frame)==0 then
        GamePrint(GameTextGetTranslatedOrNot("$nh_storm_scan_empty"))
    elseif pay() then
        GlobalsSetValue(scanKey,tostring(frame+600))
    end
end

return M
