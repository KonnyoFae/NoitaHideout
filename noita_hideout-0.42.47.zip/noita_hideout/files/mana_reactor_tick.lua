local frame=GameGetFrameNum()
-- On load the instance VM starts fresh. Thereafter do equipment work every
-- six frames, with one earlier wakeup if the absolute deadline falls between.
if not nh_reactor_next or frame>=nh_reactor_next then
    nh_reactor_next=dofile_once("mods/noita_hideout/files/mana_reactor.lua").update(GetUpdatedEntityID(),frame)
end
