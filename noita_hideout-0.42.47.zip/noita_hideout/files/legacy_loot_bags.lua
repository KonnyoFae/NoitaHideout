-- Streamed bags keep the components saved by the old template. Upgrade the
-- original entity so its stack count, ownership and other mods' data survive.
local physics = {"PhysicsThrowableComponent", "PhysicsKeepInWorldComponent",
    "PhysicsImageShapeComponent", "PhysicsBodyComponent", "VelocityComponent"}
local kinds = {}
for _, kind in ipairs({"travel_satchel", "travel_pack", "loot_case"}) do
    kinds["$nh_hideout_" .. kind] = kind
end

local function migrate(entity)
    if not EntityHasTag(entity, "item_physics") or EntityGetRootEntity(entity) ~= entity then return end
    local item = EntityGetFirstComponent(entity, "ItemComponent")
    local kind = item and kinds[ComponentGetValue2(item, "item_name")]
    if not kind or not EntityHasTag(entity, "noita_hideout_" .. kind) or not ComponentGetValue2(item, "is_pickable") then return end
    local icon = "mods/noita_hideout/files/items/" .. kind .. ".png"
    local sprite = EntityGetFirstComponentIncludingDisabled(entity, "SpriteComponent", "enabled_in_hand")
    if not sprite or ComponentGetValue2(sprite, "image_file") ~= icon
        or EntityGetFirstComponentIncludingDisabled(entity, "PhysicsBody2Component")
        or EntityGetFirstComponentIncludingDisabled(entity, "PhysicsShapeComponent")
        or EntityGetFirstComponentIncludingDisabled(entity, "PhysicsJointComponent")
        or EntityGetFirstComponentIncludingDisabled(entity, "PhysicsJoint2Component") then return end

    local old = {}
    for _, kind in ipairs(physics) do
        local found = EntityGetComponentIncludingDisabled(entity, kind)
        if not found or #found ~= 1 then return end
        old[kind] = found[1]
    end
    local body, shape = old.PhysicsBodyComponent, old.PhysicsImageShapeComponent
    if ComponentGetValue2(shape, "image_file") ~= icon or ComponentGetValue2(shape, "body_id") ~= 1
        or ComponentGetValue2(body, "uid") ~= 1 then return end

    ComponentAddTag(sprite, "enabled_in_world")
    ComponentSetValue2(sprite, "z_index", -1.5)
    EntitySetComponentIsEnabled(entity, sprite, true)
    ComponentSetValue2(body, "kills_entity", false)
    ComponentSetValue2(body, "on_death_leave_physics_body", false)
    ComponentSetValue2(body, "is_enabled", false)
    for _, kind in ipairs(physics) do EntitySetComponentIsEnabled(entity, old[kind], false) end
    for _, kind in ipairs(physics) do EntityRemoveComponent(entity, old[kind]) end
    EntityRemoveTag(entity, "item_physics")
    return true
end

return function()
    local converted = 0
    for _, entity in ipairs(EntityGetWithTag("nh_loot_bag") or {}) do
        if migrate(entity) then
            converted = converted + 1
            if converted == 8 then break end
        end
    end
end
