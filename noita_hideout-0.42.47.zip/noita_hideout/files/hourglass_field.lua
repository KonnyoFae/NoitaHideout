local files="mods/noita_hideout/files/"
local targets=dofile_once(files.."field_targets.lua")
local M={duration=1800}
local fieldTag,still="nh_hourglass_field","nh_hourglass_still"
local paused,clock="nh_hourglass_paused","nh_hourglass_clock"
local slotTag="nh_hourglass_slot_"

-- Keep hitboxes, inventories, damage/death callbacks and the original entity.
-- Velocity stays in its component while its integrator is suspended.
local suspended={
    AIComponent=true, AIAttackComponent=true, AbilityComponent=true, AnimalAIComponent=true,
    AdvancedFishAIComponent=true, ArcComponent=true, AreaDamageComponent=true, BlackHoleComponent=true,
    BossDragonComponent=true, CardinalMovementComponent=true, CellEaterComponent=true,
    CharacterDataComponent=true, CharacterPlatformingComponent=true, ControllerGoombaAIComponent=true,
    CrawlerAnimalComponent=true, DamageNearbyEntitiesComponent=true, DieIfSpeedBelowComponent=true,
    DroneLauncherComponent=true, ExplosionComponent=true, FishAIComponent=true, FlyingComponent=true,
    GhostComponent=true, HomingComponent=true, IKLimbAttackerComponent=true, IKLimbsAnimatorComponent=true,
    LaserEmitterComponent=true, LifetimeComponent=true, LightningComponent=true, LimbBossComponent=true,
    MagicConvertMaterialComponent=true, MaterialSeaSpawnerComponent=true, ParticleEmitterComponent=true,
    PathFindingComponent=true, PhysicsAIComponent=true, ProjectileComponent=true, RotateTowardsComponent=true,
    SimplePhysicsComponent=true, SineWaveComponent=true, SpriteAnimatorComponent=true,
    SpriteParticleEmitterComponent=true, TeleportComponent=true, TeleportProjectileComponent=true,
    VelocityComponent=true, WormAIComponent=true, WormComponent=true,
}

local function writableBody(entity)
    local body=EntityGetFirstComponent(entity,"PhysicsBodyComponent") or EntityGetFirstComponent(entity,"PhysicsBody2Component")
    if not body or ComponentGetValue2(body,"is_static") then return end
    local bodies=PhysicsBodyIDGetFromEntity(entity)
    if bodies and #bodies==1 then return bodies[1] end
end

local function capture(entity,deadline,now)
    local components=EntityGetAllComponents(entity) or {}
    local body=writableBody(entity)
    local vx,vy,spin
    if body then
        local bx,by,angle
        bx,by,angle,vx,vy,spin=PhysicsBodyIDGetTransform(body)
    end
    local record=EntityAddComponent2(entity,"VariableStorageComponent",{_tags=still,value_int=deadline})
    if not record or record==0 then return end
    local recovery=EntityAddComponent2(entity,"LuaComponent",{_tags=still,execute_every_n_frame=12,
        vm_type="SHARED_BY_MANY_COMPONENTS",
        script_source_file=files.."hourglass_resume.lua",script_item_picked_up=files.."hourglass_pickup.lua"})
    if not recovery or recovery==0 then EntityRemoveComponent(entity,record); return end
    EntityAddTag(entity,still)
    local timers={}
    -- Use stable component tags for the original timers: component IDs change
    -- across saves, and another mod can remove a timer during the field.
    for _,c in ipairs(components) do
        if ComponentGetIsEnabled(c) then
            local kind=ComponentGetTypeName(c)
            if kind=="LuaComponent" then
                local interval=ComponentGetValue2(c,"execute_every_n_frame")
                if interval>0 and (ComponentGetValue2(c,"script_source_file") or "")~="" then
                    timers[#timers+1]="S"..interval
                    ComponentAddTag(c,slotTag..#timers)
                    ComponentSetValue2(c,"execute_every_n_frame",-1)
                end
            elseif suspended[kind] then
                if kind=="LifetimeComponent" then
                    local finish=ComponentGetValue2(c,"kill_frame")
                    local remaining=finish>0 and math.max(1,finish-now) or ComponentGetValue2(c,"lifetime")
                    timers[#timers+1]="L"..remaining
                    ComponentAddTag(c,slotTag..#timers)
                end
                ComponentAddTag(c,paused)
                EntitySetComponentIsEnabled(entity,c,false)
            end
        end
    end
    ComponentSetValue2(record,"value_string",table.concat(timers,","))
    if vx then
        ComponentSetValue2(record,"name",table.concat({vx,vy,spin},","))
        PhysicsSetStatic(entity,true)
    end
end

function M.release(entity,pickingUp)
    local record=EntityGetFirstComponentIncludingDisabled(entity,"VariableStorageComponent",still)
    if not record then return end
    local carried=pickingUp or EntityGetRootEntity(entity)~=entity
    local slot=0
    for kind,value in ComponentGetValue2(record,"value_string"):gmatch("([SL])(%-?%d+)") do
        slot=slot+1
        local tag=slotTag..slot
        local c=EntityGetFirstComponentIncludingDisabled(entity,kind=="S" and "LuaComponent" or "LifetimeComponent",tag)
        if c then
            local n=tonumber(value)
            if kind=="S" then
                if ComponentGetValue2(c,"execute_every_n_frame")==-1 then ComponentSetValue2(c,"execute_every_n_frame",n) end
            elseif n>=0 then ComponentSetValue2(c,"kill_frame",GameGetFrameNum()+n) end
            ComponentRemoveTag(c,tag)
        end
    end
    for _,c in ipairs(EntityGetAllComponents(entity) or {}) do
        if ComponentHasTag(c,paused) then
            ComponentRemoveTag(c,paused)
            -- Pickup changes the enabled flags itself. Preserve its choice of
            -- world, hand and inventory components whichever callback ran first.
            if not carried or not (ComponentHasTag(c,"enabled_in_world") or ComponentHasTag(c,"enabled_in_hand")
                or ComponentHasTag(c,"enabled_in_inventory")) then EntitySetComponentIsEnabled(entity,c,true) end
        end
    end
    local vx,vy,spin=ComponentGetValue2(record,"name"):match("^([^,]+),([^,]+),([^,]+)$")
    if vx then
        PhysicsSetStatic(entity,false)
        local body=not carried and writableBody(entity)
        if body then
            local x,y,angle=PhysicsBodyIDGetTransform(body)
            if x then PhysicsBodyIDSetTransform(body,x,y,angle,tonumber(vx),tonumber(vy),tonumber(spin)) end
        end
    end
    local recovery=EntityGetFirstComponentIncludingDisabled(entity,"LuaComponent",still)
    EntityRemoveTag(entity,still)
    EntityRemoveComponent(entity,record)
    if recovery then EntityRemoveComponent(entity,recovery) end
end

local fields,checkedFrame={},-1
local function activeAt(entity,now)
    if checkedFrame~=now then
        fields,checkedFrame={},now
        for _,field in ipairs(EntityGetWithTag(fieldTag) or {}) do
            local c=EntityGetFirstComponentIncludingDisabled(field,"VariableStorageComponent",clock)
            if c and ComponentGetValue2(c,"value_int")>now then
                local x,y=EntityGetTransform(field)
                fields[#fields+1]={x,y,ComponentGetValue2(c,"value_float")^2}
            end
        end
    end
    local x,y=EntityGetTransform(entity)
    for _,area in ipairs(fields) do
        if (x-area[1])^2+(y-area[2])^2<=area[3] then return true end
    end
end

function M.checkTarget(entity)
    local record=EntityGetFirstComponentIncludingDisabled(entity,"VariableStorageComponent",still)
    if not record then return end
    local frame=GameGetFrameNum()
    if frame>=ComponentGetValue2(record,"value_int") or not targets.canAffect(entity,ModIsEnabled("quant.ew"))
        or not activeAt(entity,frame) then M.release(entity) end
end

function M.activate(player)
    if not player or player==0 or not EntityGetIsAlive(player) or not EntityHasTag(player,"player_unit")
        or not dofile_once(files.."ew.lua").localBody(player) then return false,"Item unavailable." end
    local now=GameGetFrameNum()
    local cast=EntityGetFirstComponentIncludingDisabled(player,"VariableStorageComponent","nh_hourglass_cast")
    if cast and ComponentGetValue2(cast,"value_int")>now then return false,"Field already active." end
    for _,field in ipairs(EntityGetWithTag(fieldTag) or {}) do
        local c=EntityGetFirstComponentIncludingDisabled(field,"VariableStorageComponent",clock)
        if c and ComponentGetValue2(c,"value_int")>now then return false,"Field already active." end
    end
    local x,y=EntityGetTransform(player)
    local field=EntityLoad(files.."hourglass_field.xml",x,y)
    if not field or field==0 then return false,"Item unavailable." end
    local c=EntityGetFirstComponentIncludingDisabled(field,"VariableStorageComponent",clock)
    if not c then EntityKill(field); return false,"Item unavailable." end
    -- The fixed field may stream out if its caster teleports. Keep its paid
    -- deadline on that player so another copy cannot start a second field.
    cast=cast or EntityAddComponent2(player,"VariableStorageComponent",{_tags="nh_hourglass_cast"})
    if not cast or cast==0 then EntityKill(field); return false,"Item unavailable." end
    local _,_,width=GameGetCameraBounds()
    local radius=math.max(1,(width or 420)*0.5)
    ComponentSetValue2(c,"value_int",now+M.duration)
    ComponentSetValue2(c,"value_float",radius)
    ComponentSetValue2(cast,"value_int",now+M.duration)
    M.tick(field,true)
    return true
end

function M.tick(field,fresh)
    local c=EntityGetFirstComponentIncludingDisabled(field,"VariableStorageComponent",clock)
    if not c then EntityKill(field); return end
    local finish=ComponentGetValue2(c,"value_int")
    local x,y=EntityGetTransform(field)
    local radius=ComponentGetValue2(c,"value_float")
    local frame=GameGetFrameNum()
    if frame>=finish then
        for _,entity in ipairs(EntityGetInRadiusWithTag(x,y,radius,still) or {}) do M.checkTarget(entity) end
        EntityKill(field)
        return
    end
    local broad=fresh or frame%8==0
    local nearby
    if broad then nearby=EntityGetInRadius(x,y,radius)
    else nearby=EntityGetInRadiusWithTag(x,y,radius,"projectile") end
    local ew=ModIsEnabled("quant.ew")
    for _,e in ipairs(nearby or {}) do
        if not EntityHasTag(e,still) and (not broad or EntityHasTag(e,"projectile") or EntityHasTag(e,"mortal")
            or EntityHasTag(e,"enemy") or EntityGetFirstComponent(e,"ProjectileComponent")
            or EntityGetFirstComponent(e,"ItemComponent") or EntityGetFirstComponent(e,"PhysicsThrowableComponent") or writableBody(e))
            and targets.canAffect(e,ew) then capture(e,finish,frame) end
    end
    for quadrant=0,3 do
        local a=(frame%12+quadrant*12)*math.pi/24
        GameCreateCosmeticParticle("spark_white",x+radius*math.cos(a),y+radius*math.sin(a),1,
            0,0,0,0.22,0.25,true,true,false,false,0,0)
    end
end

return M
