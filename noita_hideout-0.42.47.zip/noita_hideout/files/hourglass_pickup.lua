function item_pickup(item)
    dofile_once("mods/noita_hideout/files/hourglass_field.lua").release(item,true)
end
