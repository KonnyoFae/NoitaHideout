dofile_once("mods/noita_hideout/files/hourglass_field.lua").checkTarget(GetUpdatedEntityID())
