-- EW loads local_health before extra_modules. Give this audited version of
-- its normal restore path a separate entry for a Hideout drop pod.
local M={}
local source="mods/quant.ew/files/system/local_health/local_health.lua"
local version="mods/quant.ew/files/version.lua"

local function replace(text,original,replacement,count)
    local parts,start={},1
    for i=1,count do
        local at=text:find(original,start,true)
        if not at then return end
        parts[i]=text:sub(start,at-1)
        start=at+#original
    end
    if text:find(original,start,true) then return end
    parts[count+1]=text:sub(start)
    return table.concat(parts,replacement)
end

function M.install()
    if not ModDoesFileExist(version) or dofile_once(version)~="1.6.8" then return end
    local text=ModTextFileGetContent(source)
    if type(text)~="string" or text:find("nh_reinforce_restore",1,true) then return end
    text=text:gsub("\r\n","\n")
    -- The polymorph module and local_health's delayed retry both enter
    -- on_poly_death. Check at this common entry and before local_health
    -- samples HP (including the first frame after loading a downed save).
    local update="    local hp, max_hp = util.get_ent_health(player_ent)"
    text=replace(text,update,[=[    local hp, max_hp = util.get_ent_health(player_ent)
    if notplayer_active and hp <= 0 and ctx.cap.health.nh_reinforce_hold
        and ctx.cap.health.nh_reinforce_hold() then
        hp, max_hp = util.get_ent_health(player_ent)
    end]=],1)
    local head="    on_poly_death = function()"
    if not text then return end
    text=replace(text,head,[=[    nh_reinforce_restore = function()
        ctx.cap.health.on_poly_death(ctx.cap.health.nh_reinforce_restore)
    end,
    on_poly_death = function(request)
        local nh_reinforced = request ~= nil and request == ctx.cap.health.nh_reinforce_restore
        if not nh_reinforced and ctx.cap.health.nh_reinforce_hold and ctx.cap.health.nh_reinforce_hold() then return end]=],1)
    -- The original broadcasts terrain clearing to every peer, twice. A pod
    -- already has a landing site and needs neither the stamp nor the RPC.
    if text then text=replace(text,"            rpc.remove_homing(true)",
        "            if not nh_reinforced then rpc.remove_homing(true) end",2) end
    local nextLine="\n            spectate.disable_throwing(false, ctx.my_player.entity)"
    if text then text=replace(text,"            reduce_hp()"..nextLine,
        "            if not nh_reinforced then reduce_hp() end"..nextLine,1) end
    if text then ModTextFileSetContent(source,text) end
end
return M
