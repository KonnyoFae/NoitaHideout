local M = {types = {}, offers = {}}
local items = "mods/noita_hideout/files/items/"

local function define(kind, zh, en, icon, units, oil)
    M.types[kind] = {zh=zh, en=en, icon=icon}
    local function offer(action, zhVerb, enVerb, yield)
        M.offers[#M.offers+1] = {
            id=kind.."_"..action, category="storm_products", input=kind, yield=yield,
            zh=zh.." · "..zhVerb, en=en.." / "..enVerb, quantity=1,
        }
    end
    if oil then
        offer("distill","分馏","Distill",{midas=2*units, nh_elixir_of_immortality=2*units})
    else
        offer("arcane","奥术碎片","Arcane scrap",{arcane_scrap=3*units})
        offer("container","容器碎片","Container scrap",{container_scrap=units})
    end
    offer("sell","出售","Sell",{gold=500*units})
end

define("storm_mercury","罐装红水银","Canned red mercury","data/items_gfx/canister.png",1,true)
define("storm_mercury_pressure","高压红水银","Pressurized red mercury","data/items_gfx/canister.png",50,true)
define("storm_mana","法力晶块","Mana shard","data/items_gfx/waterstone.png",1,false)
define("storm_mana_pure","高纯晶块","Pure mana shard","data/items_gfx/thunderstone.png",50,false)

function M.register()
    for kind, def in pairs(M.types) do
        local id, product = kind, def
        NHTransfers.registerItem(id,function(e) return EntityHasTag(e,id) end,{
            warehouseCategory="supplies",
            capture=function(e)
                if EntityGetFirstComponentIncludingDisabled(e,"ItemCostComponent") then return nil,"Item unavailable." end
                return {kind=id, name=product.zh, icon=product.icon}
            end,
            restore=function(_,x,y) return EntityLoad(items..id..".xml",x,y) end,
        })
    end
end

function M.check(state, offer)
    local index
    for i,row in ipairs(state.warehouse) do
        if row.item.kind==offer.input then index=i; break end
    end
    if not index then return false,"Store this storm product first." end
    for key,n in pairs(offer.yield) do
        if key=="gold" then
            if n>NHStore.maxGold-state.bankGold then return false,"Piggy bank is full." end
        elseif key=="midas" then
            if not NHStore.canStockMaterials(state,{midas=n}) then return false,"Material storage is full." end
        elseif n>NHStore.maxResourceAmount-(state.resources[key] or 0)-
            (state.order and state.order.output.resources and state.order.output.resources[key] or 0) then
            return false,"Resource storage is full."
        end
    end
    return true,index
end

function M.exchange(state,offer,index)
    for key,n in pairs(offer.yield) do
        if key=="gold" then
            local ok,err=NHStore.creditGold(state,n)
            if not ok then return false,err end
        elseif key=="midas" then state.materials.midas=(state.materials.midas or 0)+n
        else state.resources[key]=(state.resources[key] or 0)+n end
    end
    table.remove(state.warehouse,index)
    return true
end

return M
