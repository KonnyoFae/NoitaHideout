local gui
local pixel = "data/ui_gfx/1px_white.png"

local function clock(seconds)
    return string.format("%02d:%02d", math.floor(seconds / 60), seconds % 60)
end

local function rect(id, x, y, width, height, r, g, b, alpha, z)
    GuiZSetForNextWidget(gui, z)
    GuiColorSetForNextWidget(gui, r, g, b, 1)
    GuiImage(gui, id, x, y, pixel, alpha, width, height)
end

local function draw_rigs(stations, sw, sh, chinese)
    local rigs = EntityGetWithTag("cycle_storm_rig") or {}
    if #rigs == 0 then return end
    local left, top, width, height = GameGetCameraBounds()
    if width <= 0 or height <= 0 then return end
    local frame = GameGetFrameNum()
    for i, rig in ipairs(rigs) do
        local rx, ry = EntityGetTransform(rig)
        local x = (rx - left) * sw / width
        local y = (ry - 28 - top) * sh / height
        if x >= 0 and x <= sw and y >= 0 and y <= sh then
            local active, fill, seconds, count = stations.rigProgress(rig, frame)
            local label = chinese and "待启动" or "Idle"
            if active then
                label = string.format(chinese and "钻探中 %ds · 已出%d罐" or "Drilling %ds · %d out", seconds, count)
            end
            local tw, th = GuiGetTextDimensions(gui, label, 0.8)
            local bar = math.max(32, tw)
            local id = 100 + i * 3
            rect(id, x - bar/2 - 2, y - th - 7, bar + 4, th + 8, 0.07, 0.05, 0.05, 0.84, 2)
            rect(id + 1, x - bar/2, y - 3, bar, 2, 0.36, 0.28, 0.25, 1, 1)
            if fill > 0 then rect(id + 2, x - bar/2, y - 3, bar * fill, 2, 0.94, 0.39, 0.25, 1, 0) end
            GuiColorSetForNextWidget(gui, 1, 0.91, 0.81, 1)
            GuiText(gui, x - tw/2, y - th - 6, label, 0.8)
        end
    end
end

return function(weather, current, elapsed, age, stations)
    gui = gui or GuiCreate()
    GuiStartFrame(gui)
    local sw, sh = GuiGetScreenDimensions(gui)
    local language = GameTextGet("$current_language")
    local chinese = language == "完全汉化" or language:find("中文", 1, true) ~= nil
    if stations then draw_rigs(stations, sw, sh, chinese) end
    local locale = chinese and "zh" or "en"
    local width = math.min(sw - 16, chinese and 158 or 186)
    local x, y = sw - width - 8, sh - 33
    rect(1, x - 3, y - 2, width + 6, 29, 0.06, 0.09, 0.13, 0.82, 5)

    local stage = weather.phases[current]
    local remaining = math.ceil((stage.frames - elapsed) / weather.fps)
    local countdown = clock(remaining)
    local status = stage[locale] .. "  " .. (chinese and ("剩余 " .. countdown) or (countdown .. " left"))
    local progress = clock(math.floor(age / weather.fps)) .. " / " .. clock(weather.frames / weather.fps)
    GuiColorSetForNextWidget(gui, 1, 0.88, 0.59, 1)
    GuiText(gui, x, y, status)
    GuiText(gui, x + width - GuiGetTextDimensions(gui, progress), y, progress)

    local start_frame = 0
    for i, phase in ipairs(weather.phases) do
        local left = math.floor(width * start_frame / weather.frames)
        start_frame = start_frame + phase.frames
        local right = math.floor(width * start_frame / weather.frames)
        local span = right - left - 1
        rect(10 + i, x + left, y + 12, span, 2, 0.44, 0.54, 0.65, 0.75, 1)
        local filled = 0
        if i < current then filled = span end
        if i == current then filled = math.max(1, math.floor(span * elapsed / phase.frames)) end
        if filled > 0 then
            rect(20 + i, x + left, y + 12, filled, 2, 1, 0.79, 0.39, 1, 0)
        end
        local name = phase[locale]
        local label_width = GuiGetTextDimensions(gui, name, 0.8)
        if i == current then
            GuiColorSetForNextWidget(gui, 1, 0.88, 0.59, 1)
        else
            GuiColorSetForNextWidget(gui, 0.77, 0.81, 0.86, 1)
        end
        GuiText(gui, x + left + (span - label_width) / 2, y + 15, name, 0.8)
    end
end
