local root = "mods/noita_hideout/files/storm/"
local weather = dofile(root .. "weather.lua")
local draw_cycle = dofile(root .. "hud.lua")
local stations = dofile(root .. "sites/stations.lua")
local phase, elapsed, age

local function update()
    phase, elapsed, age = weather.update()
    if phase then stations.update(phase, age) end
end

local function draw()
    if phase then draw_cycle(weather, phase, elapsed, age, stations) end
end

return {update = update, draw = draw}
