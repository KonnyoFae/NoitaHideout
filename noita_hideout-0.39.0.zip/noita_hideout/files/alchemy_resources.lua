-- Workshop balances that never occupy a bulk-material slot or a flask.
return {
    nh_philosopher_stone={zh="贤者之石",en="Philosopher's stone"},
    nh_elixir_of_immortality={zh="不死药",en="Elixir of immortality"},
    supply_logistics={zh="补给资源包",en="Supply logistics pack"},
    strike_logistics={zh="轰炸资源包",en="Strike logistics pack"},
    reinforcement_logistics={zh="增援资源包",en="Reinforcement logistics pack"},
    intel_logistics={zh="情报资源包",en="Intel logistics pack"},
}
