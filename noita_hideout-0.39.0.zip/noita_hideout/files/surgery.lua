local M={}
local active

function M.reset(spawnedPlayer)
    active=nil
    -- Older saves may contain the damage listener from an unfinished operation.
    if spawnedPlayer then
        local old=EntityGetFirstComponentIncludingDisabled(spawnedPlayer,"LuaComponent","noita_hideout_surgery_damage")
        if old then EntityRemoveComponent(spawnedPlayer,old) end
    end
end

function M.view()
    if active then
        return {kind=active.kind,elapsed=active.lastFrame-active.startFrame,total=active.duration}
    end
end

local function health(player)
    local model=EntityGetFirstComponentIncludingDisabled(player,"DamageModelComponent")
    if model then
        local hp=ComponentGetValue2(model,"hp")
        local maximum=ComponentGetValue2(model,"max_hp")
        if hp and hp>0 and maximum and maximum>0 then return model,hp,maximum end
    end
end

local function hasCharge(entity,maxCharges)
    local item=EntityGetFirstComponentIncludingDisabled(entity,"ItemComponent")
    local n=item and ComponentGetValue2(item,"uses_remaining")
    return type(n)=="number" and n>=1 and n<=maxCharges
end

function M.beginUse(player,kind,duration,available,finish)
    if active or not available() then return true end
    local model=health(player)
    if not model then return true end
    local frame=GameGetFrameNum()
    active={player=player,kind=kind,model=model,available=available,finish=finish,
        startFrame=frame,lastFrame=frame,duration=duration}
    return true
end

function M.begin(player,kind,available,pay)
    if active or not available() then return true end
    local model,hp,maximum=health(player)
    if not model then return true end
    if hp>=maximum and not NHSurgeryCleanse.has(player) then return true,"unneeded" end
    return M.beginUse(player,kind,NHSurgeryKits.types[kind].castFrames,available,function()
        local model,hp,maximum=health(player)
        if hp>=maximum and not NHSurgeryCleanse.has(player) then return "unneeded" end
        if not pay() then return "interrupted" end
        NHSurgeryCleanse.cleanse(player)
        model,hp,maximum=health(player)
        if model and hp<maximum then
            local percent=NHSurgeryKits.types[kind].healPercent
            ComponentSetValue2(model,"hp",math.min(maximum,hp+maximum*percent/100))
        end
        return "completed"
    end)
end

function M.physicalSource(player,entity,inventorySlot,maxCharges)
    local function available()
        if inventorySlot then
            if not EntityGetIsAlive(entity) or EntityGetParent(entity)~=inventorySlot.parent or EntityGetRootEntity(entity)~=player then return false end
            local item=EntityGetFirstComponentIncludingDisabled(entity,"ItemComponent")
            if not item then return false end
            local x,y=ComponentGetValue2(item,"inventory_slot")
            if x~=inventorySlot.xslot or y~=inventorySlot.yslot then return false end
        elseif GameIsInventoryOpen() or NHNative.held(player)~=entity then return false end
        return hasCharge(entity,maxCharges)
    end
    return available,function()
        local item=EntityGetFirstComponentIncludingDisabled(entity,"ItemComponent")
        local n=ComponentGetValue2(item,"uses_remaining")
        if n==1 then GameKillInventoryItem(player,entity) else ComponentSetValue2(item,"uses_remaining",n-1) end
        return true
    end
end

function M.start(player,entity,inventorySlot)
    if not entity or entity==0 then return false end
    local kind
    for _,id in ipairs(NHSurgeryKits.order) do
        if EntityHasTag(entity,"noita_hideout_"..id) then kind=id; break end
    end
    if not kind then return false end
    return M.begin(player,kind,M.physicalSource(player,entity,inventorySlot,4*NHSurgeryKits.types[kind].uses))
end

function M.update(player)
    local cast=active
    if not cast then return end
    local frame=GameGetFrameNum()
    if player~=cast.player or frame<cast.lastFrame or not EntityGetIsAlive(player)
        or not cast.available() then
        M.reset()
        return "interrupted",cast.kind
    end
    local model=health(player)
    if model~=cast.model then
        M.reset()
        return "interrupted",cast.kind
    end
    cast.lastFrame=frame
    if frame-cast.startFrame<cast.duration then return end

    M.reset()
    return cast.finish(),cast.kind
end

return M
