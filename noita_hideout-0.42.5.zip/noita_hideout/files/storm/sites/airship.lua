local M={}
local root="mods/noita_hideout/files/storm/sites/"
local locations=dofile(root.."locations.lua")
local cabin=dofile("mods/noita_hideout/files/travel/cabin.lua")
local prefix="cycle_storm.sites.ship_"
-- Local coordinates in the 160 x 172 material scene. All world records use
-- the anchor at ground level, also the point a scan should guide players to.
local anchorX,groundY=locations.ship.anchorX,locations.ship.groundY
local floorY=74
local holds={
    {file="ship_safe",x=133,bit=1,loot={"improved_supply_pack","advanced_supply_pack","tactical_medkit","loot_case"}},
    {file="ship_cache",x=55,bit=2,loot={"supply_pack","improved_supply_pack","shield_charger","ammo_pack"}},
}
local guards={{"shotgunner_weak",43},{"scavenger_smg",86},{"shotgunner",117}}
local lastRound

local function berthTag(left,ground)
    return string.format("nh_ship_berth_%d_%d",left,ground)
end

local function claimed(state,hold)
    return math.floor(state/hold.bit)%2==1
end

local function probe(left,py)
    local x=left+anchorX
    if not DoesWorldExistAt(x-8,py-80,x+8,py+114) then return end
    local hit,_,ground=RaytraceSurfaces(x,py-80,x,py+110)
    if not hit then return end
    ground=math.floor(ground)
    local top=ground-groundY
    if cabin.overlaps(left,top,left+160,ground+4,320) then return end
    if not DoesWorldExistAt(left-8,top-5,left+168,ground+6) then return end
    if GameGetSkyVisibility(x,ground-12)<0.5 then return end
    if locations.shipOverlaps(left-260,top-32,left+420,ground+32) then return end
    for _,tag in ipairs({"cycle_storm_well","cycle_storm_rig","nh_home_terminal","nh_landmark_terminal","nh_remote_station"}) do
        if #(EntityGetInRadiusWithTag(left+80,ground-60,165,tag) or {})>0 then return end
    end
    -- Three points support the anchor. Reject water above the soil, ledges
    -- and a tree or hillside crossing the cabins or the boarding route.
    for dx=-8,8,8 do
        local floorHit,_,y=RaytracePlatforms(x+dx,ground-7,x+dx,ground+5)
        if not floorHit or math.abs(y-ground)>4 then return end
        if RaytraceSurfacesAndLiquiform(x+dx,ground-18,x+dx,ground-6) then return end
    end
    for dx=0,159,4 do
        local bottom=dx<=49 and ground-6 or top+85
        if RaytraceSurfacesAndLiquiform(left+dx,top,left+dx,bottom) then return end
    end
    return ground
end

local function place(left,ground,replace)
    local top=ground-groundY
    local tag=berthTag(left,ground)
    local former=replace and EntityGetWithTag(tag) or {}
    local spawned={}
    local function stage(path,x,y)
        local id=EntityLoad(path,x,y)
        if not id or id==0 then
            for _,e in ipairs(spawned) do EntityKill(e) end
            return false
        end
        spawned[#spawned+1]=id
        EntityAddTag(id,tag)
        return true
    end
    for _,hold in ipairs(holds) do
        if not stage(root..hold.file..".xml",left+hold.x,top+floorY) then return end
    end
    for _,guard in ipairs(guards) do
        if not stage("data/entities/animals/"..guard[1]..".xml",left+guard[2],top+floorY-9) then return end
    end
    if not stage(root.."mooring_light.xml",left+anchorX,ground-12) then return end
    if replace then
        for _,e in ipairs(former or {}) do
            local ex,ey=EntityGetTransform(e)
            if ex>=left-8 and ex<=left+168 and ey>=top-8 and ey<=ground+6 then EntityKill(e)
            else EntityRemoveTag(e,tag) end
        end
        RemovePixelSceneBackgroundSprite(root.."ship_background.png",left,top)
    end
    LoadPixelScene(root.."ship_materials.png","",left,top,root.."ship_background.png",true,false,{},50,true)
    locations.setShip(left+anchorX,ground,0)
    return true
end

local function startRound(round)
    if GlobalsGetValue(prefix.."round","")==round then return end
    locations.each("ship",function(x,y,state)
        if state==locations.ship.empty then locations.setShip(x,y,locations.ship.replace) end
    end)
    GlobalsSetValue(prefix.."remaining","3")
    GlobalsSetValue(prefix.."round",round)
end

local function serviceBerths(px,py,cx,cy,cw,ch)
    local replaced=false
    locations.each("ship",function(x,y,state)
        if replaced or state==locations.ship.empty then return end
        local left,top=x-anchorX,y-groundY
        if not DoesWorldExistAt(left-8,top-8,left+168,y+6) then return end
        if px>=left-45 and px<=left+205 and py>=top-45 and py<=y+50 then return end
        if cx+cw>=left-12 and cx<=left+172 and cy+ch>=top-12 and cy<=y+16 then return end
        if state==locations.ship.replace then
            replaced=place(left,y,true)
        else
            -- If another effect removed an unopened box, restore that box alone.
            for _,hold in ipairs(holds) do
                local sx,sy=left+hold.x,top+floorY
                if not claimed(state,hold) and #(EntityGetInRadiusWithTag(sx,sy,4,"nh_"..hold.file) or {})==0 then
                    local id=EntityLoad(root..hold.file..".xml",sx,sy)
                    if id and id~=0 then EntityAddTag(id,berthTag(left,y)) end
                end
            end
        end
    end)
end

function M.update(phase,age)
    local frame=GameGetFrameNum()
    if phase==4 then
        local round=tostring(frame-age)
        if lastRound~=round then startRound(round); lastRound=round end
    else
        lastRound=nil
    end
    if frame%60~=30 then return end
    local player=(EntityGetWithTag("player_unit") or {})[1]
    if not player then return end
    local px,py=EntityGetTransform(player)
    local cx,cy,cw,ch=GameGetCameraBounds()
    serviceBerths(px,py,cx,cy,cw,ch)
    local remaining=tonumber(GlobalsGetValue(prefix.."remaining","0")) or 0
    if remaining<=0 or GameGetSkyVisibility(px,py)<0.35 then return end
    local first=ProceduralRandomi(frame,px,0,1)
    for i=0,1 do
        local gap=16+ProceduralRandomi(frame+i,py,0,36)
        local left=math.floor((first+i)%2==0 and cx+cw+gap or cx-gap-160)
        if px<left-40 or px>left+200 then
            local ground=probe(left,math.floor(py))
            if ground and place(left,ground,false) then
                GlobalsSetValue(prefix.."remaining",tostring(remaining-1))
                if remaining==3 then
                    GamePrintImportant("$nh_storm_ship_arrives","$nh_storm_ship_desc","data/ui_gfx/decorations_biome_modifier/booby_trapped.png")
                else
                    GamePrint(GameTextGetTranslatedOrNot("$nh_storm_ship_desc"))
                end
                return
            end
        end
    end
end

function M.open(player,box)
    if not EntityHasTag(player,"player_unit") then return end
    local interact=EntityGetFirstComponentIncludingDisabled(box,"InteractableComponent")
    if not interact then return end
    local hold=EntityHasTag(box,"nh_ship_cache") and holds[2] or holds[1]
    local x,y=EntityGetTransform(box)
    local anchor,ground=x-hold.x+anchorX,y-floorY+groundY
    local state=locations.shipState(anchor,ground)
    if not state or state>=locations.ship.empty or claimed(state,hold) then return end
    local round=tonumber(GlobalsGetValue(prefix.."round","0")) or 0
    local prize=hold.loot[ProceduralRandomi(x+round,y,1,#hold.loot)]
    local gold
    if hold==holds[1] then
        gold=EntityLoad("data/entities/items/pickup/goldnugget_50.xml",x-6,y-8)
        if not gold or gold==0 then return end
    end
    local item=EntityLoad("mods/noita_hideout/files/items/"..prize..".xml",x+7,y-8)
    if not item or item==0 then
        if gold then EntityKill(gold) end
        return
    end
    locations.setShip(anchor,ground,state+hold.bit)
    EntityRemoveComponent(box,interact)
    local sprite=EntityGetFirstComponentIncludingDisabled(box,"SpriteComponent")
    ComponentSetValue2(sprite,"image_file",root..hold.file.."_open.png")
    EntityRefreshSprite(box,sprite)
end
return M
