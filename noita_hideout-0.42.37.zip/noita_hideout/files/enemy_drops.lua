local D = {redPool = dofile("mods/noita_hideout/files/red_collectibles.lua")}

local function bagKind(hp, score, draw)
    if score < 1 then
        if draw < hp / 20 then return "travel_satchel" end
    elseif score < 1.5 then
        local pack = score - 1
        if draw < pack then return "travel_pack" end
        if draw < pack + 0.5 then return "travel_satchel" end
    else
        local case = math.min(0.5, score - 1.5)
        if draw < case then return "loot_case" end
        if draw < case + 0.5 then return "travel_pack" end
        return "travel_satchel"
    end
end

function D.roll(maxHp, allowBonus, sample)
    -- Standalone enemy templates without a damage model historically gave one satchel.
    if maxHp == nil then return "travel_satchel" end
    if type(maxHp) ~= "number" or not (maxHp > 0 and maxHp < math.huge) then return end
    local hp = 25 * maxHp
    local score = math.log10(hp)
    local bag = bagKind(hp, score, sample(1))
    if not allowBonus then return bag end
    local x = math.max(0.5, score)
    local tarot = sample(2) < math.min(1, 0.008 * x^2)
    local red = sample(3) < math.min(1, 0.00030 * x^3)
    return bag, tarot, red
end

return D
