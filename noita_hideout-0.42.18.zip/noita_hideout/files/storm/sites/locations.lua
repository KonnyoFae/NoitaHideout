local M={radius=2048,ship={width=160,height=172,anchorX=20,groundY=168,empty=3,retiring=4,
    parts={{0,0,159,85},{0,86,49,171}}}}
M.steelFleet={width=512,height=496,anchorX=28,groundY=492,
    -- Gas decks, bridge, lower gun deck, upper escort, lower escort and anchor.
    parts={{0,0,501,103},{62,104,409,188},{74,189,316,239},
        {140,253,299,337},{8,324,167,409},{14,410,57,436},{14,437,38,465},{16,466,40,495}}}
local prefix="cycle_storm.sites."
local keys={rig="rig_locations",well="well_locations",ship="ship_locations"}
local scanKey=prefix.."scan_until"

-- Oil and gas records store their expiry (-1 for idle rigs). Ship records
-- retain their ground anchor until the hull and its fixtures have been removed.
function M.each(kind,visit)
    for x,y,value,suffix in GlobalsGetValue(prefix..keys[kind],""):gmatch("(-?%d+),(-?%d+),(-?%d+)(:?%a*)") do
        visit(tonumber(x),tonumber(y),tonumber(value),suffix==":steel" and "steel" or nil)
    end
end

function M.shipState(x,y)
    local result
    M.each("ship",function(sx,sy,state)
        if sx==x and sy==y then result=state end
    end)
    return result
end

function M.setShip(x,y,newState,layout)
    local entries,found={},false
    M.each("ship",function(sx,sy,state,kind)
        if sx==x and sy==y then found=true; state=newState; kind=layout or kind end
        if state~=nil then entries[#entries+1]=string.format("%d,%d,%d%s",sx,sy,state,kind and ":steel" or "") end
    end)
    if not found and newState~=nil then entries[#entries+1]=string.format("%d,%d,%d%s",x,y,newState,layout and ":steel" or "") end
    GlobalsSetValue(prefix..keys.ship,table.concat(entries,";"))
end

function M.shipOverlaps(left,top,right,bottom)
    local overlap=false
    M.each("ship",function(x,y,_,layout)
        local ship=layout=="steel" and M.steelFleet or M.ship
        local sx,sy=x-ship.anchorX,y-ship.groundY
        if left<sx+ship.width and right>sx and top<sy+ship.height and bottom>sy then overlap=true end
    end)
    return overlap
end

function M.nearShipStructure(x,y,px,py,layout)
    local ship=layout=="steel" and M.steelFleet or M.ship
    local lx,ly=px-x+ship.anchorX,py-y+ship.groundY
    local margin=32
    for _,part in ipairs(ship.parts) do
        if lx>=part[1]-margin and lx<=part[3]+1+margin
            and ly>=part[2]-margin and ly<=part[4]+1+margin then return true end
    end
    return false
end

function M.nearby(px,py,frame)
    local matches={}
    for _,kind in ipairs({"ship","well","rig"}) do
        local nearest
        local count=0
        M.each(kind,function(x,y,value)
            local usable
            if kind=="ship" then
                usable=value<M.ship.empty
            else
                usable=value<0 or value>frame
            end
            local d=(x-px)^2+(y-py)^2
            if usable and d<=M.radius^2 then
                count=count+1
                if not nearest or d<nearest.d then nearest={kind=kind,x=x,y=y,d=d} end
            end
        end)
        if nearest then
            nearest.count=count
            matches[#matches+1]=nearest
        end
    end
    return matches
end

function M.active(frame)
    return (tonumber(GlobalsGetValue(scanKey,"0")) or 0)>frame
end

function M.scan(player,pay,report)
    local frame=GameGetFrameNum()
    if M.active(frame) then report("Radar already active."); return end
    local x,y=EntityGetTransform(player)
    if #M.nearby(x,y,frame)==0 then
        GamePrint(GameTextGetTranslatedOrNot("$nh_storm_scan_empty"))
    elseif pay() then
        GlobalsSetValue(scanKey,tostring(frame+600))
    end
end

return M
