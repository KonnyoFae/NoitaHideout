local root="mods/noita_hideout/files/"
local K={order={"hf_blade","hf_murasama"},types={}}
K.zandatsu={chargeFrames=36,durationFrames=360,radius=160,shieldCostFraction=0.5,
    shieldRewardFraction=0.1,ammoReward=5,healthRewardFraction=0.05}
local modeZh="长按右键 0.6 秒消耗当前剩余护盾的 50%，进入 6 秒静滞斩夺，无盾时无法启动。期间限制移动、按住左键连续快斩，再按右键可提前退出。斩夺亲手击杀敌人恢复最大护盾的 10%、5 点弹挂备弹和最大生命的 5%。"
local modeEn="Hold right-click for 0.6 seconds to spend 50% of current shield for 6 seconds of stasis Blade Mode; requires nonzero shield. Movement is restricted; hold left-click to slash repeatedly and press right-click again to leave early. Each direct Blade Mode kill restores 10% of maximum shield, 5 reserve ammo points and 5% of maximum HP."
K.types.hf_blade={zh="高频振动刀",en="High-frequency blade",scrap=12,chargeAttack="heavy",chargeFrames=30,
    quickDamage=2,quickReach=30,quickWidth=12,quickFrames=5,quickCooldown=10,
    heavyDamage=6,heavyReach=42,heavyWidth=18,heavyFrames=7,heavyCooldown=24,
    noteZh="点按左键快斩，长按左键蓄力，松开重击。"..modeZh,
    noteEn="Tap left-click for a quick slash. Hold left-click and release for a charged heavy strike. "..modeEn}
K.types.hf_murasama={zh="高频村雨刀",en="High-frequency Murasama",scrap=24,chargeAttack="dash",chargeFrames=36,
    quickDamage=2.4,quickReach=32,quickWidth=12,quickFrames=5,quickCooldown=10,
    dashDamage=6,dashDistance=120,dashFrames=6,dashWidth=16,dashCooldown=24,ammoCost=5,
    noteZh="点按左键快斩；长按左键蓄满后，消耗 5 点已装备弹挂备弹，自动向准星疾冲拔刀。"..modeZh,
    noteEn="Tap left-click for a quick slash. Fully charge left-click to spend 5 points from the equipped ammo rig and automatically dash-slash toward the reticle. "..modeEn}
for kind,d in pairs(K.types) do
    d.kind=kind
    d.file=root.."items/"..kind..".xml"
    d.icon=root.."items/"..kind.."_icon.png"
    d.sprite=root.."items/"..kind.."_sprite.xml"
    d.gripX,d.gripY,d.scale=56,32,0.5
    d.action="NH_"..kind:upper()
end

function K.item(kind)
    local d=K.types[kind]
    if d then return {kind=kind,name="$nh_hideout_"..kind,icon=d.icon} end
end

function K.valid(item)
    return type(item)=="table" and K.types[item.kind]~=nil and (item.count==nil or item.count==1)
        and item.remaining==nil and item.rounds==nil and item.reserve==nil
end

function K.recipe(kind)
    local d=assert(K.types[kind],"Unknown katana")
    return {id=kind,category="weapons",zh=d.zh,en=d.en,inputs={},resources={arcane_scrap=d.scrap},
        durationFrames=d.scrap*60,item=K.item(kind),noteZh=d.noteZh,noteEn=d.noteEn}
end

function K.kind(entity)
    if not entity or entity==0 then return end
    for _,kind in ipairs(K.order) do
        if EntityHasTag(entity,"noita_hideout_"..kind) then return kind end
    end
end

-- The native gun system owns the weapon slot, while the katana runtime owns
-- combat. A permanent empty action prevents accidental native projectiles.
function K.ensureBuiltInAction(entity,kind)
    kind=kind or K.kind(entity)
    local d=K.types[kind]
    if not d then return false end
    local card,item
    for _,child in ipairs(EntityGetAllChildren(entity) or {}) do
        local action=EntityGetFirstComponentIncludingDisabled(child,"ItemActionComponent")
        if action and ComponentGetValue2(action,"action_id")==d.action then
            card=child
            item=EntityGetFirstComponentIncludingDisabled(card,"ItemComponent")
            if not item then return false end
            if ComponentGetValue2(item,"permanently_attached") and ComponentGetValue2(item,"is_frozen") then return true end
            break
        end
    end
    if not card then
        local x,y=EntityGetTransform(entity)
        card=CreateItemActionEntity(d.action,x,y)
        if not card or card==0 then return false end
        item=EntityGetFirstComponentIncludingDisabled(card,"ItemComponent")
        if not item then EntityKill(card); return false end
        EntityAddChild(entity,card)
        EntitySetComponentsWithTagEnabled(card,"enabled_in_world",false)
        EntitySetComponentsWithTagEnabled(card,"enabled_in_hand",false)
    end
    ComponentSetValue2(item,"inventory_slot",0,0)
    ComponentSetValue2(item,"permanently_attached",true)
    ComponentSetValue2(item,"is_frozen",true)
    local owner=EntityGetRootEntity(entity)
    local inventory=EntityGetFirstComponentIncludingDisabled(owner,"Inventory2Component")
    if inventory then ComponentSetValue2(inventory,"mForceRefresh",true) end
    return true
end

function K.registerItems()
    for _,id in ipairs(K.order) do
        local kind=id
        local d=K.types[kind]
        NHProducts.icons[kind]=d.icon
        NHTransfers.registerItem(kind,function(entity) return EntityHasTag(entity,"noita_hideout_"..kind) end,{
            warehouseCategory="wand",
            capture=function(entity)
                local item=EntityGetFirstComponentIncludingDisabled(entity,"ItemComponent")
                local ability=EntityGetFirstComponentIncludingDisabled(entity,"AbilityComponent")
                if not item or not ability or not ComponentGetValue2(ability,"use_gun_script")
                    or EntityGetFirstComponentIncludingDisabled(entity,"ItemCostComponent") then return nil,"Katana unavailable." end
                -- The immutable katana record has no spell payload. Refuse
                -- foreign cards rather than destroying them during storage.
                for _,child in ipairs(EntityGetAllChildren(entity) or {}) do
                    local action=EntityGetFirstComponentIncludingDisabled(child,"ItemActionComponent")
                    if action and ComponentGetValue2(action,"action_id")~=d.action then
                        return nil,"Remove added spells before storing this katana."
                    end
                end
                return K.item(kind)
            end,
            restore=function(record,x,y)
                if not K.valid(record) or record.kind~=kind then return nil,"Invalid katana." end
                local entity=EntityLoad(d.file,x,y)
                if not entity or entity==0 then return nil,"Katana unavailable." end
                local item=EntityGetFirstComponentIncludingDisabled(entity,"ItemComponent")
                local ability=EntityGetFirstComponentIncludingDisabled(entity,"AbilityComponent")
                if not item or not ability or not ComponentGetValue2(ability,"use_gun_script") or not K.ensureBuiltInAction(entity,kind) then
                    EntityKill(entity)
                    return nil,"Katana unavailable."
                end
                return entity
            end,
        })
    end
end
return K
