local root="mods/noita_hideout/files/"
local shields=dofile(root.."shield_runtime.lua")
local M={}

-- Spending shield energy is not damage: no health spill, rescue or reactor hit.
function M.spend(player,weapon,commit,shieldFraction,ammo)
    local paid
    local ok=commit(function(draft)
        if NHNative.held(player)~=weapon then return false,"Item unavailable." end
        shields.snapshot(draft,player)
        local shield,rig=draft.gearShield,draft.gearRig
        local cost=0
        if shieldFraction and shieldFraction>0 then
            if not shield or not NHShields.types[shield.item.kind] then return false,"A charged shield is required." end
            if shield.item.charge<=0 then return false,"Not enough shield charge." end
            cost=math.max(1,math.ceil(shield.item.charge*shieldFraction))
            if shield.item.charge<cost then return false,"Not enough shield charge." end
        end
        if ammo and ammo>0 and (not rig or rig.item.reserve<ammo) then return false,"Not enough reserve ammo." end
        if cost>0 then
            shield.item.charge=shield.item.charge-cost
            shield.item.repair,shield.item.delay=0,180
            shield.epoch=draft.revision+1
        end
        if ammo and ammo>0 then rig.item.reserve=rig.item.reserve-ammo end
        paid=draft
        return true
    end)
    if ok and paid then shields.sync(paid,player) end
    return ok==true
end

function M.reward(player,commit,token,total,amount)
    local paid,delta
    local ok=commit(function(draft)
        local prior=draft.katanaRewardToken==token and draft.katanaRewardSeen or 0
        delta=math.max(0,total-(prior or 0))
        if delta==0 then return false,"Reward already collected." end
        shields.snapshot(draft,player)
        local shield,rig=draft.gearShield,draft.gearRig
        if shield and NHShields.types[shield.item.kind] then
            local capacity=NHShields.types[shield.item.kind].cells*NHShields.cell
            shield.item.charge=math.min(capacity,shield.item.charge+math.ceil(capacity*amount.shieldRewardFraction)*delta)
            shield.item.repair=0
            shield.epoch=draft.revision+1
        end
        if rig and NHFirearms.rigs[rig.item.kind] then
            rig.item.reserve=math.min(NHFirearms.rigs[rig.item.kind].capacity,rig.item.reserve+amount.ammoReward*delta)
        end
        draft.katanaRewardToken,draft.katanaRewardSeen=token,total
        paid=draft
        return true
    end)
    if ok and paid then shields.sync(paid,player) end
    return ok==true,delta
end
return M
