local root="mods/noita_hideout/files/"
local K=NHKatanas or dofile(root.."katanas.lua")
local combat=dofile(root.."katana_combat.lua")
local fields=dofile(root.."katana_field.lua")
local resources=dofile(root.."katana_resources.lua")
local rewards=dofile(root.."katana_rewards.lua")
local visual=dofile(root.."katana_visual.lua")
local fx=dofile(root.."katana_fx.lua")
local movement=dofile(root.."katana_movement.lua")
local M={}
local current,input,serial=nil,nil,0
local function first(id,kind,tag)
    if tag then return EntityGetFirstComponentIncludingDisabled(id,kind,tag) end
    return EntityGetFirstComponentIncludingDisabled(id,kind)
end
local function network(name,...)
    if CrossCall and ModIsEnabled("quant.ew") and GlobalsGetValue("nh_ew.status","")~="" then CrossCall(name,...) end
end
local function clock(player)
    return first(player,"VariableStorageComponent","nh_katana_clock")
        or EntityAddComponent2(player,"VariableStorageComponent",{_tags="nh_katana_clock"})
end
local function cooldown(player,untilFrame)
    local c=clock(player)
    if c then ComponentSetValue2(c,"value_int",untilFrame) end
end
local function ready(player,frame)
    local c=clock(player)
    return c and frame>=ComponentGetValue2(c,"value_int")
end
local function guard(player,untilFrame)
    if not player or not EntityGetIsAlive(player) then return end
    local c=first(player,"VariableStorageComponent","nh_katana_dash_guard")
    if not c and untilFrame>0 then c=EntityAddComponent2(player,"VariableStorageComponent",{_tags="nh_katana_dash_guard"}) end
    if c then ComponentSetValue2(c,"value_int",untilFrame) end
end
local function leaveField()
    if not current or not current.field then return end
    movement.release(current.player)
    fields.cancel(current.field)
    network("ew_hideout_katana_field",current.fieldToken,0,0,0,0)
    current.field,current.fieldToken,current.fieldEnd=nil,nil,nil
    current.leftStart,current.rightStart=nil,nil
end
local function cancel()
    leaveField()
    if current then guard(current.player,0);visual.reset(current.player) end
    current=nil
end
function M.reset(saved)
    cancel()
    input=nil
    visual.reset()
    movement.reset()
    if saved then
        for _,field in ipairs(EntityGetWithTag("nh_katana_field") or {}) do fields.cancel(field) end
    end
end
local function suppress(c)
    for _,key in ipairs({"Fire","Fire2","Throw","LeftClick","RightClick"}) do
        ComponentSetValue2(c,"mButtonDown"..key,false)
        ComponentSetValue2(c,"mButtonFrame"..key,-1)
    end
    ComponentSetValue2(c,"mButtonDownDelayLineFire",0)
    ComponentSetValue2(c,"mButtonDownDelayLineThrow",0)
    ComponentSetValue2(c,"mButtonDownDelayLineFire2",0)
end
-- Capture before vanilla item use or another UI handler consumes the buttons.
function M.capture(player,blocked)
    -- Polymorph can preserve a slowed original body while replacing the active player.
    -- Clean its serialized multiplier when that body returns without its old field.
    if player and (not current or current.player~=player or not current.field) then movement.release(player) end
    local weapon=player and NHNative.held(player)
    local kind=weapon and K.kind(weapon)
    if not kind then cancel();input=nil;return false end
    local c=first(player,"ControlsComponent")
    if not c then cancel();input=nil;return true end
    local left=ComponentGetValue2(c,"mButtonDownFire")==true or InputIsMouseButtonDown(1)
    local right=ComponentGetValue2(c,"mButtonDownThrow")==true
        or ComponentGetValue2(c,"mButtonDownFire2")==true or InputIsMouseButtonDown(2)
    if not current or current.player~=player or current.weapon~=weapon then
        cancel()
        current={player=player,weapon=weapon,kind=kind,wasLeft=left,wasRight=right,release=left or right}
        K.ensureBuiltInAction(weapon,kind)
        guard(player,0)
    end
    if blocked then
        leaveField()
        current.attack,current.dash,current.leftStart,current.rightStart=nil,nil,nil,nil
        current.release=left or right
        guard(player,0)
    end
    input={player=player,weapon=weapon,left=left,right=right,blocked=blocked,frame=GameGetFrameNum()}
    if current.field and not blocked then movement.apply(player) end
    if not blocked then suppress(c) end
    return true
end

local function aim(player)
    local x,y=EntityGetTransform(player)
    local dx,dy=NHProducts.aim(player,x,y-4)
    if not dx or dx*dx+dy*dy<0.0001 then dx,dy=1,0 end
    local length=math.sqrt(dx*dx+dy*dy)
    return x,y,dx/length,dy/length
end
local function token(player,frame)
    serial=serial+1
    return "nh_katana/"..player.."/"..frame.."/"..serial
end
local function slash(player,def,frame,heavy,plunder)
    local x,y,dx,dy=aim(player)
    local prefix=heavy and "heavy" or "quick"
    local a={token=token(player,frame),kind=current.kind,damage=def[prefix.."Damage"],width=def[prefix.."Width"],
        reach=def[prefix.."Reach"],duration=def[prefix.."Frames"],start=frame,dx=dx,dy=dy,hit={},plunder=plunder==true}
    current.attack=a
    cooldown(player,frame+(plunder and 6 or def[prefix.."Cooldown"]))
    GamePlaySound("data/audio/Desktop/player.bank","player/throw",x,y)
end
local function apply(player,a,x1,y1,x2,y2,showFx)
    local event={token=a.token,kind=a.kind,x1=x1,y1=y1,x2=x2,y2=y2,width=a.width,damage=a.damage,
        plunder=a.plunder,showFx=showFx==true}
    local hits=combat.apply(player,event,a.hit)
    network("ew_hideout_katana_attack",event)
    if showFx then fx.spawn(x1,y1,math.atan2(y2-y1,x2-x1),a.kind,
        math.sqrt((x2-x1)^2+(y2-y1)^2)/64,math.cos(math.atan2(y2-y1,x2-x1))<0 and -1 or 1) end
    if hits>0 and not a.sounded then
        GamePlaySound("data/audio/Desktop/player.bank","player/kick",x2,y2)
        a.sounded=true
    end
end
local function dash(player,def,frame,commit)
    local x,y,dx,dy=aim(player)
    local _,_,travelled=combat.safeStep(x,y,dx,dy,math.min(8,def.dashDistance))
    if travelled<2 then return false end
    if not resources.spend(player,current.weapon,commit,nil,def.ammoCost) then return false end
    current.dash={token=token(player,frame),kind=current.kind,start=frame,duration=def.dashFrames,
        distance=def.dashDistance,dx=dx,dy=dy,hit={},width=def.dashWidth,damage=def.dashDamage}
    cooldown(player,frame+def.dashFrames+def.dashCooldown)
    guard(player,frame+def.dashFrames)
    GamePlaySound("data/audio/Desktop/player.bank","player/throw",x,y)
    return true
end
function M.update(state,player,commit,enabled)
    if player then rewards.claim(state,player,commit) end
    if not current or not input then return end
    local c=current
    -- Noita advances GameGetFrameNum between PreUpdate and PostUpdate.
    local inputAge=GameGetFrameNum()-input.frame
    if not player or c.player~=player or not EntityGetIsAlive(player) or NHNative.held(player)~=c.weapon
        or input.weapon~=c.weapon or inputAge<0 or inputAge>1 then cancel();return end
    local dm=first(player,"DamageModelComponent")
    if not dm or ComponentGetValue2(dm,"hp")<=0 then cancel();return end
    local frame=GameGetFrameNum()
    local def=K.types[c.kind]
    local left,right=input.left,input.right
    local leftPress,rightPress=left and not c.wasLeft,right and not c.wasRight
    c.wasLeft,c.wasRight=left,right
    if input.blocked or not enabled then
        leaveField();c.attack,c.dash,c.leftStart,c.rightStart=nil,nil,nil,nil
        c.release=left or right;guard(player,0)
        visual.pose(player,c.weapon,c.kind,frame)
        return end
    if c.release then
        c.release=left or right
        visual.pose(player,c.weapon,c.kind,frame)
        return {kind=c.kind}
    end
    if c.field and not fields.active(c.field) then leaveField() end
    if c.field then
        local px,py=EntityGetTransform(player)
        local fx,fy=EntityGetTransform(c.field)
        if (px-fx)^2+(py-fy)^2>K.zandatsu.radius^2 then leaveField() end
    end
    if c.field then
        movement.apply(player)
        if rightPress then leaveField();c.release=left or right
        else
            if left and ready(player,frame) then slash(player,def,frame,false,true) end
            if frame%15==0 then
                local x,y=EntityGetTransform(c.field)
                network("ew_hideout_katana_field",c.fieldToken,x,y,K.zandatsu.radius,c.fieldEnd-frame)
            end
        end
    elseif not c.dash then
        if rightPress and not c.attack and ready(player,frame) then
            c.rightStart,c.leftStart=frame,nil
        end
        if c.rightStart then
            if not right then c.rightStart=nil
            elseif frame-c.rightStart>=K.zandatsu.chargeFrames then
                c.rightStart=nil
                local field=fields.activate(player,{radius=K.zandatsu.radius,duration=K.zandatsu.durationFrames,weapon=c.weapon},
                    function() return resources.spend(player,c.weapon,commit,K.zandatsu.shieldCostFraction) end)
                if field then
                    c.field,c.fieldEnd,c.fieldToken=field,frame+K.zandatsu.durationFrames,token(player,frame)
                    movement.apply(player)
                    local x,y=EntityGetTransform(field)
                    network("ew_hideout_katana_field",c.fieldToken,x,y,K.zandatsu.radius,K.zandatsu.durationFrames)
                    GamePlaySound("data/audio/Desktop/projectiles.bank","player_projectiles/kantele/a/create",x,y)
                end
            end
        elseif not right and not c.attack then
            if leftPress and ready(player,frame) then c.leftStart=frame end
            if c.leftStart then
                local elapsed=frame-c.leftStart
                if def.chargeAttack=="dash" and elapsed>=def.chargeFrames then
                    c.leftStart=nil
                    dash(player,def,frame,commit)
                elseif not left then
                    c.leftStart=nil
                    slash(player,def,frame,def.chargeAttack=="heavy" and elapsed>=def.chargeFrames,false)
                end
            end
        end
    end
    local angle,kick
    if c.dash then
        local a=c.dash
        local x,y,rotation,scaleX,scaleY=EntityGetTransform(player)
        local tx,ty,moved=combat.safeStep(x,y,a.dx,a.dy,a.distance/a.duration)
        EntitySetTransform(player,tx,ty,rotation or 0,scaleX or 1,scaleY or 1)
        local motion=first(player,"CharacterDataComponent")
        if motion then ComponentSetValue2(motion,"mVelocity",0,0) end
        if moved>0 then apply(player,a,x,y-4,tx,ty-4,true) end
        angle=math.atan2(a.dy,a.dx)
        if moved<a.distance/a.duration or frame-a.start>=a.duration-1 then c.dash=nil;guard(player,0) end
    elseif c.attack then
        local a=c.attack
        local x,y=EntityGetTransform(player)
        local age=frame-a.start
        apply(player,a,x,y-4,x+a.dx*a.reach,y-4+a.dy*a.reach,age==0)
        angle=math.atan2(a.dy,a.dx)
        kick=0.08*math.sin(math.pi*(age+1)/(a.duration+1))*(a.dx<0 and -1 or 1)
        if age>=a.duration-1 then c.attack=nil end
    end
    visual.pose(player,c.weapon,c.kind,frame,{angle=angle,handKick=kick})
    local progress=c.leftStart and math.min(1,(frame-c.leftStart)/def.chargeFrames)
        or c.rightStart and math.min(1,(frame-c.rightStart)/K.zandatsu.chargeFrames)
    return {kind=c.kind,charge=progress,preparing=c.rightStart~=nil,plunder=c.field and math.max(0,c.fieldEnd-frame),
        heavyReady=c.leftStart and frame-c.leftStart>=def.chargeFrames}
end
return M
