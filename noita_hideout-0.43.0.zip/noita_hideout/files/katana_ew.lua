-- Each enemy is hit/frozen only by its simulation owner. The attacking peer
-- pays costs; reliable reward events are credited on the player owner.
local root="mods/noita_hideout/files/"
local api=dofile_once("mods/quant.ew/files/api/ew_api.lua")
local rpc=api.new_rpc_namespace("nh_katana")
local combat=dofile_once(root.."katana_combat.lua")
local fields=dofile_once(root.."katana_field.lua")
local rewards=dofile_once(root.."katana_rewards.lua")
local visual=dofile_once(root.."katana_visual.lua")
local fx=dofile_once(root.."katana_fx.lua")
local K=dofile_once(root.."katanas.lua")
local M={}
local serial,seen,hits,poses=0,{},{},{}
local function finite(n,limit)
    return type(n)=="number" and n==n and math.abs(n)<=limit
end
local function scope()
    local world=nh_ew_session and nh_ew_session.world()
    local boot=world and nh_ew_session.challenge(ctx.my_id)
    if world and boot then serial=serial+1;return world,boot,serial end
end
local function accept(lane,world,boot,number)
    if not nh_ew_session or nh_ew_session.world()~=world or type(boot)~="string"
        or not finite(number,9007199254740991) or number<1 or number~=math.floor(number) then return end
    local peer=api.rpc_player_data()
    if not peer or peer.dc or peer.peer_id==ctx.my_id or nh_ew_session.challenge(peer.peer_id)~=boot then return end
    if lane~="credit" and (not peer.entity or not EntityGetIsAlive(peer.entity)) then return end
    local key=lane.."/"..peer.peer_id
    local prior=seen[key]
    if prior and prior.world==world and prior.boot==boot and number<=prior.number then return end
    seen[key]={world=world,boot=boot,number=number}
    return peer
end
util.add_cross_call("ew_hideout_katana_attack",function(event)
    local world,boot,sequence=scope()
    if world then rpc.attack(world,boot,sequence,event) end
end)
rpc.opts_reliable()
function rpc.attack(world,boot,sequence,a)
    local peer=accept("attack",world,boot,sequence)
    if not peer or type(a)~="table" or not K.types[a.kind] or type(a.token)~="string" or #a.token>100
        or not a.token:match("^nh_katana/%d+/%d+/%d+$") or not finite(a.damage,8) or a.damage<=0
        or not finite(a.width,24) or a.width<=0 then return end
    for _,key in ipairs({"x1","y1","x2","y2"}) do if not finite(a[key],10000000) then return end end
    local dx,dy=a.x2-a.x1,a.y2-a.y1
    local length=math.sqrt(dx*dx+dy*dy)
    local px,py=EntityGetTransform(peer.entity)
    if length>150 or (a.x1-px)^2+(a.y1-py)^2>256^2 then return end
    local key=peer.peer_id.."/"..boot.."/"..a.token
    local entry=hits[key]
    if not entry then entry={targets={},expires=GameGetFrameNum()+120};hits[key]=entry end
    combat.apply(peer.entity,a,entry.targets)
    local angle=math.atan2(dy,dx)
    poses[peer.peer_id]={angle=angle,untilFrame=GameGetFrameNum()+6}
    if a.showFx==true then fx.spawn(a.x1,a.y1,angle,a.kind,length/64,dx<0 and -1 or 1) end
end
util.add_cross_call("ew_hideout_katana_field",function(token,x,y,radius,remaining)
    local world,boot,sequence=scope()
    if world then rpc.field(world,boot,sequence,token,x,y,radius,remaining) end
end)
rpc.opts_reliable()
function rpc.field(world,boot,sequence,token,x,y,radius,remaining)
    local peer=accept("field",world,boot,sequence)
    if not peer or type(token)~="string" or #token>100 or not token:match("^nh_katana/%d+/%d+/%d+$")
        or not finite(remaining,360) or remaining<0 then return end
    local key=peer.peer_id.."/"..boot.."/"..token
    if remaining==0 then fields.cancelRemote(key);return end
    if not finite(x,10000000) or not finite(y,10000000) or radius~=K.zandatsu.radius then return end
    local px,py=EntityGetTransform(peer.entity)
    if (x-px)^2+(y-py)^2>(radius+128)^2 then return end
    fields.applyRemote(peer.entity,key,x,y,radius,remaining)
end
util.add_cross_call("ew_hideout_katana_credit",function(replica)
    local target=ctx.player_data_by_local_entity[replica]
    if not target or target.entity~=replica or target.dc or target.peer_id==ctx.my_id then return end
    local world,boot,sequence=scope()
    local targetBoot=world and nh_ew_session.challenge(target.peer_id)
    if targetBoot then rpc.credit(world,boot,sequence,target.peer_id,targetBoot) end
end)
rpc.opts_reliable()
function rpc.credit(world,boot,sequence,target,targetBoot)
    if target~=ctx.my_id or not nh_ew_session or nh_ew_session.challenge(target)~=targetBoot then return end
    if accept("credit",world,boot,sequence) and ctx.my_player then rewards.credit(ctx.my_player.entity) end
end
function M.on_world_initialized()
    seen,hits,poses={},{},{}
    visual.reset()
end
function M.on_world_update()
    local frame=GameGetFrameNum()
    for key,entry in pairs(hits) do if frame>entry.expires then hits[key]=nil end end
    for peerId,peer in pairs(ctx.players or {}) do
        if peerId~=ctx.my_id and peer.entity then
            local player=peer.entity
            local inv=EntityGetIsAlive(player) and EntityGetFirstComponentIncludingDisabled(player,"Inventory2Component")
            local weapon=inv and ComponentGetValue2(inv,"mActiveItem")
            local kind=weapon and weapon~=0 and K.kind(weapon)
            if not peer.dc and kind then
                local pose=poses[peerId]
                local c=EntityGetFirstComponentIncludingDisabled(player,"ControlsComponent")
                local dx,dy=1,0
                if c then dx,dy=ComponentGetValue2(c,"mAimingVectorNormalized") end
                visual.pose(player,weapon,kind,frame,{angle=pose and frame<=pose.untilFrame and pose.angle or math.atan2(dy,dx)})
            else visual.reset(player) end
        end
    end
end
return M
