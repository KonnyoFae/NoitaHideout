return function(gui,v,sw,sh,tr)
    if v.transit then
        local text=tr("正在确认降落点…","Checking landing site…")
        GuiText(gui,(sw-GuiGetTextDimensions(gui,text))/2,sh-36,text)
        return
    end
    if v.key then
        local text=tr("长按 %s  开启返航门","Hold %s  Open return portal"):format(v.key)
        if v.percent then text=text.."  "..v.percent.."%" end
        GuiColorSetForNextWidget(gui,0.65,0.92,1,1)
        GuiText(gui,(sw-GuiGetTextDimensions(gui,text))/2,sh-36,text)
        return
    end
    local first=math.max(1,math.min(v.selected-2,#v.rows-4))
    local last=math.min(#v.rows,first+4)
    local help=tr("↑ ↓ 或 PgUp/PgDn 选择    Enter 开门    Esc 关闭","Up/Down or PgUp/PgDn: select    Enter: open    Esc: close")
    local width=math.max(145,GuiGetTextDimensions(gui,help)+12)
    local height=35+(last-first+1)*12
    local x,y=(sw-width)/2,(sh-height)/2
    GuiZSetForNextWidget(gui,-88)
    GuiColorSetForNextWidget(gui,0.06,0.09,0.12,1)
    GuiImage(gui,7350,x,y,"data/ui_gfx/1px_white.png",0.94,width,height)
    local function line(row,text,selected)
        GuiZSetForNextWidget(gui,-90)
        if selected then GuiColorSetForNextWidget(gui,1,0.83,0.49,1) end
        GuiText(gui,x+6,y+row,text)
    end
    line(3,tr("旅行终端","Travel terminal").."   "..v.selected.." / "..#v.rows,true)
    for i=first,last do
        local dest=v.rows[i]
        local name=dest.kind=="home" and tr("矿井入口 · 藏身处","Mines entrance · Hideout")
            or string.format(tr("圣山  (%d, %d)","Holy Mountain  (%d, %d)"),dest.x,dest.y)
        line(17+(i-first)*12,(i==v.selected and ">  " or "    ")..name,i==v.selected)
    end
    line(height-13,help,false)
end
