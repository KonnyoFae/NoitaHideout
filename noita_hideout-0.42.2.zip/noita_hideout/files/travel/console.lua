function interacting(player,terminal)
    if EntityHasTag(player,"player_unit") then
        GlobalsSetValue("nh_travel.console_request",tostring(GameGetFrameNum()))
    end
end
