local R={resource="supply_logistics",station="resupply",shortage="Not enough supply logistics packs."}
local items="mods/noita_hideout/files/items/"
local pendingEjections={}
local flightSerial=0

-- Box2D initializes a newly spawned item's body on a subsequent engine tick.
function R.eject()
    for id,side in pairs(pendingEjections) do
        if not EntityGetIsAlive(id) or EntityGetRootEntity(id)~=id then
            pendingEjections[id]=nil
        elseif #(PhysicsBodyIDGetFromEntity(id) or {})>0 then
            PhysicsApplyForce(id,side*32,-55)
            pendingEjections[id]=nil
        end
    end
end

-- Look for a reachable column beside the caller. A cave roof shortens the
-- descent. Sample both edges so the capsule cannot start inside an overhang.
local function column(px,py,x,air)
    if x~=px and RaytracePlatforms(px,py,x,py) then return end
    local floor,ceiling
    for _,edge in ipairs({x-6,x,x+6}) do
        local hit,_,ground=RaytracePlatforms(edge,py-2,edge,py+96)
        if not hit and not air then return end
        if not hit then ground=py+8 end
        floor=math.min(floor or ground,ground)
        local roof,_,top=RaytracePlatforms(edge,py-2,edge,py-64)
        local limit=roof and top+9 or py-60
        ceiling=math.max(ceiling or limit,limit)
    end
    if ceiling+2>=floor-8 then return end
    if not DoesWorldExistAt(math.floor(x-8),math.floor(ceiling-8),math.ceil(x+8),math.ceil(floor+1)) then return end
    return ceiling
end

local groundUnits={missile_crab=true,robot_monk=true,ground_guard=true,mg_turret=true,chaingun_turret=true,missile_turret=true}
-- For a player drop, require a loaded, dry standing space across the whole
-- capsule footprint. Recheck when launching and opening the pod.
function R.playerDropSite(x,y)
    x,y=math.floor(x),math.floor(y)
    if not DoesWorldExistAt(x-8,y-26,x+8,y+34) then return end
    local hit,_,floor=RaytracePlatforms(x,y-3,x,y+32)
    if not hit then return end
    for dx=-6,6,2 do
        local sx=x+dx
        local supported,_,h=RaytracePlatforms(sx,floor-3,sx,floor+4)
        if not supported or math.abs(h-floor)>3 or RaytraceSurfacesAndLiquiform(sx,h-22,sx,h-1) then return end
    end
    local start=column(x,floor-8,x)
    if start then return {x=x,y=floor-8,start=start} end
end

local function spawnPod(call,x,start,bottom)
    local id=EntityLoad("mods/noita_hideout/files/supply_pod.xml",x,start)
    if not id or id==0 then return false end
    call.phase,call.pod,call.x,call.y,call.bottom,call.speed="descending",id,x,start,bottom,1
    return true
end

function R.playerDropClear(x,y,ignore)
    -- EW keeps ew_client on remote polymorphs when the normal peer body
    -- (and its ew_peer tag) has been replaced.
    for _,tag in ipairs({"ew_peer","ew_client"}) do
        for _,body in ipairs(EntityGetInRadiusWithTag(x,y,13,tag) or {}) do
            if body~=ignore and not EntityHasTag(body,"nh_ew_waiting") then return false end
        end
    end
    return true
end

function R.launchPlayerPod(call,player)
    local px,py=EntityGetTransform(player)
    for _,dx in ipairs({22,-22,36,-36}) do
        if not RaytracePlatforms(px,py,px+dx,py) then
            local site=R.playerDropSite(px+dx,py)
            if site and R.playerDropClear(site.x,site.y) then
                call.landingY=site.y
                if not spawnPod(call,site.x,site.start,site.y+16) then return false end
                EntityAddTag(call.pod,"ew_no_enemy_sync")
                if call.ticket and call.ticket.world then
                    flightSerial=flightSerial+1
                    call.flight=GameGetFrameNum().."."..flightSerial
                    call.flightCycle=tonumber(SessionNumbersGetValue("NEW_GAME_PLUS_COUNT")) or 0
                    GlobalsSetValue("nh_ew.pod_start",table.concat({call.ticket.world,call.flightCycle,call.flight,GameGetFrameNum(),
                        math.floor(site.x),math.floor(site.start),math.floor(site.y)},"|"))
                end
                return true
            end
        end
    end
    return false
end

function R.finishPlayerPod(call,opened)
    if call.flight then
        GlobalsSetValue("nh_ew.pod_end",table.concat({call.ticket.world,call.flightCycle,call.flight,GameGetFrameNum(),
            opened and "open" or "cancel",math.floor(call.y)},"|"))
        call.flight=nil
    end
end

function R.launch(call,player)
    local px,py=EntityGetTransform(player)
    local supply=call.tier~=nil or call.weapon~=nil
    for _,offset in ipairs(supply and {0,6,-6,16,-16} or {22,-22,36,-36,0}) do
        local x=px+offset
        local start=column(px,py,x)
        if not supply and not groundUnits[call.project] and not start then
            start=column(px,py,x,true)
            if start then call.airY=py end
        end
        if start then
            return spawnPod(call,x,start,py+100)
        end
    end
end

-- Return the first surface touched by the bottom of the moving pod. Check
-- again during flight because explosions and falling material change terrain.
function R.advance(call)
    if not EntityGetIsAlive(call.pod) or not EntityHasTag(call.pod,"nh_supply_pod") then return "failed" end
    local x,y=call.x,call.y
    call.speed=math.min(5,call.speed+0.18)
    local nextY=y+call.speed
    if nextY>call.bottom or not DoesWorldExistAt(math.floor(x-8),math.floor(y-8),math.ceil(x+8),math.ceil(nextY+9)) then
        return "failed"
    end
    local floor
    for _,edge in ipairs({x-6,x,x+6}) do
        local hit,_,ground=RaytracePlatforms(edge,y+8,edge,nextY+8)
        if hit then floor=math.min(floor or ground,ground) end
    end
    call.y=floor and floor-8 or nextY
    if call.airY then call.y=math.min(call.airY,call.y) end
    EntitySetTransform(call.pod,x,call.y)
    if floor or call.y==call.airY then return "landed" end
end

function R.deliver(call,pay)
    local packs={}
    local count=call.weapon and 1 or 4
    local path=items..(call.weapon or NHLootBags.packKinds[call.tier])..".xml"
    for i=1,count do
        local id=EntityLoad(path,call.x+(i-(count+1)/2)*2,call.y)
        if not id or id==0 then break end
        packs[i]=id
    end
    if #packs==count and pay() then
        for i,id in ipairs(packs) do pendingEjections[id]=i-(count+1)/2 end
        return true
    end
    for _,id in ipairs(packs) do EntityKill(id) end
    if #packs<count then return false,"Supply pod could not open." end
    return false
end
return R
