-- Runs in EW's Lua state. Only the host writes the winner. Its settings
-- receipt also survives a host world checkpoint older than the pickup.
local api=dofile_once("mods/quant.ew/files/api/ew_api.lua")
local rpc=api.new_rpc_namespace("nh_pickup1")
local M={}
local last,at

local function valid(key)
    if type(key)~="string" or #key>156 then return false end
    local gid=key:match("^g/(%d+)$")
    if gid then return #gid<=20 end
    return key:match("^t/ew/[%w_-]+/r/%d+/%d+/%d+/%d+/%d+/%d+$")~=nil
end

local function settle(world,key,winner)
    if type(world)=="string" and nh_ew_session and nh_ew_session.world()==world and valid(key)
        and type(winner)=="string" and #winner<=40 and winner:match("^[%w_-]+$") then
        GlobalsSetValue("nh_ew.item_result."..world.."|"..key,winner)
    end
end

rpc.opts_reliable()
function rpc.winner(peer,world,key,issuer)
    if peer==ctx.my_id and ctx.rpc_peer_id==ctx.host_id then settle(world,key,issuer) end
end

local function decide(peer,world,key)
    if not ctx.is_host or type(world)~="string" or not nh_ew_session or nh_ew_session.world()~=world or not valid(key) then return end
    local issuer=nh_ew_session.issuer(peer)
    if not issuer then return end
    local field="noita_hideout.ew_claim."..world.."."..key
    local winner=ModSettingGet(field)
    if winner==nil then
        pcall(ModSettingSet,field,issuer)
        winner=ModSettingGet(field)
    end
    if type(winner)~="string" then return end
    if peer==ctx.my_id then settle(world,key,winner)
    else rpc.winner(peer,world,key,winner) end
end

rpc.opts_reliable()
function rpc.request(world,key) decide(ctx.rpc_peer_id,world,key) end

function M.on_world_update()
    local f=GameGetFrameNum()
    if f%4~=0 or not nh_ew_session then return end
    local request=GlobalsGetValue("nh_ew.item_request","")
    if request=="" then return end
    local world,key=request:match("^([%w_-]+)|(.+)$")
    if world~=nh_ew_session.world() or not valid(key) then return end
    if GlobalsGetValue("nh_ew.item_result."..request,"")~="" then
        GlobalsSetValue("nh_ew.item_request","")
    elseif request~=last or f-at>=60 or f<at then
        last,at=request,f
        if ctx.is_host then decide(ctx.my_id,world,key) else rpc.request(world,key) end
    end
end
return M
