-- The controller owns the caller's personal stock. EW owns the downed bodies.
-- Persist the five packs and the exact request together before contacting the host.
return function(current,draftForRun,save,tr,feedback)
    local M={}
    local cost=5
    local stockKey="supply_logistics"
    local requestKey="nh_ew.reinforce_request"
    local lastRoster,targets,lastChecked
    local function validPosition(n)
        return type(n)=="number" and math.abs(n)<1073741824
    end

    local function roster()
        local raw=GlobalsGetValue("nh_ew.reinforce_targets","")
        if raw~=lastRoster then
            lastRoster,targets=raw,{}
            for line in raw:gmatch("[^\r\n]+") do
                local owner,episode,x,y=line:match("^(%w+)|([1-9]%d*)|(-?%d+)|(-?%d+)|")
                x,y=tonumber(x),tonumber(y)
                if validPosition(x) and validPosition(y) and #owner<=40 and #episode<=15 and owner~=NHEW.issuer() then
                    targets[owner]={episode=episode,x=x,y=y}
                end
            end
        end
        return targets
    end

    function M.visible()
        local world=NHEW.world()
        local state=current()
        return world~=nil and state~=nil and state.ewActive==world
            and GlobalsGetValue("nh_ew.reinforce_mode","")==world
    end

    function M.available()
        if not M.visible() then return false,tr("联机增援尚未就绪。","Multiplayer reinforcement is unavailable.") end
        local state=current()
        if (state.resources[stockKey] or 0)<cost then return false,tr("需要 5 点补给资源。","Requires 5 supply logistics packs.") end
        local pending=state.ewReinforcePending
        for target in pairs(roster()) do
            if not pending or not pending[target] then return true end
        end
        return false,tr("暂无可增援的倒地队友。","No downed teammate is available for reinforcement.")
    end

    function M.select(player,x,y)
        local ok,reason=M.available()
        if not ok then return nil,reason end
        if not NHEW.localBody(player) or not validPosition(x) or not validPosition(y) then
            return nil,tr("无法确认呼叫者的位置。","Could not locate the caller.")
        end
        local best,distance
        local pending=current().ewReinforcePending
        for owner,target in pairs(roster()) do
            local d=(x-target.x)^2+(y-target.y)^2
            if (not pending or not pending[owner]) and (not distance or d<distance or (d==distance and owner<best)) then
                best,distance=owner,d
            end
        end
        return {world=NHEW.world(),owner=NHEW.issuer(),target=best,episode=targets[best].episode}
    end

    function M.request(player,x,y,ticket)
        local ok,reason=M.available()
        if not ok then return false,reason end
        local owner=NHEW.issuer()
        local target=ticket and roster()[ticket.target]
        if not owner or not NHEW.localBody(player) or not target or target.episode~=ticket.episode
            or ticket.owner~=owner or ticket.world~=NHEW.world() then
            return false,tr("这次倒地已结束，增援取消。","The selected teammate is no longer down. Reinforcement canceled.")
        end
        local draft=draftForRun()
        if not draft or draft.ewActive~=ticket.world or (draft.ewReinforcePending and draft.ewReinforcePending[ticket.target]) then
            return false,tr("增援档案已改变。","The reinforcement record has changed.")
        end
        if not validPosition(x) or not validPosition(y) or draft.revision>=999999999999999 then
            return false,tr("无法提交这次空投。","Cannot submit this drop.")
        end
        if (draft.resources[stockKey] or 0)<cost then return false,tr("需要 5 点补给资源。","Requires 5 supply logistics packs.") end
        local request=table.concat({ticket.world,owner,string.format("%.0f",draft.revision+1),ticket.target,
            ticket.episode,math.floor(x),math.floor(y)},"|")
        NHStore.deductStock(draft.resources,{[stockKey]=cost})
        draft.ewReinforcePending=draft.ewReinforcePending or {}
        draft.ewReinforcePending[ticket.target]=request
        if not save(draft) then return false,tr("无法保存这次增援请求。","Could not save the reinforcement request.") end
        GlobalsSetValue(requestKey,request)
        return true
    end

    function M.settle()
        local entries=current().ewReinforcePending
        if not entries then return end
        -- A disconnected recipient can keep their own receipt outstanding.
        -- Rotate the mailbox so it never stalls another teammate's rescue.
        local first,after
        for who in pairs(entries) do
            if not first or who<first then first=who end
            if lastChecked and who>lastChecked and (not after or who<after) then after=who end
        end
        lastChecked=after or first
        local pending=entries[lastChecked]
        local world,owner,id=pending:match("^([%w_-]+)|([%w_-]+)|(%d+)|")
        if not world or world~=NHEW.world() or owner~=NHEW.issuer() then return end
        local receipt=GlobalsGetValue("nh_ew.reinforce_result."..world.."."..owner.."."..id,"")
        if receipt~="ok" and receipt~="rejected" then
            if GlobalsGetValue(requestKey,"")~=pending then GlobalsSetValue(requestKey,pending) end
            return
        end
        local draft=draftForRun()
        if not draft or not draft.ewReinforcePending or draft.ewReinforcePending[lastChecked]~=pending then return end
        if receipt=="rejected" then
            local stock=draft.resources[stockKey] or 0
            if stock>NHStore.maxResourceAmount-cost then return end -- Keep the refund until it fits.
            draft.resources[stockKey]=stock+cost
        end
        draft.ewReinforcePending[lastChecked]=nil
        if not next(draft.ewReinforcePending) then draft.ewReinforcePending=nil end
        if not save(draft) then return end
        if GlobalsGetValue(requestKey,"")==pending then GlobalsSetValue(requestKey,"") end
        if receipt=="ok" then feedback(tr("队友已满血归队，消耗 5 点补给。","Teammate revived at full health. Spent 5 supply packs."))
        else feedback(tr("增援取消，5 点补给已退还。","Reinforcement canceled. Refunded 5 supply packs.")) end
    end
    return M
end
