-- Runs in EW's VM. The host binds one payer to a downed body. Only the
-- machine owning that body can run EW's restore or acknowledge its result.
local api=dofile_once("mods/quant.ew/files/api/ew_api.lua")
local pod=dofile_once("mods/noita_hideout/files/resupply.lua")
local rpc=api.new_rpc_namespace("nh_reinforce1")
local M={}
local prefix="nh_ew.reinforce_"
local ledger="noita_hideout.ew_reinforce."
local room,seen,lastAdvert,lastRequest,lastFrame,published,lastRollback,boot

local function read(key) return GlobalsGetValue(prefix..key,"") end
local function write(key,value) GlobalsSetValue(prefix..key,value) end
local function save(key,value)
    pcall(ModSettingSet,key,value)
    return ModSettingGet(key)==value
end
local function id(s)
    return type(s)=="string" and #s<=40 and s:match("^%w+$")~=nil
end
local function number(s)
    return type(s)=="string" and #s<=15 and s:match("^[1-9]%d*$")~=nil
end
local function position(n)
    return type(n)=="number" and n==math.floor(n) and math.abs(n)<1073741824
end
local function world()
    if not nh_ew_session or not ctx.ready or ctx.run_ended or not ctx.cap.health
        or not ctx.cap.health.nh_reinforce_restore or ctx.proxy_opt.game_mode~="local_health"
        or ctx.proxy_opt.no_notplayer or ctx.proxy_opt.perma_death or ctx.proxy_opt.pvp
        or GameHasFlagRun("ending_game_completed") or GameHasFlagRun("ew_kill_player") then return end
    return nh_ew_session.world()
end
local function current(field) return seen and field~=nil and field==room and field==world() end
local function owner(peer) return nh_ew_session.issuer(peer) end
local function peerFor(who)
    for peer,p in pairs(ctx.players) do
        if not p.dc and owner(peer)==who then return peer end
    end
end
local function tag(entity,name)
    return EntityGetFirstComponentIncludingDisabled(entity,"VariableStorageComponent",name)
end
local function localBody()
    local p=ctx.my_player and ctx.my_player.entity
    if p and EntityGetIsAlive(p) and GameHasFlagRun("ew_flag_notplayer_active")
        and EntityHasTag(p,"ew_notplayer") and not EntityHasTag(p,"ew_client") then return p end
end
local function loaded(x,y) return DoesWorldExistAt(x-8,y-26,x+8,y+34) end
local function safeSite(x,y,body)
    local site=pod.playerDropSite(x,y)
    return site~=nil and math.abs(site.y-y)<=3 and pod.playerDropClear(x,y,body)
end
local function callerSite(x,y)
    local player=ctx.my_player and ctx.my_player.entity
    if not player or not EntityGetIsAlive(player) or GameHasFlagRun("ew_flag_notplayer_active") or not loaded(x,y) then return false end
    local px,py=EntityGetTransform(player)
    return (px-x)^2+(py-y)^2<=160^2 and safeSite(x,y)
end
local function fresh(challenge,stamp)
    local age=type(stamp)=="number" and GameGetFrameNum()-stamp
    return boot and challenge==boot and age and age>=0 and age<=120
end
local function episode(who,body)
    if not body then return end
    local c=tag(body,"nh_ew_reinforce_episode")
    local stamp=room.."|"..who.."|"
    local value=c and ComponentGetValue2(c,"value_string") or ""
    if value:sub(1,#stamp)==stamp and number(value:sub(#stamp+1)) then return value:sub(#stamp+1) end
    local counter=ledger..room.."."..who..".seq"
    local n=(tonumber(ModSettingGet(counter)) or 0)+1
    local serial=("%.0f"):format(n)
    if not number(serial) or not save(counter,serial) then return end
    if not c then c=EntityAddComponent2(body,"VariableStorageComponent",{_tags="nh_ew_reinforce_episode"}) end
    if c and c~=0 then
        ComponentSetValue2(c,"value_string",stamp..serial)
        if ComponentGetValue2(c,"value_string")==stamp..serial then return serial end
    end
end
local function scope(who,episodeId) return ledger..room.."."..who..".down."..episodeId end
local function hostKey(caller,tx) return ledger..room.."."..caller..".order."..tx end
local function payload(target,ep,x,y) return table.concat({target,ep,x,y},"|") end
local function result(field,own,tx,status)
    if field==world() and owner(ctx.my_id)==own and number(tx) and (status=="ok" or status=="rejected") then
        write("result."..field.."."..own.."."..tx,status)
    end
end
rpc.opts_reliable()
function rpc.result(to,field,tx,status)
    if ctx.rpc_peer_id==ctx.host_id then result(field,to,tx,status) end
end
local function answer(caller,tx,status)
    if owner(ctx.my_id)==caller then result(room,caller,tx,status) else rpc.result(caller,room,tx,status) end
end
local function confirm(peer,field,caller,tx,target,ep,x,y,status)
    if not ctx.is_host or not current(field) or not id(caller) or not number(tx) or not id(target)
        or owner(peer)~=target or not number(ep) or not position(x) or not position(y)
        or (status~="ok" and status~="rejected") then return end
    local key=hostKey(caller,tx)
    local plan=payload(target,ep,x,y)
    local winner=caller.."|"..tx
    if ModSettingGet(scope(target,ep)..".owner")~=winner then return end
    if ModSettingGet(key)==plan.."|pending" and save(key,plan.."|"..status) then
        if status=="rejected" then save(scope(target,ep)..".owner","") end
        answer(caller,tx,status)
    end
end
rpc.opts_reliable()
function rpc.confirm(...) confirm(ctx.rpc_peer_id,...) end
local function toHost(caller,tx,target,ep,x,y,status)
    if ctx.is_host then confirm(ctx.my_id,room,caller,tx,target,ep,x,y,status)
    else rpc.confirm(room,caller,tx,target,ep,x,y,status) end
end

local function restore(body,x,y)
    -- A natural kill may already be queued. An empty serialization cannot
    -- restore the original inventory, so never enter EW's destructive path.
    local dm=EntityGetFirstComponentIncludingDisabled(body,"DamageModelComponent")
    if not dm or ComponentGetValue2(dm,"hp")<=0 or GlobalsGetValue("ew_local_player_dead","")=="" then return false end
    local ok=pcall(ctx.cap.health.nh_reinforce_restore)
    local player=ctx.my_player.entity
    if not ok then
        if player==body and EntityGetIsAlive(body) and GameHasFlagRun("ew_flag_notplayer_active") then return false end
        return nil  -- EW changed bodies before failing; do not refund an ambiguous delivery.
    end
    if not player or player==body or not EntityGetIsAlive(player)
        or GameHasFlagRun("ew_flag_notplayer_active") or EntityHasTag(player,"ew_notplayer") then return false end
    local health=EntityGetFirstComponentIncludingDisabled(player,"DamageModelComponent")
    if not health then return false end
    EntitySetTransform(player,x,y)
    local motion=EntityGetFirstComponentIncludingDisabled(player,"CharacterDataComponent")
    if motion then ComponentSetValue2(motion,"mVelocity",0,0) end
    ComponentSetValue2(health,"hp",ComponentGetValue2(health,"max_hp"))
    return true
end
local function command(from,field,caller,tx,target,ep,x,y,challenge,stamp,approved)
    if from~=ctx.host_id or not current(field) or owner(ctx.my_id)~=target or not id(target)
        or not id(caller) or caller==target or not number(tx) or not number(ep) or not position(x) or not position(y)
        or not fresh(challenge,stamp) or type(approved)~="boolean" then return end
    local key=scope(target,ep)..".receipt"
    local entry=table.concat({caller,tx,x,y},"|")
    local prior=ModSettingGet(key)
    local worldReceipt=GlobalsGetValue(key,"")
    if prior==entry.."|ok" or worldReceipt==entry.."|ok" then
        if prior~=entry.."|ok" and not save(key,entry.."|ok") then return end
        local rewound=localBody()
        if rewound and episode(target,rewound)==ep and approved and (not loaded(x,y) or safeSite(x,y,rewound)) then
            restore(rewound,x,y)
        end
        toHost(caller,tx,target,ep,x,y,"ok")
        return
    end
    if prior==entry.."|uncertain" or worldReceipt==entry.."|uncertain" then return end
    if prior==entry.."|rejected" then toHost(caller,tx,target,ep,x,y,"rejected"); return end
    if prior and prior~=entry.."|pending" and not prior:match("|rejected$") then
        toHost(caller,tx,target,ep,x,y,"rejected"); return
    end
    local body=localBody()
    if not body or episode(target,body)~=ep or not approved or (loaded(x,y) and not safeSite(x,y,body)) then
        if save(key,entry.."|rejected") then toHost(caller,tx,target,ep,x,y,"rejected") end
        return
    end
    if not save(key,entry.."|pending") then return end
    local restored=restore(body,x,y)
    if restored==nil then
        GlobalsSetValue(key,entry.."|uncertain")
        save(key,entry.."|uncertain")
        return
    end
    local status=restored and "ok" or "rejected"
    -- A setting write may fail after the engine already delivered the player.
    if status=="ok" then GlobalsSetValue(key,entry.."|ok") end
    if save(key,entry.."|"..status) then toHost(caller,tx,target,ep,x,y,status) end
end
rpc.opts_reliable()
function rpc.command(...) command(ctx.rpc_peer_id,...) end
local function decide(peer,field,caller,tx,target,ep,x,y,challenge,stamp,approved)
    if not ctx.is_host or not current(field) or not id(caller) or owner(peer)~=caller or not number(tx)
        or not id(target) or target==caller or not number(ep) or not position(x) or not position(y)
        or not fresh(challenge,stamp) or type(approved)~="boolean" then return end
    local key=hostKey(caller,tx)
    local plan=payload(target,ep,x,y)
    local entry=ModSettingGet(key)
    if entry then
        local stored,status=entry:match("^(.*)|(%a+)$")
        if stored~=plan then return end
        if status=="ok" or status=="rejected" then answer(caller,tx,status); return end
    end
    local targetPeer=peerFor(target)
    local reported=targetPeer and seen[targetPeer]
    local lock=scope(target,ep)..".owner"
    local winner=ModSettingGet(lock)
    local order=caller.."|"..tx
    if winner and winner~="" and winner~=order then
        local other,otherTx=winner:match("^(%w+)|(%d+)$")
        local previous=other and ModSettingGet(hostKey(other,otherTx))
        if previous and previous:match("|rejected$") and save(lock,"") then winner="" end
    end
    if winner~=order then
        local p=ctx.players[peer]
        if targetPeer and not reported and (not winner or winner=="") then return end -- wait for first heartbeat
        if not p or not p.status or p.status.is_alive~=true or not reported
            or not approved or reported.owner~=target or reported.ep~=ep or (winner and winner~="") then
            if save(key,plan.."|rejected") then answer(caller,tx,"rejected") end
            return
        end
        if not save(key,plan.."|pending") or not save(lock,order) then return end
    end
    if not reported or reported.owner~=target then return end -- an earlier delivery/ACK may be in flight
    if targetPeer==ctx.my_id then command(ctx.host_id,room,caller,tx,target,ep,x,y,reported.boot,reported.stamp,approved)
    else rpc.command(room,caller,tx,target,ep,x,y,reported.boot,reported.stamp,approved) end
end
rpc.opts_reliable()
function rpc.request(...) decide(ctx.rpc_peer_id,...) end
local function advertise(peer,field,ep,x,y,challenge,stamp)
    if not current(field) or (ep~="" and not number(ep)) or not position(x) or not position(y)
        or type(challenge)~="string" or #challenge>60 or not challenge:match("^[%w%-]+$")
        or type(stamp)~="number" or stamp<0 or stamp~=math.floor(stamp) then return end
    local who=owner(peer)
    if who then seen[peer]={owner=who,ep=ep,x=x,y=y,at=GameGetFrameNum(),boot=challenge,stamp=stamp} end
end
rpc.opts_reliable()
function rpc.advert(...) advertise(ctx.rpc_peer_id,...) end
local function reset(nextRoom)
    room,seen,lastAdvert,lastRequest,published,lastRollback=nextRoom,{},nil,nil,nil,nil
    boot=room and (("%04d%02d%02d%02d%02d%02d"):format(GameGetDateAndTimeUTC()).."-"..math.floor(GameGetRealWorldTimeSinceStarted()*1000000))
    write("mode",""); write("targets","")
end
function M.on_world_initialized() reset(nil); lastFrame=nil end
function M.on_world_update()
    local f=GameGetFrameNum()
    if f%6~=0 then return end
    local here=world()
    if room~=here or not seen or (lastFrame and f<lastFrame) then reset(here) end
    lastFrame=f
    if not room then return end
    local me=owner(ctx.my_id)
    if not me then return end
    local body=localBody()
    local ep=episode(me,body) or ""
    -- The settings ledger may have survived a rollback to a world save that
    -- still contains this exact downed body. Reapply the paid delivery only
    -- to that body's episode; a later death has a fresh serial.
    if ep~="" and (not lastRollback or lastRollback.ep~=ep or f-lastRollback.at>=60) then
        lastRollback={ep=ep,at=f}
        local key=scope(me,ep)..".receipt"
        local entry=ModSettingGet(key) or ""
        local x,y=entry:match("^%w+|%d+|(-?%d+)|(-?%d+)|ok$")
        x,y=tonumber(x),tonumber(y)
        if position(x) and position(y) and loaded(x,y) and safeSite(x,y,body) and restore(body,x,y) then
            body,ep=nil,""
        end
    end
    if not lastAdvert or ep~=lastAdvert.ep or f-lastAdvert.at>=36 then
        local x,y=0,0
        if body then x,y=EntityGetTransform(body); x,y=math.floor(x),math.floor(y) end
        advertise(ctx.my_id,room,ep,x,y,boot,f); rpc.advert(room,ep,x,y,boot,f)
        lastAdvert={at=f,ep=ep}
    end
    local rows={}
    for peer,row in pairs(seen) do
        local p=ctx.players[peer]
        if not p or p.dc or owner(peer)~=row.owner or f-row.at>120 then seen[peer]=nil
        elseif peer~=ctx.my_id and row.ep~="" then
            local name=tostring(p.name or peer):gsub("[%c|]"," ")
            rows[#rows+1]=table.concat({row.owner,row.ep,row.x,row.y,name},"|")
        end
    end
    table.sort(rows)
    local roster=table.concat(rows,"\n")
    if published~=roster then write("targets",roster); write("mode",room); published=roster end
    local request=read("request")
    if request=="" then lastRequest=nil; return end
    if lastRequest and request==lastRequest.value and f-lastRequest.at<30 then return end
    local field,caller,tx,target,n,sx,sy=request:match("^([%w_-]+)|(%w+)|(%d+)|(%w+)|(%d+)|(-?%d+)|(-?%d+)$")
    if field~=room or caller~=me or not number(tx) or not id(target) or not number(n) then return end
    local x,y=tonumber(sx),tonumber(sy)
    if not position(x) or not position(y) or read("result."..room.."."..me.."."..tx)~="" then return end
    local host=seen[ctx.host_id]
    if not host then return end
    lastRequest={value=request,at=f}
    local approved=callerSite(x,y)
    if ctx.is_host then decide(ctx.my_id,room,me,tx,target,n,x,y,host.boot,host.stamp,approved)
    else rpc.request(room,me,tx,target,n,x,y,host.boot,host.stamp,approved) end
end
return M
