-- Whole items and fractional work are kept separately so large inventories
-- never need to be multiplied by the common fixed-point denominator.
local M={}
local scale=10000
local cycle=216000 -- divisible by every crop and animal period, in frames
local divisor=cycle*scale
local housing={livestock=true,beehive=true,dragon_nest=true,gel_pool=true,dog_kennel=true,cat_house=true}
local sources={"farm","livestock","beehive","dragon","gel_pool","dog_kennel","cat_house"}
local balances={"fiber","herb","grain","sugar","spice","active_herb","egg","milk","meat","gold","dog","cat"}
local function add(t,id,n)
    if n>0 then t[id]=(t[id] or 0)+n end
end
local function rareBook() return {counts={},private={}} end

function M.levelBonus(id,level)
    if id=="agri_equipment" then return level>0 and 400 or 0 end
    if id=="farmland" then return math.max(0,level-1)*200 end
    return housing[id] and math.max(0,level-1)*500 or 0
end

function M.bonus(state,facility,source,pet,basis)
    local amount=M.levelBonus(facility,NHStore.level(state,facility))
    if facility=="farmland" then amount=amount+M.levelBonus("agri_equipment",NHStore.level(state,"agri_equipment")) end
    if pet and NHCompanions.productionMatch(source,pet) then amount=amount+basis end
    return amount
end

local function credit(book,id,frames,workers,period,amount,basis)
    if workers==0 or frames==0 or basis==0 then return end
    local rate=workers*amount*basis
    -- First separate the whole cycles, then their whole units and fractional
    -- basis points. The partial-cycle product is bounded even on catch-up.
    local cycles=math.floor(frames/period)
    local whole=math.floor(cycles/scale)*rate
    local part=(cycles%scale)*rate
    whole=whole+math.floor(part/scale)
    local sub=(book.remainder[id] or 0)+(part%scale)*cycle+(frames%period)*(cycle/period)*rate
    add(book.open,id,whole+math.floor(sub/divisor))
    local remainder=sub%divisor
    book.remainder[id]=remainder>0 and remainder or nil
end

-- Dogs return a satchel and a backpack together. A box or pair contains
-- three vanilla 10-gold nuggets; only the percentage bonus is banked.
local function bagSpecies(species) return species=="dog" or species=="cat" end
function M.bagValue(kind)
    local gold=0
    for _,part in ipairs(kind.yields) do gold=gold+NHLootBags.types[part[1]].gold*part[2]*10 end
    return gold
end

local function herdFixed(book,species,frames,workers,bonus)
    local kind=NHLivestock.species[species]
    if bagSpecies(species) then
        credit(book,"gold",frames,workers,kind.period,M.bagValue(kind),bonus)
    else
        for _,part in ipairs(kind.yields) do
            if part[1]~="loot" then credit(book,part[1],frames,workers,kind.period,part[2],scale+bonus) end
        end
    end
end

local function privateRolls(queue,id,chance,count)
    local last=queue[#queue]
    if last and last.id==id and last.chance==chance then last.count=last.count+count
    else queue[#queue+1]={id=id,chance=chance,count=count} end
end

local function record(book,source,count,span)
    if count==0 then return end
    add(book.counts,source,count)
    if span and NHCompanions.productionMatch(source,span.id) then
        local chance=NHAffinity.incomeBasisPoints(span.points)
        if chance>0 then privateRolls(book.private,span.id,chance,count) end
    end
end

local function close(book)
    for id,amount in pairs(book.open) do add(book.owed,id,amount) end
    for id,count in pairs(book.openRare.counts) do add(book.rare.counts,id,count) end
    for _,roll in ipairs(book.openRare.private) do privateRolls(book.rare.private,roll.id,roll.chance,roll.count) end
    book.open,book.openRare={},rareBook()
end

-- Retire already-earned legacy batches at face value. Partial cycles become
-- minute credit at the historical base rate and keep their rare-roll phase.
function M.adopt(state)
    local farm=state.farm
    if farm.minuteIncome then return end
    local book={remainder={},open={},owed={},openRare=rareBook(),rare=rareBook()}
    farm.minuteIncome=book
    -- Old snapshots recorded uncollected batches, but only determined their
    -- private card chance at collection. Capture that opportunity exactly once.
    local id,_,points=NHCompanions.productionCurrent(state)
    local collector=id and {id=id,points=points}
    for id,count in pairs(farm.pending or {}) do
        add(book.owed,id,count*NHFarm.crops[id].amount)
        record(book.rare,"farm",count,collector)
    end
    farm.pending=nil
    for _,plot in pairs(farm.plots) do
        if plot.crop then
            local kind=assert(NHFarm.crops[plot.crop],"Unknown legacy crop")
            local count=math.max(0,1+math.floor((farm.time-plot.readyAt)/kind.frames))
            add(book.owed,plot.crop,count*kind.amount)
            record(book.rare,"farm",count,collector)
            plot.readyAt=plot.readyAt+count*kind.frames
            credit(book,plot.crop,math.max(0,kind.frames-(plot.readyAt-farm.time)),1,kind.frames,kind.amount,scale)
        end
    end
    for species,herd in pairs(farm.herds or {}) do
        local kind=NHLivestock.species[species]
        local source=species=="dragon_egg" and "dragon" or kind.facility or "livestock"
        record(book.rare,source,herd.owed,collector)
        if not bagSpecies(species) then
            for _,part in ipairs(kind.yields) do
                if part[1]~="loot" then add(book.owed,part[1],herd.owed*part[2]) end
            end
            herdFixed(book,species,herd.progress,1,0)
        end
        herd.owed=0
    end
end

local function segment(state,from,to,span)
    if to<=from then return end
    local farm=state.farm
    local book=farm.minuteIncome
    local pet,basis=span and span.id,span and span.basis
    local cropBonus=M.bonus(state,"farmland","farm",pet,basis)
    for _,plot in pairs(farm.plots) do
        if plot.crop then
            local kind=NHFarm.crops[plot.crop]
            credit(book,plot.crop,to-from,1,kind.frames,kind.amount,scale+cropBonus)
            if plot.readyAt<=to then
                local count=1+math.floor((to-plot.readyAt)/kind.frames)
                record(book.openRare,"farm",count,span)
                plot.readyAt=plot.readyAt+count*kind.frames
            end
        end
    end
    for _,species in ipairs(NHLivestock.order) do
        local herd=(farm.herds or {})[species]
        if herd then
            local kind=NHLivestock.species[species]
            local facility=kind.facility or "livestock"
            local source=species=="dragon_egg" and "dragon" or facility
            local bonus=M.bonus(state,facility,source,pet,basis)
            herdFixed(book,species,to-from,herd.adults,bonus)
            local progress,count,matured=NHLivestock.project(herd,kind.period,from,to)
            for i=1,matured do herdFixed(book,species,to-herd.young[i],1,bonus) end
            herd.adults=herd.adults+matured
            for i=1,matured do table.remove(herd.young,1) end
            herd.progress=progress
            record(book.openRare,source,count,span)
        end
    end
end

function M.advance(state,from,to)
    if to<=from then return end
    local cursor=from
    for _,span in ipairs(NHCompanions.productionSegments(state,from,to)) do
        segment(state,cursor,span.from)
        segment(state,span.from,span.to,span)
        cursor=span.to
    end
    segment(state,cursor,to)
end
M.close=close

local function room(state,id)
    if id=="gold" then return NHStore.maxGold-state.bankGold end
    return NHStore.maxResourceAmount-(state.resources[id] or 0)
end

-- Published profiles are immutable between transactions. Remember a failed
-- warehouse fit on that snapshot rather than making scratch rows every frame.
local blockedBags=setmetatable({},{__mode="k"})
function M.bagBlocked(state,id)
    local cache=blockedBags[state]
    local capacity=NHStore.warehouseCapacity(state,"supplies")
    if not cache or cache.revision~=state.revision or cache.rows~=state.warehouse or cache.length~=#state.warehouse
        or cache.nextId~=state.nextItemId or cache.capacity~=capacity then
        cache={revision=state.revision,rows=state.warehouse,length=#state.warehouse,nextId=state.nextItemId,capacity=capacity}
        blockedBags[state]=cache
    end
    if cache[id]==nil then cache[id]=NHLivestock.bagPayment(state,id,1)==0 end
    return cache[id]
end

function M.ready(state)
    local book=state.farm.minuteIncome
    if not book then return false end
    if next(book.rare.counts) or #book.rare.private>0 then return true end
    if not next(book.owed) then return false end
    for id in pairs(book.owed) do
        if bagSpecies(id) then
            if not M.bagBlocked(state,id) then return true end
        elseif room(state,id)>0 then return true end
    end
    return false
end

function M.pay(state)
    local book=state.farm.minuteIncome
    local rare=book.rare
    local produced,awards=false,{}
    for _,source in ipairs(sources) do
        local total=rare.counts[source] or 0
        local count=math.min(total,NHFarm.batchLimit)
        if count>0 then
            local found
            if source=="dragon" then found=NHDragonLoot.award(state,count)
            else
                if source=="gel_pool" then NHGelPool.award(state,count) end
                if source=="dog_kennel" then add(book.owed,"dog",count) end
                if source=="cat_house" then add(book.owed,"cat",count) end
                found=NHCompanions.reward(state,source,count,true)
            end
            for _,id in ipairs(found) do awards[#awards+1]=id end
            rare.counts[source]=total>count and total-count or nil
            produced=true
        end
    end
    local budget=NHFarm.batchLimit
    while budget>0 and rare.private[1] do
        local roll=rare.private[1]
        local n=math.min(roll.count,budget)
        NHCompanions.productionCardRoll(state,roll.id,roll.chance,n,awards)
        roll.count,budget=roll.count-n,budget-n
        if roll.count==0 then table.remove(rare.private,1) end
        produced=true
    end
    if budget<NHFarm.batchLimit then NHCompanions.deliver(state) end
    -- Fixed priority also keeps competing cat/dog container deliveries
    -- reproducible if only one warehouse slot becomes available.
    for _,id in ipairs(balances) do
        local owed=book.owed[id]
        if owed then
            local count
            if bagSpecies(id) then
                local delivery
                count,delivery=NHLivestock.bagPayment(state,id,owed)
                if delivery then state.warehouse,state.nextItemId=delivery.warehouse,delivery.nextItemId end
            else
                count=math.min(owed,room(state,id))
                if count>0 then
                    if id=="gold" then assert(NHStore.creditGold(state,count))
                    else state.resources[id]=(state.resources[id] or 0)+count end
                end
            end
            if count>0 then
                book.owed[id]=owed>count and owed-count or nil
                produced=true
            end
        end
    end
    return produced,awards
end

function M.validate(farm,whole)
    local book=farm.minuteIncome
    if not book then return end -- old profiles are adopted when loaded
    assert(type(book)=="table" and not farm.pending,"Invalid minute income")
    for _,field in ipairs({"remainder","open","owed"}) do
        assert(type(book[field])=="table","Invalid minute balance")
        for id,n in pairs(book[field]) do
            assert((NHFarm.crops[id] or id=="gold" or id=="egg" or id=="meat" or id=="milk"
                or field=="owed" and bagSpecies(id)) and whole(n) and n>0 and (field~="remainder" or n<divisor),
                "Invalid minute balance")
        end
    end
    for _,rare in ipairs({assert(book.openRare),assert(book.rare)}) do
        assert(type(rare.counts)=="table" and type(rare.private)=="table","Invalid minute reward schedule")
        for source,n in pairs(rare.counts) do
            local known=false
            for _,id in ipairs(sources) do if id==source then known=true end end
            assert(known and whole(n) and n>0,"Invalid earned production rolls")
        end
        local entries=0
        for i,roll in pairs(rare.private) do
            assert(whole(i) and i>=1 and i<=#rare.private and NHCompanions.species[roll.id] and whole(roll.count)
                and roll.count>0 and whole(roll.chance) and roll.chance>0 and roll.chance<=900,"Invalid companion rolls")
            entries=entries+1
        end
        assert(entries==#rare.private,"Invalid companion roll queue")
    end
end

return M
