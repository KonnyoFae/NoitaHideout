function death(damage_type,message,responsible,drop_items)
    local mob=GetUpdatedEntityID()
    if drop_items==false or EntityHasTag(mob,"player_unit") or EntityHasTag(mob,"nh_loot_paid") then return end
    EntityAddTag(mob,"nh_loot_paid")
    local x,y=EntityGetTransform(mob)
    -- Vanilla's ordinary gold payout also starts from max_hp. One engine HP is 25 displayed HP.
    local model=EntityGetFirstComponentIncludingDisabled(mob,"DamageModelComponent")
    local health=model and ComponentGetValue2(model,"max_hp") or 0
    local kind="travel_satchel"
    if health>=8 then kind="loot_case"
    elseif health>=2 then kind="travel_pack" end
    EntityLoad("mods/noita_hideout/files/items/"..kind..".xml",x,y-3)
end
