-- World origin is derived from the dock's horizontal centre and bottom edge.
-- All points below are local pixels measured from the top left of the art.
local C={
    center=260,bottom=-26400,width=500,height=356,
    material="mods/noita_hideout/files/travel/cabin_materials.png",
    background="mods/noita_hideout/files/travel/cabin_background.png",revision="2",
    infirmary={x=83,y=199},terminal={x=182,y=207},gate={x=299,y=196},
}
C.left=C.center-math.floor(C.width/2)
C.top=C.bottom-C.height
function C.point(p) return C.left+p.x,C.top+p.y end
function C.overlaps(left,top,right,bottom,padding)
    local d=padding or 0
    return right>=C.left-d and left<=C.left+C.width+d and bottom>=C.top-d and top<=C.bottom+d
end
function C.inside(x,y)
    x,y=x-C.left,y-C.top
    if x>=476 and x<=497 and y>=65 and y<=326 then return true end
    if x<10 or x>477 then return false end
    return (y>=23 and y<=96) or (y>=135 and y<=208) or (y>=254 and y<=326)
        or (x>=127 and x<=351 and y>=9 and y<=23)
        or (x>=127 and x<=353 and y>=124 and y<=135)
        or (x>=244 and x<=352 and y>=242 and y<=254)
end
return C
