local root="mods/noita_hideout/files/travel/"
local cabin=dofile(root.."cabin.lua")
local N={}
local prefix,cycle="nh_travel.",nil
local function read(key) return GlobalsGetValue(prefix..key,"") end
local function write(key,value) GlobalsSetValue(prefix..key,value) end
local function say(key) GamePrint(GameTextGetTranslatedOrNot("$nh_travel_"..key)) end
local function near(x,y,tx,ty,r) return (x-tx)^2+(y-ty)^2<=r*r end
local function here(x,y,r,tag) return (EntityGetInRadiusWithTag(x,y,r,tag) or {})[1] end
local function coords(x,y) return ("%d,%d"):format(math.floor(x),math.floor(y)) end
local terminalX,terminalY=cabin.point(cabin.terminal)
local infirmaryX,infirmaryY=cabin.point(cabin.infirmary)
-- Published 0.42.0 position, before the three decks replaced the test room.
local oldLeft,oldTop=164,-26480
local function inPrototype(x,y)
    return x>=oldLeft and x<oldLeft+192 and y>=oldTop and y<oldTop+80
end
local menu,held,startHold,latched,hint,lastMountain
local returnKeys={["10"]="G",["11"]="H",["13"]="J"}
local function returnKey()
    local key=tostring(ModSettingGet("noita_hideout.return_key") or "10")
    if not returnKeys[key] then key="10" end
    return tonumber(key),returnKeys[key]
end
local function syncWorld()
    local ng=tonumber(SessionNumbersGetValue("NEW_GAME_PLUS_COUNT")) or 0
    if cycle==ng then return end
    cycle=ng
    menu,held,startHold,latched,hint,lastMountain=nil,nil,nil,false,nil,nil
    prefix=ng==0 and "nh_travel." or ("nh_travel.ng"..ng..".")
    local oldDeck="318,-26424,"
    local gate=read("gate")
    if gate:sub(1,#oldDeck)==oldDeck then
        write("gate",coords(cabin.point(cabin.gate))..","..gate:sub(#oldDeck+1))
    end
end
function N.reset() cycle=nil; syncWorld() end
function N.inCabin(player)
    local x,y=EntityGetTransform(player)
    return cabin.inside(x,y) and read("built")==cabin.revision
end

local function ensureCabin()
    if read("built")~=cabin.revision then
        if not DoesWorldExistAt(cabin.left,cabin.top,cabin.left+cabin.width-1,cabin.bottom-1) then return false end
        local frame=GameGetFrameNum()
        local revision,attempt=read("placing"):match("^([^,]+),(%d+)$")
        local age=attempt and frame-tonumber(attempt)
        if revision~=cabin.revision or age<0 or age>=120 then
            if read("built")=="1" or revision=="1" then
                RemovePixelSceneBackgroundSprite(cabin.background,oldLeft,oldTop)
                LoadPixelScene(root.."prototype_clear.png","",oldLeft,oldTop,"",true,true,{},50,true)
                for _,id in ipairs(EntityGetInRadiusWithTag(oldLeft+100,oldTop+67,4,"nh_travel_console") or {}) do
                    EntityKill(id)
                end
            end
            if revision==cabin.revision or (read("built")~="" and read("built")~="1") then
                RemovePixelSceneBackgroundSprite(cabin.background,cabin.left,cabin.top)
            end
            LoadPixelScene(cabin.material,cabin.background,cabin.left,cabin.top,cabin.background,true,true,{},50,true)
            write("placing",cabin.revision..","..frame)
            return false
        end
        if age==0 or not RaytracePlatforms(infirmaryX,infirmaryY,infirmaryX,infirmaryY+24) then return false end
        write("built",cabin.revision)
        write("placing","")
    end
    if not DoesWorldExistAt(terminalX-8,terminalY-8,terminalX+8,terminalY+8) then return true end
    local id=here(terminalX,terminalY,4,"nh_travel_console")
    if not id then id=EntityLoad(root.."console.xml",terminalX,terminalY) end
    return id~=nil and id~=0
end

local function register(id)
    local x,y=EntityGetTransform(id)
    local pos=coords(x,y)..";"
    local routes=read("stations")
    if not (";"..routes):find(";"..pos,1,true) then
        write("stations",routes..pos)
        say("unlocked")
    end
end

local function destinations(hx,hy)
    local rows={}
    for x,y in read("stations"):gmatch("(-?%d+),(-?%d+);") do
        rows[#rows+1]={kind="mountain",x=tonumber(x),y=tonumber(y)}
    end
    table.sort(rows,function(a,b) return a.y<b.y or (a.y==b.y and a.x<b.x) end)
    table.insert(rows,1,{kind="home",x=hx,y=hy})
    return rows
end

-- Check the head, shoulders and feet on both sides of a standing player.
local function landing(x,y)
    for _,dx in ipairs({0,10,-10,20,-20,32,-32}) do
        local sx=x+dx
        local hit,_,floor=RaytracePlatforms(sx,y-8,sx,y+48)
        if hit and floor then
            local clear=true
            for side=-4,4,2 do
                if RaytraceSurfacesAndLiquiform(sx+side,floor-20,sx+side,floor-1)
                    or not RaytracePlatforms(sx+side,floor-1,sx+side,floor+4) then clear=false; break end
            end
            if clear then return sx,floor-6 end
        end
    end
end

local function move(player,x,y)
    local motion=EntityGetFirstComponentIncludingDisabled(player,"CharacterDataComponent")
    if motion then ComponentSetValue2(motion,"mVelocity",0,0) end
    EntitySetTransform(player,x,y)
end
local function protect(player)
    if not (EntityGetAllChildren(player,"nh_transit_protection") or {})[1] then
        local x,y=EntityGetTransform(player)
        local e=EntityLoad(root.."transit_protection.xml",x,y)
        if e and e~=0 then EntityAddChild(player,e) end
    end
end

local function begin(player,kind,x,y,bx,by)
    -- The player streams the destination. Save the return point before moving
    -- and hold still until the loaded material grid yields a standable floor.
    write("trip",table.concat({kind,coords(x,y),coords(bx,by),GameGetFrameNum()+240},","))
    menu=nil
    protect(player)
end
function N.rescue(player,hx,hy)
    syncWorld()
    write("gate","")
    begin(player,"rescue",infirmaryX,infirmaryY,hx,hy)
end

local function transit(player,data,frame)
    local kind,x,y,bx,by,deadline=data:match("^(%a+),(-?%d+),(-?%d+),(-?%d+),(-?%d+),(%d+)$")
    if not kind then write("trip",""); return end
    x,y,bx,by,deadline=tonumber(x),tonumber(y),tonumber(bx),tonumber(by),tonumber(deadline)
    -- A pending outbound trip from the previous version can still roll back.
    if inPrototype(bx,by) and read("built")=="1" then
        bx,by=infirmaryX,infirmaryY
        if kind=="back" then x,y=bx,by end
    end
    local inbound=kind=="ship" or kind=="rescue" or kind=="refit"
        or (kind=="back" and x==infirmaryX and y==infirmaryY)
    if inbound then x,y=infirmaryX,infirmaryY end
    protect(player)
    local loaded=DoesWorldExistAt(x-70,y-35,x+70,y+56)
    if loaded and inbound then loaded=ensureCabin() end
    if loaded and kind=="mountain" then loaded=here(x,y,4,"noita_hideout_mountain_storage")~=nil end
    if loaded then
        local tx,ty=x,y
        if kind=="home" then
            local terminal=here(x,y,128,"nh_home_terminal")
            if terminal then tx,ty=EntityGetTransform(terminal) end
        end
        if kind=="home" or kind=="mountain" then tx=tx+12 end
        local sx,sy=landing(tx,ty)
        if sx then
            move(player,sx,sy)
            write("trip","")
            if kind~="back" and kind~="refit" then write("gate","") end
            return
        end
    end
    if frame>=deadline or (loaded and kind~="back") then
        if kind=="back" then
            -- Last resort is the original stand position or known spawn point.
            move(player,bx,by)
            write("trip","")
        else
            write("exit","1")
            begin(player,"back",bx,by,bx,by)
            say(kind=="rescue" and "rescue_fallback" or "blocked")
        end
        return
    end
    move(player,x,y)
end

local function syncGate(gx,gy)
    local found
    for _,id in ipairs(EntityGetWithTag("nh_travel_gate") or {}) do
        local x,y=EntityGetTransform(id)
        if gx and x==gx and y==gy and not found then found=id else EntityKill(id) end
    end
    if gx and not found and DoesWorldExistAt(gx-8,gy-8,gx+8,gy+8) then
        found=EntityLoad(root.."gate.xml",gx,gy)
    end
    return found and found~=0
end

local function openGate(gx,gy,kind,x,y,mustLeave)
    gx,gy=math.floor(gx),math.floor(gy)
    if not syncGate(gx,gy) then say("blocked"); return end
    write("gate",table.concat({coords(gx,gy),kind,coords(x,y)},","))
    write("exit",mustLeave and "1" or "")
    say("gate_ready")
end

function N.choose(index)
    local row=menu and menu.rows[index]
    if not row then return end
    local gx,gy=cabin.point(cabin.gate)
    openGate(gx,gy,row.kind,row.x,row.y)
    menu=nil
end

local function returnGate(player,terminal)
    local x,y=EntityGetTransform(player)
    local tx=EntityGetTransform(terminal)
    local side=x<tx and -1 or 1
    local gx,gy=landing(x+side*27,y)
    if not gx then gx,gy=landing(x-side*27,y) end
    if not gx then say("blocked"); return end
    openGate(gx,gy-3,"ship",infirmaryX,infirmaryY,near(x,y,gx,gy-3,12))
end

function N.update(player,hx,hy,blocked)
    local frame=GameGetFrameNum()
    if not cycle or frame%60==0 then syncWorld() end
    hint=nil
    local trip=read("trip")
    if trip~="" then
        transit(player,trip,frame)
        hint={transit=true}
        return
    end
    local x,y=EntityGetTransform(player)
    if frame%15==0 and cabin.overlaps(x,y,x,y,240) then
        if (read("built")=="1" or read("placing"):match("^1,")) and inPrototype(x,y) then
            begin(player,"refit",infirmaryX,infirmaryY,hx,hy)
            return
        end
        ensureCabin()
    end
    local data=read("gate")
    local gx,gy,kind,tx,ty=data:match("^(-?%d+),(-?%d+),(%a+),(-?%d+),(-?%d+)$")
    gx,gy=tonumber(gx),tonumber(gy)
    if frame%15==0 then syncGate(gx,gy) end
    if gx then
        if not near(x,y,gx,gy,12) then
            if read("exit")=="1" then write("exit","") end
        elseif not blocked and read("exit")=="" and here(gx,gy,2,"nh_travel_gate") then
            begin(player,kind,tonumber(tx),tonumber(ty),x,y)
            return
        end
    end
    local mountain=here(x,y,48,"noita_hideout_mountain_storage")
    if mountain~=lastMountain then
        if mountain then register(mountain) end
        lastMountain=mountain
    end
    local request=tonumber(GlobalsGetValue("nh_travel.console_request",""))
    if request then GlobalsSetValue("nh_travel.console_request","") end
    if blocked then menu,held,startHold=nil,nil,nil; return end
    if near(x,y,terminalX,terminalY,36) and N.inCabin(player) then
        if request and math.abs(request-frame)<=1 and hx and hy then
            menu={rows=destinations(hx,hy),selected=1}
        end
    else menu=nil end
    if menu then
        if InputIsKeyJustDown(41) then menu=nil
        elseif InputIsKeyJustDown(75) or InputIsKeyJustDown(82) then menu.selected=math.max(1,menu.selected-1)
        elseif InputIsKeyJustDown(78) or InputIsKeyJustDown(81) then menu.selected=math.min(#menu.rows,menu.selected+1)
        elseif InputIsKeyJustDown(40) then N.choose(menu.selected) end
    end
    local terminal=mountain or here(x,y,48,"nh_home_terminal") or here(x,y,48,"nh_remote_station")
    if not terminal then held,startHold,latched=nil,nil,false; return end
    local key,label=returnKey()
    hint={key=label}
    local down=InputIsKeyDown(key) and not InputIsKeyDown(224)
    if not down then latched=false end
    if not terminal or not down or latched then held,startHold=nil,nil; return end
    if held~=terminal then held,startHold=terminal,frame end
    hint.percent=math.min(100,math.floor((frame-startHold)*100/36))
    if frame-startHold>=36 then
        latched=true
        returnGate(player,terminal)
    end
end
function N.view() return menu or hint end
return N
