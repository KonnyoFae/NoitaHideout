local M = {types = {}, offers = {}, stackLimit = 8}
local items = "mods/noita_hideout/files/items/"

M.recipes={
    {id="refine_red_mercury",category="alchemy",alchemyMode="decomposition",zh="分馏红水银",en="Distill red mercury",
        inputs={},resources={nh_red_mercury=1},materials={midas=2},resourceYield={nh_elixir_of_immortality=2},count=4,durationFrames=60},
    {id="refine_mana_arcane",category="alchemy",alchemyMode="decomposition",zh="晶化法力制奥术碎片",en="Crystallized mana to arcane scrap",
        inputs={},resources={nh_crystallized_mana=1},resourceYield={arcane_scrap=3},count=3,durationFrames=60},
    {id="refine_mana_container",category="alchemy",alchemyMode="decomposition",zh="晶化法力制容器碎片",en="Crystallized mana to container scrap",
        inputs={},resources={nh_crystallized_mana=1},resourceYield={container_scrap=1},count=1,durationFrames=60},
}

local function define(kind, zh, en, units, oil)
    M.types[kind] = {zh=zh, en=en, icon=items..kind..".png",units=units,saleGold=500*units,
        resource=oil and "nh_red_mercury" or "nh_crystallized_mana"}
    local function offer(action, zhVerb, enVerb, yield)
        M.offers[#M.offers+1] = {
            id=kind.."_"..action, category="storm_products", input=kind, yield=yield,
            zh=zh.." · "..zhVerb, en=en.." / "..enVerb, quantity=1,
        }
    end
    local function process(action,zhVerb,enVerb,recipe)
        local yield={}
        for key,n in pairs(recipe.materials or {}) do yield[key]=n*units end
        for key,n in pairs(recipe.resourceYield) do yield[key]=n*units end
        offer(action,zhVerb,enVerb,yield)
    end
    if oil then process("distill","分馏","Distill",M.recipes[1])
    else
        process("arcane","奥术碎片","Arcane scrap",M.recipes[2])
        process("container","容器碎片","Container scrap",M.recipes[3])
    end
    offer("sell","出售","Sell",{gold=M.types[kind].saleGold})
end

define("storm_mercury","罐装红水银","Canned red mercury",1,true)
define("storm_mercury_pressure","高压红水银","Pressurized red mercury",50,true)
define("storm_mana","法力晶块","Mana shard",1,false)
define("storm_mana_pure","高纯晶块","Pure mana shard",50,false)

-- Pre-stack warehouse records omit count. Old physical items use Noita's -1.
function M.count(n)
    if n==nil then return 1 end
    if type(n)=="number" and n>=1 and n<=M.stackLimit and n==math.floor(n) then return n end
end

function M.worldCount(item)
    if not item then return end
    local n=ComponentGetValue2(item,"uses_remaining")
    if n==-1 then return 1 end
    return M.count(n)
end

function M.refreshLegacyItems(player)
    for kind,product in pairs(M.types) do
        for _,e in ipairs(EntityGetWithTag(kind) or {}) do
            local item=EntityGetFirstComponentIncludingDisabled(e,"ItemComponent")
            local icon=item and ComponentGetValue2(item,"ui_sprite")
            if icon=="data/items_gfx/canister.png" or icon=="data/items_gfx/waterstone.png" or icon=="data/items_gfx/thunderstone.png" then
                local sprite=EntityGetFirstComponentIncludingDisabled(e,"SpriteComponent","enabled_in_hand")
                if sprite then
                    ComponentSetValue2(sprite,"offset_x",8)
                    ComponentSetValue2(sprite,"offset_y",8)
                end
                NHNative.refreshArt(e,item,product.icon)
                local uses=ComponentGetValue2(item,"uses_remaining")
                if uses==nil or uses==-1 then ComponentSetValue2(item,"uses_remaining",1) end
                EntityAddComponent2(e,"LuaComponent",{script_item_picked_up="mods/noita_hideout/files/bag_pickup.lua",execute_every_n_frame=-1})
                if EntityGetRootEntity(e)==player then
                    EntityAddTag(e,"nh_merge_pickup")
                    EntityAddTag(player,"nh_has_merge_pickup")
                end
            end
        end
    end
end

function M.register()
    for kind, def in pairs(M.types) do
        local id, product = kind, def
        NHTransfers.registerItem(id,function(e) return EntityHasTag(e,id) end,{
            warehouseCategory="supplies",
            capture=function(e)
                if EntityGetFirstComponentIncludingDisabled(e,"ItemCostComponent") then return nil,"Item unavailable." end
                local count=M.worldCount(EntityGetFirstComponentIncludingDisabled(e,"ItemComponent"))
                if not count then return nil,"Invalid storm product stack." end
                return {kind=id, count=count, name=product.zh, icon=product.icon}
            end,
            restore=function(record,x,y)
                local count=M.count(record.count)
                if not count then return nil,"Invalid storm product stack." end
                local e=EntityLoad(items..id..".xml",x,y)
                if not e or e==0 then return end
                local item=EntityGetFirstComponentIncludingDisabled(e,"ItemComponent")
                if not item then EntityKill(e); return end
                ComponentSetValue2(item,"uses_remaining",count)
                return e
            end,
        })
    end
end

function M.check(state, offer)
    local index
    for i,row in ipairs(state.warehouse) do
        if row.item.kind==offer.input then index=i; break end
    end
    local product=M.types[offer.input]
    if not index and (state.resources[product.resource] or 0)<product.units then return false,"Store this storm product first." end
    for key,n in pairs(offer.yield) do
        if key=="gold" then
            if n>NHStore.maxGold-state.bankGold then return false,"Piggy bank is full." end
        elseif key=="midas" then
            if not NHStore.canStockMaterials(state,{midas=n}) then return false,"Material storage is full." end
        elseif n>NHStore.maxResourceAmount-(state.resources[key] or 0)-
            (state.order and state.order.output.resources and state.order.output.resources[key] or 0) then
            return false,"Resource storage is full."
        end
    end
    return true,index
end

function M.exchange(state,offer,index)
    for key,n in pairs(offer.yield) do
        if key=="gold" then
            local ok,err=NHStore.creditGold(state,n)
            if not ok then return false,err end
        elseif key=="midas" then state.materials.midas=(state.materials.midas or 0)+n
        else state.resources[key]=(state.resources[key] or 0)+n end
    end
    if index then
        local item=state.warehouse[index].item
        if (item.count or 1)>1 then item.count=item.count-1 else table.remove(state.warehouse,index) end
    else
        local product=M.types[offer.input]
        NHStore.deductStock(state.resources,{[product.resource]=product.units})
    end
    return true
end

return M
