local M={}

function M.canAffect(entity,multiplayer)
    if EntityGetRootEntity(entity)~=entity or EntityHasTag(entity,"player_unit")
        or EntityHasTag(entity,"polymorphed_player") or EntityHasTag(entity,"ew_peer")
        or EntityHasTag(entity,"ew_client") or EntityHasTag(entity,"ew_notplayer")
        or EntityHasTag(entity,"nh_ew_waiting") or EntityHasTag(entity,"nh_hourglass_field")
        or EntityHasTag(entity,"nh_duster_field")
        or EntityGetFirstComponentIncludingDisabled(entity,"VariableStorageComponent","nh_ew_deposit_lock") then return false end
    local tracked=EntityHasTag(entity,"ew_des")
    if multiplayer or tracked then
        dofile_once("mods/noita_hideout/files/ew_items.lua")
        local gid,invalid,owned=NHEWItems.gid(entity)
        if gid then return owned==true end
        if invalid or tracked then return false end
    end
    return true
end

return M
