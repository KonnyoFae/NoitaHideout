-- Each released collectible has a stable id, its physical entity file, and
-- the complete warehouse item record accepted by that entity's storage codec.
-- Those two representations describe the same reward in combat and at home.
local path="mods/noita_hideout/files/items/"
local function collectible(id,zh,en,noteZh,noteEn,tarot,companion)
    return {id=id,file=path..id..".xml",zh=zh,en=en,noteZh=noteZh,noteEn=noteEn,tarot=tarot,companion=companion,
        item={kind=id,remaining=90,name="$nh_hideout_"..id,icon=path..id..".png"}}
end
return {
    collectible("salvage_bell","打捞钟","Salvage Bell",
        "手持时按射击键（默认左键），将附近战利品袋召到身边。接下来 15 分钟提高击杀掉落。",
        "Fire while held to draw nearby loot bags to you and improve kill drops for 15 minutes.","tarot_moon","cat"),
    collectible("rewind_watch","倒流表","Rewind Watch",
        "手持时按射击键设置 60 秒锚点。首次受击会挡下伤害并获得 5 秒无敌，随后闪回并恢复原装备的弹药和护盾。未受击则自然结束。",
        "Fire while held to set a 60-second anchor. The first hit is blocked and grants 5 seconds of invulnerability. Then blink back and rewind your original ammo and shield. The anchor expires if unused.","tarot_hermit","dryad"),
    collectible("stasis_hourglass","静滞沙漏","Stasis Hourglass",
        "手持时按射击键，在原地展开持续 30 秒的静滞领域。敌人、投射物及独立物理块停下，玩家可自由行动。水、沙和火仍照常流动。",
        "Fire while held to suspend enemies, projectiles and loose physics bodies around this spot for 30 seconds. Players move freely. Water, sand and fire continue to flow.","tarot_tower","slime"),
    collectible("dustless_duster","无尘掸帚","Dustless Duster",
        "手持时按射击键，展开持续 60 秒的随身领域，将松散材料、敌人、投射物和地面物品向外推开。岩层和地板保持原状。",
        "Fire while held to repel loose materials, enemies, projectiles and dropped items around you for 60 seconds. Solid terrain stays in place.","tarot_chariot","griffin"),
}
