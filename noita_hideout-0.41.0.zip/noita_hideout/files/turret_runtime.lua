local root="mods/noita_hideout/files/"
local T=NHTurrets or dofile(root.."turrets.lua")
local R={}
local function components(id,kind) return EntityGetComponentIncludingDisabled(id,kind) or {} end
local function removeAll(id,kind)
    for _,c in ipairs(components(id,kind)) do EntityRemoveComponent(id,c) end
end
local function discard(id)
    removeAll(id,"ExplodeOnDamageComponent")
    removeAll(id,"LuaComponent")
    EntityKill(id)
end
-- Ground within 64 pixels of the player, with room for the full tank silhouette.
function R.preview(player,kind)
    local px,py=EntityGetTransform(player)
    local dx,dy=NHProducts.aim(player)
    if not dx then return end
    local x,y=px+dx*28,py+dy*16
    local hit,_,ground=RaytracePlatforms(x,y-8,x,y+40)
    local valid=hit and ground~=nil and (x-px)^2+(ground-py)^2<=64^2
    y=hit and ground and ground-5 or y
    local view={x=x,y=y,kind=kind,valid=false}
    if not valid or RaytracePlatforms(px,py,x,y-6) then return view end
    for offset=-10,10,5 do
        if RaytracePlatforms(x+offset,y-16,x+offset,y+3) then return view end
    end
    for offset=-16,3,3 do
        if RaytracePlatforms(x-10,y+offset,x+10,y+offset) then return view end
    end
    if #(EntityGetInRadiusWithTag(x,y,22,"nh_deployed_turret") or {})>0 then return view end
    view.valid=true
    return view
end
function R.position(player)
    local p=R.preview(player)
    if p and p.valid then return p.x,p.y end
end
function R.heldPreview(player)
    local held=NHNative.held(player)
    if not held then return end
    for _,kind in ipairs(T.order) do
        if EntityHasTag(held,"noita_hideout_"..kind) then return R.preview(player,kind) end
    end
end
function R.deploy(player,kind,pay)
    local d=T.types[kind]
    if not d then return end
    local x,y=R.position(player)
    if not x then
        if GamePrint then GamePrint("$nh_turret_no_ground") end
        return
    end
    local turret=EntityLoad(root.."turrets/"..kind..".xml",x,y)
    if not turret or turret==0 then return end
    local genome=EntityGetFirstComponentIncludingDisabled(turret,"GenomeDataComponent")
    local playerGenome=EntityGetFirstComponentIncludingDisabled(player,"GenomeDataComponent")
    local ai=EntityGetFirstComponentIncludingDisabled(turret,"AnimalAIComponent")
    local attacks=components(turret,"AIAttackComponent")
    if not genome or not playerGenome or not ai or #attacks==0 then discard(turret); return end
    ComponentSetValue2(genome,"herd_id",ComponentGetValue2(playerGenome,"herd_id"))
    ComponentSetValue2(ai,"dont_counter_attack_own_herd",true)
    ComponentSetValue2(ai,"creature_detection_range_x",260)
    ComponentSetValue2(ai,"creature_detection_range_y",260)
    ComponentSetValue2(ai,"attack_ranged_max_distance",260)
    local attack=attacks[1]
    for i=2,#attacks do EntityRemoveComponent(turret,attacks[i]) end
    local rocket=kind=="rocket_turret_pack"
    ComponentSetValue2(attack,"attack_ranged_entity_file",root.."turrets/"..(rocket and "rocket" or "bullet")..".xml")
    ComponentSetValue2(attack,"min_distance",rocket and 40 or 12)
    ComponentSetValue2(attack,"max_distance",260)
    ComponentSetValue2(attack,"frames_between",rocket and 90 or 15)
    ComponentSetValue2(attack,"frames_between_global",rocket and 90 or 15)
    ComponentSetValue2(attack,"angular_range_deg",90)
    -- Launch outside this turret's shield, whose radius is 22.
    if kind=="shield_turret_pack" then ComponentSetValue2(attack,"attack_ranged_offset_x",27) end
    removeAll(turret,"CameraBoundComponent")
    removeAll(turret,"ItemChestComponent")
    removeAll(turret,"ExplodeOnDamageComponent")
    -- Keep the existing bag death hook; remove the native cash payout.
    for _,c in ipairs(components(turret,"LuaComponent")) do
        if ComponentGetValue2(c,"script_death")=="data/scripts/items/drop_money.lua" then EntityRemoveComponent(turret,c) end
    end
    if not EntityGetFirstComponentIncludingDisabled(turret,"LuaComponent","nh_bag_drop") then
        EntityAddComponent2(turret,"LuaComponent",{_tags="nh_bag_drop",script_death=root.."enemy_loot.lua",execute_every_n_frame=-1})
    end
    if not pay() then discard(turret); return end
    return true
end
return R
