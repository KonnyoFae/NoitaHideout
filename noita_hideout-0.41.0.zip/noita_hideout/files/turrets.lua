local root="mods/noita_hideout/files/"
local T={order={"turret_pack","rocket_turret_pack","shield_turret_pack"},types={}}
local defs={
    {"turret_pack","机枪炮塔部署包","Machinegun turret pack","tank",nil},
    {"rocket_turret_pack","导弹炮塔部署包","Rocket turret pack","tank_rocket","essence_high_energy"},
    {"shield_turret_pack","护盾炮塔部署包","Shield turret pack","tank","essence_force"},
}
for _,row in ipairs(defs) do
    local kind,zh,en,base,essence=unpack(row)
    T.types[kind]={zh=zh,en=en,base=base,essence=essence,
        icon=root.."items/"..kind..".png",
        noteZh="手持左键部署在附近地面，每包一座，不可回收。无限弹药，持续至被摧毁。"..(essence=="essence_force" and "机枪附带防弹护盾。" or ""),
        noteEn="Left-click while held to deploy on nearby ground. One turret per pack. No recall. Unlimited ammo; lasts until destroyed."..(essence=="essence_force" and " Machinegun with a projectile shield." or "")}
end
function T.validCount(n) return type(n)=="number" and n>=1 and n<=4 and n==math.floor(n) end
function T.recipe(kind)
    local d=T.types[kind]
    local resources={arcane_scrap=1}
    if d.essence then resources[d.essence]=1 end
    return {id=kind,zh=d.zh,en=d.en,category="weapons",facility="grenade",
        durationFrames=600,inputs={},resources=resources,goldCost=200,count=4,
        item={kind=kind,name="$nh_hideout_"..kind,icon=d.icon,count=4},
        noteZh=d.noteZh,noteEn=d.noteEn}
end
return T
