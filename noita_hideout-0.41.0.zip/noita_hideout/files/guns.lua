local root="mods/noita_hideout/files/"
local G={
    derringer={zh="迪林杰手枪",en="Derringer",capacity=4,speed=680,powder=10,gold=10,seconds=8,
        noteZh="手持时左键逐发射击。预装4发，用尽后消耗。",noteEn="Left-click while held. Four shots per disposable pistol."},
    flare_gun={zh="信号枪",en="Flare gun",capacity=1,speed=410,powder=5,gold=5,seconds=5,
        noteZh="手持时左键发射一枚信号弹，致盲并点燃附近敌人。",noteEn="Left-click while held. One flare blinds and ignites nearby enemies."}
}
local function tube(zh,en,projectile,effectZh,effectEn)
    return {zh=zh,en=en,isTube=true,capacity=6,speed=280,seconds=10,projectile=projectile,
        noteZh="预装6发。手持时每次左键发射一发，"..effectZh.."。",noteEn="Six charges. Left-click while held. "..effectEn}
end
G.magic_tube=tube("魔弹发射管","Magic spell tube","data/entities/projectiles/deck/grenade_small.xml","引发小型爆炸","Fires a small magic explosion.")
G.fire_tube=tube("火焰发射管","Fire spell tube",root.."projectiles/fire_grenade.xml","范围灼烧并点燃敌人","Burns and ignites nearby enemies.")
G.frost_tube=tube("冰冻发射管","Frost spell tube",root.."projectiles/frost_grenade.xml","造成冰伤并短暂冻结","Deals ice damage and briefly freezes enemies.")
G.shock_tube=tube("雷电发射管","Shock spell tube",root.."projectiles/shock_grenade.xml","造成电伤并短暂麻痹","Deals electric damage and briefly stuns enemies.")
local function supportGun(zh,en,capacity,speed,interval,charge,file,flash,noteZh,noteEn)
    return {zh=zh,en=en,capacity=capacity,speed=speed,interval=interval,charge=charge,projectile=file,
        muzzle=root.."muzzle_flashes/"..flash..".xml",noteZh=noteZh.."。用尽后消耗。",noteEn=noteEn.." Disposable."}
end
G.heavy_mg=supportGun("重机枪","Heavy machine gun",320,1080,5,nil,root.."projectiles/support_mg.xml","mg",
    "按住左键发射高速曳光弹，预装320发","Hold for sustained tracer fire. 320 rounds.")
G.auto_grenade=supportGun("连发榴弹发射器","Automatic grenade launcher",36,660,15,nil,root.."projectiles/support_grenade.xml","grenade",
    "按住左键连射低弧线碰炸榴弹，预装36发","Hold to fire low-arc impact grenades. 36 rounds.")
G.missile_launcher=supportGun("导弹发射器","Missile launcher",12,290,nil,nil,root.."projectiles/support_missile.xml","missile",
    "追踪弹命中后沿来向继续等离子切割，预装12发","Homing missiles cut forward with plasma on impact. 12 rounds.")
G.railgun=supportGun("轨道炮","Railgun",5,1800,nil,36,root.."projectiles/support_rail.xml","rail",
    "按住左键蓄力，发射可贯穿敌人和薄层地形的重弹，预装5发","Hold to charge a shot that punches through enemies and thin terrain. 5 rounds.")
G.heavy_plasma=supportGun("重等离子炮","Heavy plasma cannon",24,430,14,nil,root.."projectiles/support_plasma.xml","plasma",
    "按住左键连射等离子弹，命中点向八个方向射出短等离子切割束，预装24发","Hold to fire plasma bolts. Each impact sends eight short plasma cutters outwards. 24 rounds.")
G.bfg=supportGun("BFG","BFG",4,145,nil,nil,root.."projectiles/support_bfg.xml","bfg",
    "慢速光球向沿途敌人释放电弧，命中后爆发，预装4发","The slow orb arcs to nearby enemies and bursts on impact. Four shots.")
for kind,gun in pairs(G) do gun.projectile=gun.projectile or root.."projectiles/"..kind..".xml" end
local M={types=G}
-- A hold belongs to the item that received the initial press. UI capture or
-- switching items cancels the charge and cannot start an automatic burst.
local triggerItem,nextShot
-- Brief sparks converge around the held weapon. No effect entity survives a cancelled charge.
local function chargeSparks(item,remaining)
    if remaining%4~=0 then return end
    local x,y=EntityGetTransform(item)
    local radius=2+remaining*0.22
    local angle=remaining*0.3
    for i=1,3 do
        local dx,dy=math.cos(angle)*radius,math.sin(angle)*radius
        GameCreateCosmeticParticle("spark_blue",x+dx,y+dy,1,-dx*10,-dy*10,0,0.09,0.12,true,true,false,false,0,0)
        angle=angle+2*math.pi/3
    end
end
function M.trigger(item,edge,frame)
    if edge then triggerItem,nextShot=item,frame
    elseif not item or item~=triggerItem then triggerItem=nil end
    if not item or item~=triggerItem then return end
    if EntityHasTag(item,"nh_support_weapon") then
        for kind,gun in pairs(G) do
            if EntityHasTag(item,"noita_hideout_"..kind) then
                if edge and gun.charge then nextShot=frame+gun.charge end
                if frame<nextShot then
                    if gun.charge then chargeSparks(item,nextShot-frame) end
                    return
                end
                if gun.interval then nextShot=frame+gun.interval else triggerItem=nil end
                return item
            end
        end
    end
    if edge then return item end
end
function M.canCombine(gun,a,b)
    local fullA,fullB=a==gun.capacity,b==gun.capacity
    return (fullA and fullB) or (gun.isTube and (fullA or fullB))
end
function M.recipe(kind,id,inputs,resources,count,zh,en)
    local g=G[kind]
    return {id=id or kind,zh=zh or g.zh,en=en or g.en,category="weapons",facility="grenade",durationFrames=g.seconds*60,
        count=count or 1,goldCost=g.gold,inputs=inputs or {{name="gunpowder",amount=g.powder}},resources=resources or (kind=="flare_gun" and {fiber=2} or nil),
        item={kind=kind,name="$nh_hideout_"..kind,icon=root.."items/"..kind..".png",remaining=g.capacity,count=count or 1},
        noteZh=g.noteZh,noteEn=g.noteEn}
end
-- One open gun at the front of the stack. All later guns are fully loaded.
function M.rounds(item)
    local capacity=G[item.kind].capacity
    local remaining,count=item.remaining,item.count or 1
    if not NHStore.validBandageCount(count) or not NHStore.validBandageCount(remaining) or remaining>capacity then return end
    local rounds=(count-1)*capacity+remaining
    if rounds<=2147483647 then return rounds end
end
function M.unpack(item,rounds)
    local capacity=G[item.kind].capacity
    item.count=math.ceil(rounds/capacity)
    item.remaining=(rounds-1)%capacity+1
end
return M
