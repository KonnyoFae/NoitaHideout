local staff={}
local root="mods/noita_hideout/files/"
local dragonAttack=dofile(root.."companions/dragon_attack.lua")
local formRoot=root.."staff_forms/"
local forms={}
local started,level,wasDown,swing

local function unstableForm(path)
    local name=path and path:match("([^/]+)%.xml$")
    return name=="acidshooter" or name=="acidshooter_weak"
end

local pool={}
local herds={}
local function herdOf(path,seen)
    if herds[path]~=nil then return herds[path] end
    if seen[path] then return false end
    seen[path]=true
    local xml=(ModTextFileGetContent(path) or ""):gsub("<!%-%-.-%-%->","")
    local herd=xml:match('<GenomeDataComponent%s[^>]-herd_id="([^"]+)"')
    if not herd then
        local base=xml:match('<Base%s+file="(data/entities/[%w_/]+%.xml)"')
        if base then herd=herdOf(base,seen) end
    end
    herds[path]=herd or false
    return herds[path]
end

function staff.register()
    forms,pool,herds={},{},{}
    for _,path in ipairs(PolymorphTableGet(false) or {}) do
        local name=path:match("^data/entities/animals/([%w_/]+)%.xml$")
        if name and not forms[path] and not unstableForm(path) and not name:find("boss",1,true)
            and not name:find("necromancer_shop",1,true) and not name:find("illusions/",1,true) then
            local xml=ModTextFileGetContent(path)
            local tags=xml and xml:match('<Entity%s[^>]-tags="([^"]*)"') or ""
            if xml and xml~="" and not (","..tags..","):find(",boss,",1,true) and not xml:find("$animal_acidshooter",1,true) and not xml:find("/acidshooter",1,true) then
                forms[path]=formRoot..name.."_effect.xml"
                ModTextFileSetContent(forms[path],'<Entity><Base file="data/entities/misc/effect_polymorph.xml"><GameEffectComponent _tags="nh_staff_mimic" frames="3600" polymorph_target="'..path..'" /></Base></Entity>')
                pool[#pool+1]={path=path,name=name:match("([^/]+)$"),herd=herdOf(path,{})}
            end
        end
    end
    table.sort(pool,function(left,right) return left.path<right.path end)
end

local function resolveForm(player,id)
    local path=EntityGetFilename(id) or ""
    local name=path:match("([^/]+)%.xml$") or ""
    local species=EntityGetName(id) or ""
    local acid=unstableForm(path) or species=="$animal_acidshooter"
    local boss=EntityHasTag(id,"boss") or path:find("boss",1,true) or species:find("boss",1,true)
    local special=acid or boss
        or not EntityHasTag(id,"enemy") or EntityHasTag(id,"nh_reinforcement") or EntityHasTag(id,"noita_hideout_companion")
        or EntityHasTag(id,"nh_deployed_turret") or EntityGetHerdRelationSafe(player,id)>=40 or GameGetGameEffectCount(id,"CHARM")>0
    if not special and forms[path] then return forms[path] end
    local genome=EntityGetFirstComponentIncludingDisabled(id,"GenomeDataComponent")
    local herd=genome and HerdIdToString(ComponentGetValue2(genome,"herd_id"))
    local family=name:match("^([^_]+)_")
    local mechanical=EntityHasTag(id,"nh_deployed_turret") or EntityHasTag(id,"nh_reinforcement")
    local preferred=acid and "slimeshooter" or mechanical and "roboguard"
    local best,score
    for _,candidate in ipairs(pool) do
        local rank
        if acid and preferred==candidate.name then rank=5
        elseif candidate.name==name or species=="$animal_"..candidate.name then rank=4
        elseif family and candidate.name:match("^([^_]+)_")==family then rank=3
        elseif preferred==candidate.name or (herd and herd~="-1" and candidate.herd==herd) or (mechanical and candidate.herd=="robot") then rank=2 end
        if rank and not (boss and candidate.path==path) and (not score or rank>score) then best,score=candidate,rank end
    end
    if best then return forms[best.path],best.name end
end

function staff.reset() started,level,wasDown,swing=nil,0,false,nil end
staff.reset()

function staff.guardMimic(body)
    if not body or not EntityGetFirstComponentIncludingDisabled(body,"DamageModelComponent") then return false end
    local effect=GameGetGameEffect(body,"POLYMORPH")
    if not effect or effect==0 then return false end
    if not ComponentHasTag(effect,"nh_staff_mimic") then
        local target=ComponentGetValue2(effect,"polymorph_target") or ""
        if target:sub(1,#formRoot)~=formRoot then return false end
    end
    if EntityHasTag(body,"nh_staff_mimic_hit") then
        local frames=ComponentGetValue2(effect,"frames")
        if frames>1 or frames<0 then ComponentSetValue2(effect,"frames",1) end
    elseif not EntityGetFirstComponentIncludingDisabled(body,"LuaComponent","nh_staff_mimic_guard") then
        EntityAddComponent2(body,"LuaComponent",{_tags="nh_staff_mimic_guard",execute_every_n_frame=-1,
            script_damage_about_to_be_received=root.."staff_mimic_damage.lua"})
        print("[noita_hideout] mimic active: "..EntityGetFilename(body))
    end
    return true,not EntityHasTag(body,"nh_staff_mimic_hit") and ComponentGetValue2(effect,"frames") or nil
end

local function hostile(player,id)
    return id~=player and EntityHasTag(id,"enemy") and not EntityHasTag(id,"nh_reinforcement")
        and not EntityHasTag(id,"noita_hideout_companion") and not EntityHasTag(id,"nh_deployed_turret")
        and EntityGetHerdRelationSafe(player,id)<40
end

local function push(id,dx,dy,speed)
    local body=EntityGetFirstComponent(id,"PhysicsBodyComponent") or EntityGetFirstComponent(id,"PhysicsBody2Component")
    if body then PhysicsApplyForce(id,dx*speed,dy*speed) end
    local motion=EntityGetFirstComponent(id,"CharacterDataComponent") or EntityGetFirstComponent(id,"VelocityComponent")
    if motion then
        local vx,vy=ComponentGetValue2(motion,"mVelocity")
        local impulse=math.max(0,speed-vx*dx-vy*dy)
        ComponentSetValue2(motion,"mVelocity",vx+dx*impulse,vy+dy*impulse)
    end
end

local function affectArea(player,x,y,dx,dy,stroke,halfStep)
    local radius=stroke and (13+18*stroke.charge+2+stroke.charge) or 80
    for _,id in ipairs(EntityGetInRadius(x,y,radius) or {}) do
        if id~=player and EntityGetRootEntity(id)==id and not (stroke and stroke.hit[id]) then
            local enemy=hostile(player,id)
            local projectile=EntityHasTag(id,"projectile")
            local object=not EntityHasTag(id,"enemy") and not EntityHasTag(id,"nh_reinforcement") and not EntityHasTag(id,"nh_deployed_turret")
                and not EntityHasTag(id,"noita_hideout_companion") and not EntityGetFirstComponent(id,"GenomeDataComponent") and (EntityGetFirstComponent(id,"PhysicsBodyComponent")
                or EntityGetFirstComponent(id,"PhysicsBody2Component") or EntityGetFirstComponent(id,"ItemComponent"))
            if enemy or object or (not stroke and projectile) then
                local tx,ty=EntityGetTransform(id)
                local ax,ay=tx-x,ty-y
                local dist=math.sqrt(ax*ax+ay*ay)
                local nx,ny=dx,dy
                if dist>0.01 then nx,ny=ax/dist,ay/dist end
                if (not stroke or dx*nx+dy*ny>=math.cos(halfStep+math.asin(math.min(1,(2+stroke.charge)/math.max(1,dist)))))
                    and not RaytracePlatforms(x,y,tx,ty) then
                    if stroke then
                        stroke.hit[id]=true
                        push(id,dx,dy,170+50*stroke.charge)
                        if enemy or (object and EntityGetFirstComponent(id,"DamageModelComponent")) then
                            EntityInflictDamage(id,1,"DAMAGE_MELEE","$nh_hideout_battle_staff","NORMAL",dx*80,dy*80,player,tx,ty)
                        end
                    else push(id,nx,ny,340) end
                end
            end
        end
    end
end

local poseStep=2*math.pi/64
local function pose(gun,clock,angle,frame)
    local x,y,rotation=EntityGetTransform(gun)
    local sprite=EntityGetFirstComponent(gun,"SpriteComponent","enabled_in_hand")
    if not sprite then return x,y,angle end
    -- Undo the native item's rotation and flips to select a frame in sprite space.
    local signX=ComponentGetValue2(sprite,"special_scale_x")<0 and -1 or 1
    local signY=ComponentGetValue2(sprite,"special_scale_y")<0 and -1 or 1
    local relative=angle-rotation
    local localAngle=math.atan2(signY*math.sin(relative),signX*math.cos(relative))
    local step=math.floor(localAngle/poseStep+0.5)
    local index=step%64
    local name=index==0 and "default" or "swing_"..index
    ComponentSetValue2(clock,"value_float",frame)
    if ComponentGetValue2(sprite,"rect_animation")~=name then
        ComponentSetValue2(sprite,"rect_animation",name)
        ComponentSetValue2(sprite,"next_rect_animation",name)
        EntityRefreshSprite(gun,sprite)
    end
    -- Preserve the unwrapped sweep angle and put the drill exactly on the drawn axis.
    return x,y,angle+signX*signY*(step*poseStep-localAngle)
end

local function advanceSwing(player,gun,clock,frame)
    local age=frame-swing.start
    if age>swing.duration then swing=nil;return end
    local progress=age/swing.duration
    local angle=swing.aim+swing.side*swing.arc*(2*progress*progress*(3-2*progress)-1)
    local x,y
    x,y,angle=pose(gun,clock,angle,frame)
    local dx,dy=math.cos(angle),math.sin(angle)
    local center=(swing.last+angle)*0.5
    affectArea(player,x,y,math.cos(center),math.sin(center),swing,math.abs(angle-swing.last)*0.5)
    swing.last=angle
    if swing.charge>0 then
        for distance=13,13+18*swing.charge,2 do
            for side=-swing.charge,swing.charge,2 do
                GameCreateParticle("spark_green",x+dx*distance-dy*side,y+dy*distance+dx*side,1,0,0,true,false,false)
            end
        end
        if age%2==0 then
            for segment=1,swing.charge do
                local distance=13+18*(segment-1)
                local sx,sy=x+dx*distance,y+dy*distance
                local drill=EntityLoad(root.."projectiles/staff_blade.xml",sx,sy)
                if drill and drill~=0 then GameShootProjectile(player,sx,sy,sx+dx*18,sy+dy*18,drill,false) end
            end
        end
    end
    if age==swing.duration then swing=nil end
end

local function orb(player,x,y,dx,dy)
    local id=EntityLoad(root.."projectiles/staff_orb.xml",x+dx*6,y+dy*6)
    if not id or id==0 then return false end
    GameShootProjectile(player,x+dx*6,y+dy*6,x+dx*120,y+dy*120,id)
    local shot=EntityGetFirstComponent(id,"ProjectileComponent")
    ComponentSetValue2(shot,"mWhoShot",player)
    local genome=EntityGetFirstComponent(player,"GenomeDataComponent")
    if genome then ComponentSetValue2(shot,"mShooterHerdId",ComponentGetValue2(genome,"herd_id")) end
    ComponentSetValue2(EntityGetFirstComponent(id,"VelocityComponent"),"mVelocity",dx*115,dy*115)
    return true
end

local function pulse(player,x,y,dx,dy)
    local buff=EntityLoad(root.."staff_mana.xml",x,y)
    if not buff or buff==0 then return false end
    EntityAddChild(player,buff)
    affectArea(player,x,y,dx,dy,nil)
    for step=1,48 do
        local angle=step*math.pi/24
        local nx,ny=math.cos(angle),math.sin(angle)
        GameCreateParticle("spark_blue",x+nx*8,y+ny*8,2,nx*200,ny*200,true,true,false)
    end
    GamePlaySound("data/audio/Desktop/explosion.bank","explosions/magic_rocket_small",x,y)
    return true
end

local function mimic(player,x,y,dx,dy)
    local pad=GameGetIsGamepadConnected() and not InputIsMouseButtonDown(1)
    local mx,my=DEBUG_GetMouseWorld()
    local best,score
    local candidates={}
    for _,tag in ipairs({"enemy","nh_reinforcement","noita_hideout_companion","nh_deployed_turret","boss","homing_target"}) do
        for _,id in ipairs(EntityGetInRadiusWithTag(pad and x or mx,pad and y or my,pad and 180 or 14,tag) or {}) do
            if id~=player and not EntityHasTag(id,"polymorphed_player") and not EntityHasTag(id,"player_unit")
                and (tag~="homing_target" or EntityGetFirstComponentIncludingDisabled(id,"GenomeDataComponent")) then candidates[id]=true end
        end
    end
    for id in pairs(candidates) do
        local tx,ty=EntityGetTransform(id)
        local ax,ay=tx-x,ty-y
        local along=ax*dx+ay*dy
        local distance=pad and along or (tx-mx)^2+(ty-my)^2
        if (not pad or (along>0 and math.abs(ax*dy-ay*dx)<=12)) and (not score or distance<=score) then
            local form,substitute=resolveForm(player,id)
            if not score or distance<score or (distance==score and form and (not best.form or (best.substitute and not substitute))) then
                score,best=distance,{x=tx,y=ty,form=form,substitute=substitute,status=form and "ready" or "unsupported"}
            end
        end
    end
    return best
end

function staff.update(player,gun,mag,index,points,frame,blocked,reloading,canMimic)
    local controls=EntityGetFirstComponentIncludingDisabled(player,"ControlsComponent")
    local clock=EntityGetFirstComponentIncludingDisabled(gun,"VariableStorageComponent","nh_staff_clock")
    if not clock or not controls then staff.reset(); return points end
    local down=ComponentGetValue2(controls,"mButtonDownFire")
    local pressed=down and not wasDown
    wasDown=down
    if index~=1 or blocked then swing=nil end
    if blocked and not (index==4 and reloading) then started,level=nil,0; return points end
    local ready=frame>=ComponentGetValue2(clock,"value_int")
    local x,y=EntityGetTransform(player)
    local dx,dy=NHProducts.aim(player,x,y)
    dx,dy=dx or 1,dy or 0
    if index==1 then
        if swing then advanceSwing(player,gun,clock,frame);return points end
        if pressed and ready then started,level=frame,0 end
        if started then
            local spent=math.min(points,math.min(3,math.floor((frame-started)/60))-level)
            if spent>0 then
                points,level=points-spent,level+spent
                ComponentSetValue2(mag,"value_int",points)
            end
            local aim=math.atan2(dy,dx)
            local side=dx<0 and -1 or 1
            local arc=math.rad(48+16*level)
            if down then
                local angle=aim-side*arc
                local handX,handY
                handX,handY,angle=pose(gun,clock,angle,frame)
                if spent>0 then GameCreateParticle("spark_blue",handX+13*math.cos(angle),handY+13*math.sin(angle),6,0,-10,true) end
            else
                local duration=6+2*level
                swing={start=frame,duration=duration,charge=level,side=side,arc=arc,aim=aim,last=aim-side*arc,hit={}}
                GamePlaySound("data/audio/Desktop/animals.bank","animals/spearbot/attack_melee",x,y)
                dragonAttack(player,dx,dy)
                advanceSwing(player,gun,clock,frame)
                started,level=nil,0
                ComponentSetValue2(clock,"value_int",frame+duration+1)
            end
        end
        return points,started and level
    end
    started,level=nil,0
    local mode=NHFirearms.staffModes[index]
    local target=index==4 and mimic(player,x,y,dx,dy) or nil
    if target and target.form then
        if reloading then target.status="reload"
        elseif points<mode.cost then target.status="ammo"
        elseif not ready then target.status="cooldown"
        elseif canMimic and not canMimic(player) then target.status="immune" end
    end
    if index==4 and (not pressed or not target or target.status~="ready" or blocked) then return points,nil,nil,target end
    if not down or not ready or points<mode.cost then return points end
    local ok
    if index==2 then ok=orb(player,x,y,dx,dy)
    elseif index==3 then ok=pulse(player,x,y,dx,dy)
    elseif target then
        local form=target.form
        return points,nil,function(shield,state)
            if NHNative.held(player)~=gun or ComponentGetValue2(mag,"value_int")~=points or not shield.allowMimic(player) then return end
            local prior=ComponentGetValue2(clock,"value_int")
            ComponentSetValue2(mag,"value_int",points-mode.cost)
            ComponentSetValue2(clock,"value_int",frame+60)
            print("[noita_hideout] mimic cast: "..form)
            local effect=LoadGameEffectEntityTo(player,form)
            if (not effect or effect==0) and EntityGetIsAlive(player) then
                ComponentSetValue2(mag,"value_int",points)
                ComponentSetValue2(clock,"value_int",prior)
                shield.sync(state,player)
            elseif effect and effect~=0 and EntityGetIsAlive(effect) then
                local body=EntityGetRootEntity(effect)
                if body and body~=0 and EntityHasTag(body,"polymorphed_player") then staff.guardMimic(body) end
            end
        end,target
    end
    if ok then
        if index==3 then dragonAttack(player,dx,dy) end
        points=points-mode.cost
        ComponentSetValue2(mag,"value_int",points)
        ComponentSetValue2(clock,"value_int",frame+(index==2 and 36 or 60))
    end
    return points
end
return staff
