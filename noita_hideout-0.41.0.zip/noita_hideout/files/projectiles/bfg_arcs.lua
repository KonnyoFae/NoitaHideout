local orb=GetUpdatedEntityID()
local shot=EntityGetFirstComponentIncludingDisabled(orb,"ProjectileComponent")
local shooter=shot and ComponentGetValue2(shot,"mWhoShot")
if not shooter or shooter==0 or not EntityGetIsAlive(shooter) then return end

local x,y=EntityGetTransform(orb)
local count=0
for _,target in ipairs(EntityGetInRadiusWithTag(x,y,56,"homing_target") or {}) do
    if target~=shooter and EntityGetFirstComponentIncludingDisabled(target,"GenomeDataComponent")
        and EntityGetHerdRelation(shooter,target)<40 and GameGetGameEffectCount(target,"CHARM")==0 then
        local tx,ty=EntityGetFirstHitboxCenter(target)
        if tx and not RaytraceSurfaces(x,y,tx,ty) then
            local dx,dy=tx-x,ty-y
            local length=math.max(1,math.sqrt(dx*dx+dy*dy))
            local steps=math.ceil(length/1.5)
            local phase=GameGetFrameNum()+target
            for i=0,steps do
                local t=i/steps
                local bend=2.5*math.sin(math.pi*t)*math.sin(phase+14*t)
                GameCreateCosmeticParticle("spark_green",x+t*dx-bend*dy/length,y+t*dy+bend*dx/length,
                    1,0,0,0,0.06,0.10,true,true,false,false,0,0)
            end
            EntityInflictDamage(target,0.8,"DAMAGE_ELECTRICITY","$nh_hideout_bfg","NONE",0,0,shooter,tx,ty)
            count=count+1
            if count==3 then break end
        end
    end
end
