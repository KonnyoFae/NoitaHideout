-- Native AI aims and fires; assign friendly projectiles to the current player.
-- Resolve the player on every shot so loading a save never retains a stale ID.
function shot(projectile)
    local player=(EntityGetWithTag("player_unit") or {})[1]
    if not player then return end
    local p=EntityGetFirstComponentIncludingDisabled(projectile,"ProjectileComponent")
    local g=EntityGetFirstComponentIncludingDisabled(player,"GenomeDataComponent")
    if p and g then
        ComponentSetValue2(p,"mWhoShot",player)
        ComponentSetValue2(p,"mShooterHerdId",ComponentGetValue2(g,"herd_id"))
    end
    local h=EntityGetFirstComponentIncludingDisabled(projectile,"HomingComponent")
    if h then
        local ai=EntityGetFirstComponentIncludingDisabled(GetUpdatedEntityID(),"AnimalAIComponent")
        local target=ai and ComponentGetValue2(ai,"mGreatestThreat")
        if target and target~=0 and EntityGetIsAlive(target) and EntityGetHerdRelation(player,target)<40
            and GameGetGameEffectCount(target,"CHARM")==0 then
            ComponentSetValue2(h,"predefined_target",target)
        else EntityRemoveComponent(projectile,h) end
    end
end
