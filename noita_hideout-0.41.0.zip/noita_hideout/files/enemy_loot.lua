function death(damage_type,message,responsible,drop_items)
    local mob=GetUpdatedEntityID()
    if drop_items==false or EntityHasTag(mob,"player_unit") or EntityHasTag(mob,"nh_loot_paid") then return end
    EntityAddTag(mob,"nh_loot_paid")
    local x,y=EntityGetTransform(mob)
    local roll=ProceduralRandomi(x+mob,y+GameGetFrameNum(),1,100)
    local kind=roll<=80 and "travel_satchel" or roll<=98 and "travel_pack" or "loot_case"
    EntityLoad("mods/noita_hideout/files/items/"..kind..".xml",x,y-3)
end
