local M={radius=2048,ship={width=160,height=172,anchorX=20,groundY=168,empty=3,replace=4}}
local prefix="cycle_storm.sites."
local keys={rig="rig_locations",well="well_locations",ship="ship_locations"}
local scanKey=prefix.."scan_until"

-- Oil and gas records store their expiry (-1 for idle rigs). Ship records
-- keep the ground anchor after looting so another hull cannot overwrite it.
function M.each(kind,visit)
    for x,y,value in GlobalsGetValue(prefix..keys[kind],""):gmatch("(-?%d+),(-?%d+),(-?%d+)") do
        visit(tonumber(x),tonumber(y),tonumber(value))
    end
end

function M.shipState(x,y)
    local result
    M.each("ship",function(sx,sy,state)
        if sx==x and sy==y then result=state end
    end)
    return result
end

function M.setShip(x,y,newState)
    local entries,found={},false
    M.each("ship",function(sx,sy,state)
        if sx==x and sy==y then found=true; state=newState end
        entries[#entries+1]=string.format("%d,%d,%d",sx,sy,state)
    end)
    if not found then entries[#entries+1]=string.format("%d,%d,%d",x,y,newState) end
    GlobalsSetValue(prefix..keys.ship,table.concat(entries,";"))
end

function M.shipOverlaps(left,top,right,bottom)
    local overlap=false
    M.each("ship",function(x,y)
        local sx,sy=x-M.ship.anchorX,y-M.ship.groundY
        if left<sx+M.ship.width and right>sx and top<sy+M.ship.height and bottom>sy then overlap=true end
    end)
    return overlap
end

function M.nearby(px,py,frame)
    local matches={}
    for _,kind in ipairs({"ship","well","rig"}) do
        local nearest
        local count=0
        M.each(kind,function(x,y,value)
            local usable=kind=="ship" and value<M.ship.empty or kind~="ship" and (value<0 or value>frame)
            local d=(x-px)^2+(y-py)^2
            if usable and d<=M.radius^2 then
                count=count+1
                if not nearest or d<nearest.d then nearest={kind=kind,x=x,y=y,d=d} end
            end
        end)
        if nearest then
            nearest.count=count
            matches[#matches+1]=nearest
        end
    end
    return matches
end

function M.active(frame)
    return (tonumber(GlobalsGetValue(scanKey,"0")) or 0)>frame
end

function M.scan(player,pay,report)
    local frame=GameGetFrameNum()
    if M.active(frame) then report("Radar already active."); return end
    local x,y=EntityGetTransform(player)
    if #M.nearby(x,y,frame)==0 then
        GamePrint(GameTextGetTranslatedOrNot("$nh_storm_scan_empty"))
    elseif pay() then
        GlobalsSetValue(scanKey,tostring(frame+600))
    end
end

return M
