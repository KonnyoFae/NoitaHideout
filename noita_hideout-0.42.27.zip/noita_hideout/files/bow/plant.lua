local arrow=GetUpdatedEntityID()
local shot=EntityGetFirstComponentIncludingDisabled(arrow,"ProjectileComponent")
local data=EntityGetFirstComponentIncludingDisabled(arrow,"VariableStorageComponent","nh_bow_field")
if not shot or not data or ComponentGetValue2(shot,"lifetime")<=0 then return end
local owner=ComponentGetValue2(data,"value_int")
if owner==0 or not EntityGetIsAlive(owner) then return end
local x,y,angle=EntityGetTransform(arrow)
if not x or not DoesWorldExistAt(math.floor(x)-1,math.floor(y)-1,math.ceil(x)+1,math.ceil(y)+1) then return end
local tier=ComponentGetValue2(data,"value_float")
local mode=dofile_once("mods/noita_hideout/files/bow/modes.lua")[3]
local anchor=EntityLoad("mods/noita_hideout/files/bow/anchor.xml",x,y)
if not anchor or anchor==0 then return end
EntitySetTransform(anchor,x,y,angle)
local field=EntityGetFirstComponentIncludingDisabled(anchor,"VariableStorageComponent","nh_bow_field")
ComponentSetValue2(field,"value_int",owner)
ComponentSetValue2(field,"value_float",tier)
local ring=EntityGetFirstComponentIncludingDisabled(anchor,"SpriteComponent","nh_bow_ring")
ComponentSetValue2(ring,"special_scale_x",mode.radius[tier]/32)
ComponentSetValue2(ring,"special_scale_y",mode.radius[tier]/32)
EntityAddComponent2(anchor,"LifetimeComponent",{lifetime=mode.life[tier]})
