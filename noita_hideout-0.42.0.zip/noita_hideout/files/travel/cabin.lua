-- World origin is derived from the dock's horizontal centre and bottom edge.
-- All points below are local pixels measured from the top left of the art.
local C={
    center=260,bottom=-26400,width=192,height=80,
    material="mods/noita_hideout/files/travel/cabin_materials.png",
    background="mods/noita_hideout/files/travel/cabin_background.png",revision="1",
    infirmary={x=38,y=59},terminal={x=100,y=67},gate={x=154,y=56},
}
C.left=C.center-math.floor(C.width/2)
C.top=C.bottom-C.height
function C.point(p) return C.left+p.x,C.top+p.y end
function C.overlaps(left,top,right,bottom,padding)
    local d=padding or 0
    return right>=C.left-d and left<=C.left+C.width+d and bottom>=C.top-d and top<=C.bottom+d
end
function C.inside(x,y)
    return C.overlaps(x,y,x,y,-4)
end
return C
