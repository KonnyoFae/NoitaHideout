-- The supplied four-frame slash is cosmetic. Combat owns its attack token,
-- swept volume and hit list; the fading image never applies extra damage.
local M={}
local file="mods/noita_hideout/files/katana_fx.xml"
local defaultScale={hf_blade=0.5,hf_murasama=0.5,dragon_king=0.75}

local function finite(n)
    return type(n)=="number" and n==n and n~=math.huge and n~=-math.huge
end

function M.spawn(x,y,angle,kind,scale,flip)
    if not finite(x) or not finite(y) or not finite(angle) then return end
    -- All three blades retain the supplied slash art. Gameplay can override
    -- its size to match the exact reach of the attack being displayed.
    scale=scale or defaultScale[kind] or 0.5
    if not finite(scale) or scale<=0 then return end
    scale=math.min(scale,4)
    local entity=EntityLoad(file,x,y)
    if not entity or entity==0 then return end
    local scaleY=(flip and flip<0 and -1 or 1)*scale
    EntitySetTransform(entity,x,y,angle,scale,scaleY)
    EntityApplyTransform(entity,x,y,angle,scale,scaleY)
    return entity
end

return M
