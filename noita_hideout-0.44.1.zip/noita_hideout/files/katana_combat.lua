local root="mods/noita_hideout/files/"
local targets=dofile(root.."field_targets.lua")
local M={}

function M.hostile(player,entity)
    if entity==player or not EntityGetIsAlive(entity) or not EntityHasTag(entity,"enemy")
        or EntityHasTag(entity,"nh_reinforcement") or EntityHasTag(entity,"noita_hideout_companion")
        or EntityHasTag(entity,"nh_deployed_turret") or EntityHasTag(entity,"nh_decoy")
        or EntityGetHerdRelationSafe(player,entity)>=40 or GameGetGameEffectCount(entity,"CHARM")>0 then return false end
    return targets.canAffect(entity,ModIsEnabled("quant.ew"))
end

function M.distanceToSegment(px,py,x1,y1,x2,y2)
    local dx,dy=x2-x1,y2-y1
    local square=dx*dx+dy*dy
    local t=square>0 and math.max(0,math.min(1,((px-x1)*dx+(py-y1)*dy)/square)) or 0
    local x,y=x1+dx*t,y1+dy*t
    return math.sqrt((px-x)^2+(py-y)^2),x,y
end

local function closestSegments(ax,ay,bx,by,cx,cy,dx,dy)
    local rx,ry,sx,sy=bx-ax,by-ay,dx-cx,dy-cy
    local denominator=rx*sy-ry*sx
    if math.abs(denominator)>0.000000001 then
        local qx,qy=cx-ax,cy-ay
        local t,u=(qx*sy-qy*sx)/denominator,(qx*ry-qy*rx)/denominator
        if t>=0 and t<=1 and u>=0 and u<=1 then
            local x,y=ax+t*rx,ay+t*ry
            return 0,x,y,x,y
        end
    end
    local best,px,py,hx,hy,along
    local function consider(distance,x,y,tx,ty)
        local travel=(x-ax)^2+(y-ay)^2
        if not best or distance<best-0.000000001 or (math.abs(distance-best)<0.000000001 and travel<along) then
            best,px,py,hx,hy,along=distance,x,y,tx,ty,travel
        end
    end
    local distance,x,y=M.distanceToSegment(cx,cy,ax,ay,bx,by)
    consider(distance,x,y,cx,cy)
    distance,x,y=M.distanceToSegment(dx,dy,ax,ay,bx,by)
    consider(distance,x,y,dx,dy)
    distance,x,y=M.distanceToSegment(ax,ay,cx,cy,dx,dy)
    consider(distance,ax,ay,x,y)
    distance,x,y=M.distanceToSegment(bx,by,cx,cy,dx,dy)
    consider(distance,bx,by,x,y)
    return best,px,py,hx,hy
end

local function closestHitbox(entity,box,a)
    local ex,ey,rotation,scaleX,scaleY=EntityGetTransform(entity)
    rotation,scaleX,scaleY=rotation or 0,scaleX or 1,scaleY or 1
    local minx,maxx=ComponentGetValue2(box,"aabb_min_x"),ComponentGetValue2(box,"aabb_max_x")
    local miny,maxy=ComponentGetValue2(box,"aabb_min_y"),ComponentGetValue2(box,"aabb_max_y")
    if type(minx)~="number" or type(maxx)~="number" or type(miny)~="number" or type(maxy)~="number" then return end
    local ox,oy=ComponentGetValue2(box,"offset")
    minx,maxx,miny,maxy=minx+(ox or 0),maxx+(ox or 0),miny+(oy or 0),maxy+(oy or 0)
    local cosine,sine=math.cos(rotation),math.sin(rotation)
    local function world(x,y)
        x,y=x*scaleX,y*scaleY
        return {ex+x*cosine-y*sine,ey+x*sine+y*cosine}
    end
    -- If the attack begins inside the target, it already touches its volume.
    if math.abs(scaleX)>0.000000001 and math.abs(scaleY)>0.000000001 then
        local dx,dy=a.x1-ex,a.y1-ey
        local lx,ly=(dx*cosine+dy*sine)/scaleX,(-dx*sine+dy*cosine)/scaleY
        if lx>=minx and lx<=maxx and ly>=miny and ly<=maxy then return 0,a.x1,a.y1,a.x1,a.y1 end
    end
    local corners={world(minx,miny),world(maxx,miny),world(maxx,maxy),world(minx,maxy)}
    local best,px,py,hx,hy,along
    for i=1,4 do
        local from,to=corners[i],corners[i%4+1]
        local distance,x,y,tx,ty=closestSegments(a.x1,a.y1,a.x2,a.y2,from[1],from[2],to[1],to[2])
        local travel=(x-a.x1)^2+(y-a.y1)^2
        if not best or distance<best-0.000000001 or (math.abs(distance-best)<0.000000001 and travel<along) then
            best,px,py,hx,hy,along=distance,x,y,tx,ty,travel
        end
    end
    return best,px,py,hx,hy
end

local function contact(entity,a)
    local boxes=EntityGetComponentIncludingDisabled(entity,"HitboxComponent") or {}
    for _,box in ipairs(boxes) do
        if ComponentGetIsEnabled(box) then
            local distance,px,py,x,y=closestHitbox(entity,box,a)
            if distance and distance<=a.width/2 and not RaytracePlatforms(a.x1,a.y1,px,py)
                and not RaytracePlatforms(px,py,x,y) then return x,y end
        end
    end
    -- Some native enemies (e.g. custom worm bodies) expose no normal hitbox.
    -- An intentionally disabled hitbox is different and must remain unhittable.
    if #boxes==0 then
        local x,y=EntityGetFirstHitboxCenter(entity)
        if not x then x,y=EntityGetTransform(entity) end
        if x then
            local distance,px,py=M.distanceToSegment(x,y,a.x1,a.y1,a.x2,a.y2)
            if distance<=a.width/2 and not RaytracePlatforms(a.x1,a.y1,px,py)
                and not RaytracePlatforms(px,py,x,y) then return x,y end
        end
    end
end

-- The candidate padding covers large/offset bodies; it never widens the blade.
-- Exact contact still uses the requested capsule against each enabled hitbox.
function M.apply(player,a,hit)
    hit=hit or {}
    local mx,my=(a.x1+a.x2)/2,(a.y1+a.y2)/2
    local dx,dy=a.x2-a.x1,a.y2-a.y1
    local length=math.sqrt(dx*dx+dy*dy)
    local handX,handY=a.fxX or a.x1,a.fxY or a.y1
    local bx,by=a.x2-handX,a.y2-handY
    local bladeLength=math.sqrt(bx*bx+by*by)
    local nx,ny=bladeLength>0 and bx/bladeLength or 1,bladeLength>0 and by/bladeLength or 0
    -- x2/y2 is the actual blade tip. The rounded cap extends a radius
    -- beyond its axis, so end the axis slightly before the advertised reach.
    local cap=math.min(a.width/2,bladeLength)
    local shape={x1=a.x1,y1=a.y1,x2=a.x2-nx*cap,y2=a.y2-ny*cap,width=a.width}
    local oldBlade,newBlade
    local travelX,travelY=handX-a.x1,handY-a.y1
    if math.abs(travelX*ny-travelY*nx)>0.001 then
        -- When the floor redirects movement, the blade still points at the
        -- reticle. Include its two poses as well as the connecting sweep.
        oldBlade={x1=a.x1,y1=a.y1,x2=shape.x2-travelX,y2=shape.y2-travelY,width=a.width}
        newBlade={x1=handX,y1=handY,x2=shape.x2,y2=shape.y2,width=a.width}
    end
    local count=0
    for _,id in ipairs(EntityGetInRadius(mx,my,length/2+a.width/2+128) or {}) do
        if not hit[id] and M.hostile(player,id) then
            local dm=EntityGetFirstComponentIncludingDisabled(id,"DamageModelComponent")
            if dm and ComponentGetValue2(dm,"hp")>0 then
                local x,y=contact(id,shape)
                if not x and oldBlade then x,y=contact(id,oldBlade) end
                if not x and newBlade then x,y=contact(id,newBlade) end
                if x then
                    hit[id]=true
                    if a.plunder then dofile_once(root.."katana_rewards.lua").mark(id,player,a.token) end
                    EntityInflictDamage(id,a.damage,"DAMAGE_MELEE",a.token,"NORMAL",nx*45,ny*45,player,x,y,1)
                    count=count+1
                end
            end
        end
    end
    return count,hit
end

local corners={{-3,-6},{0,-6},{3,-6},{-3,-2},{0,-2},{3,-2},{-3,2},{0,2},{3,2}}
local function clearBody(x,y)
    if not DoesWorldExistAt(math.floor(x)-4,math.floor(y)-7,math.ceil(x)+4,math.ceil(y)+3) then return false end
    for dy=-6,2 do if RaytracePlatforms(x-3,y+dy,x+3,y+dy) then return false end end
    -- RaytracePlatforms also sees many physics objects; query the remaining
    -- bodies explicitly so a movable crate cannot be blinked through.
    if PhysicsBodyIDQueryBodies then
        if #(PhysicsBodyIDQueryBodies(x-3,y-6,x+3,y+2,true) or {})>0 then return false end
    end
    return true
end

local function clearStep(x,y,tx,ty)
    if not clearBody(tx,ty) then return false end
    for _,p in ipairs(corners) do
        if RaytracePlatforms(x+p[1],y+p[2],tx+p[1],ty+p[2]) then return false end
    end
    return true
end

-- Third return is the portion of the requested step completed. On level
-- ground a shallow downward lunge can spend it moving along the surface.
function M.safeStep(x,y,dx,dy,distance)
    local moved=0
    while moved<distance do
        local step=math.min(2,distance-moved)
        local tx,ty=x+dx*step,y+dy*step
        if not clearStep(x,y,tx,ty) then
            if dy<=0 or dy>0.35 or not RaytracePlatforms(x,y+1,x,y+4) or not clearStep(x,y,tx,y) then break end
            ty=y
        end
        x,y,moved=tx,ty,moved+step
    end
    return x,y,moved
end
return M
