-- Shared by the controller and isolated entity-script Lua states.
if NHEW then return NHEW end
local M={}
NHEW=M
local enabled,installed,frame,status,owner,lastStatus

function M.reset()
    enabled,installed=nil,nil
    frame,status,owner,lastStatus=nil,nil,nil,nil
end

function M.enabled()
    if enabled==nil then
        installed=ModIsEnabled and ModIsEnabled("quant.ew")
        enabled=installed or
            (GlobalsGetValue and GlobalsGetValue("nh_ew.world_mark","")~="") or false
    end
    return enabled
end

-- Ownership is bound once per local save-slot profile. Two fresh peers can
-- have the same profile number and start on the same second.
function M.bind(profile)
    if not M.enabled() or not installed then return end
    local key="noita_hideout.ew_owner_"..profile
    local id=ModSettingGet(key)
    if id==nil then
        local peer=GlobalsGetValue("nh_ew.local_peer","")
        if peer=="" or not peer:match("^%x+$") then return end
        local y,m,d,h,minute,s=GameGetDateAndTimeLocal()
        local micros=math.floor(GameGetRealWorldTimeSinceStarted()*1000000)%10000000
        local salt=("%d.%d.%d.%d.%d.%d.%d.%d"):format(y,m,d,h,minute,s,micros,profile)
        local hash=5381
        for i=1,#salt do hash=(hash*33+salt:byte(i))%2147483647 end
        id=("p%x%s%x"):format(profile,peer,hash)
        pcall(ModSettingSet,key,id)
        if ModSettingGet(key)~=id then return end
    end
    if type(id)~="string" or #id>40 or not id:match("^%w+$") then return end
    owner=id
    if GlobalsGetValue("nh_ew.issuer","")~=id then GlobalsSetValue("nh_ew.issuer",id) end
    return id
end

function M.issuer()
    return owner or (GlobalsGetValue and GlobalsGetValue("nh_ew.issuer",""):match("^([%w]+)$"))
end

local function session()
    if not M.enabled() or not installed then return end
    local now=GameGetFrameNum()
    if frame~=now then
        frame=now
        local raw=GlobalsGetValue("nh_ew.status","")
        if raw~=lastStatus then
            status,lastStatus=nil,raw
            local world,gold,role,cycle,beat=raw:match("^1|([%w_-]+)|([01])|([hg])|(%d+)|(%d+)$")
            if world and tonumber(cycle)==(tonumber(SessionNumbersGetValue("NEW_GAME_PLUS_COUNT")) or 0)
                and GlobalsGetValue("nh_ew.world_mark","")==world then
                status={world=world,gold=gold=="1",role=role,heartbeat=tonumber(beat)}
            end
        end
        if status and (now<status.heartbeat or now-status.heartbeat>45) then status=nil end
    end
    return status
end

function M.ready() return session()~=nil end
function M.world() local s=session(); return s and s.world end
function M.walletAllowed()
    if not M.enabled() then return true end
    local s=session()
    return s~=nil and not s.gold
end
function M.rescueAllowed() return not M.enabled() end
function M.localBody(entity)
    return entity and entity~=0 and (not M.enabled() or
        (not EntityHasTag(entity,"ew_client") and not EntityHasTag(entity,"ew_notplayer") and not EntityHasTag(entity,"nh_ew_waiting")))
end

-- A receipt is meaningful only in the host world and for the bound owner.
function M.claimItem(key)
    local s=session()
    local issuer=M.issuer()
    if not s or not issuer then return nil end
    local request=s.world.."|"..key
    local result=GlobalsGetValue("nh_ew.item_result."..request,"")
    if result~="" then return result==issuer end
    GlobalsSetValue("nh_ew.item_request",request)
    return nil
end
return M
