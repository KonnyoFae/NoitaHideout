-- Each released collectible has a stable id, its physical entity file, and
-- the complete warehouse item record accepted by that entity's storage codec.
-- Those two representations describe the same reward in combat and at home.
local path="mods/noita_hideout/files/items/"
local function collectible(id,zh,en,noteZh,noteEn,tarot,companion)
    return {id=id,file=path..id..".xml",zh=zh,en=en,noteZh=noteZh,noteEn=noteEn,tarot=tarot,companion=companion,
        item={kind=id,remaining=90,name="$nh_hideout_"..id,icon=path..id..".png"}}
end
return {
    collectible("salvage_bell","打捞钟","Salvage Bell",
        "手持时按射击键（默认左键），将附近战利品袋召到身边。接下来 15 分钟提高击杀掉落。",
        "Fire while held to draw nearby loot bags to you and improve kill drops for 15 minutes.","tarot_moon","cat"),
    collectible("rewind_watch","倒流表","Rewind Watch",
        "手持时按射击键（默认左键）记录状态。30 秒后或受到致命伤时回到原位，恢复记录的生命、法力、弹药和消耗性特质。",
        "Fire while held to set a 30-second anchor. On expiry or lethal damage, return with recorded health, mana, ammo and consumable perks.","tarot_hermit","dryad"),
}
