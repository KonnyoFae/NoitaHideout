-- Installed only while an independent-health EW player has a running watch.
local rescue=dofile_once("mods/noita_hideout/files/rescue.lua")
function damage_about_to_be_received(damage,x,y,responsible,critical)
    rescue.lifePriority(GetUpdatedEntityID(),true,true)
    return damage,critical
end
