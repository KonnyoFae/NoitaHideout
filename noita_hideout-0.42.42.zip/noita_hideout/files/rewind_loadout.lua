-- The watch annotates the actual carried entities. Warehouse records and new
-- pickups never receive these markers. Engine component/entity IDs may change
-- when a save is loaded, so the markers themselves carry the snapshot.
local M={}
local tag="nh_rewind_equipment"
local hook="nh_rewind_throw"
local rigTag="nh_rewind_rig"
local first=EntityGetFirstComponentIncludingDisabled
local get,set=ComponentGetValue2,ComponentSetValue2

local function scope(token)
    return ((NHEW and NHEW.enabled() and NHEW.issuer()) or "solo").."/"..token
end

local function rigKey(s)
    local row=s and s.gearRig
    return row and table.concat({s.profile,s.runSerial,row.id,row.epoch or 0,row.item.kind},"/") or ""
end

local function inspect(entity,kind)
    local item=first(entity,"ItemComponent")
    if not item then return end
    if NHGuns.types[kind] then
        local n=NHGuns.physicalRounds(kind,entity,item)
        if NHStore.validBandageCount(n) then return n end
    elseif NHFirearms.items[kind] and NHFirearms.items[kind].magazine then
        local mag=first(entity,"VariableStorageComponent","nh_magazine")
        if mag and get(mag,"name")==kind then
            NHFirearms.prepareMagazine(entity,mag)
            return get(mag,"value_int")
        end
    elseif kind=="wand" then
        local ability=first(entity,"AbilityComponent")
        if ability then return get(ability,"mana") end
    end
end

local function unpackMark(c)
    local owner,serial,kind,picked,initial=get(c,"value_string"):match("^([^|]+)|(%d+)|(%w[%w_]*)|(-?%d+)|([^|]+)$")
    return owner,serial,kind,tonumber(picked),tonumber(initial)
end

-- Also called by the native throw callback, before the item can be picked up
-- by anyone (including its previous owner).
function M.abandon(entity)
    local mark=first(entity,"VariableStorageComponent",tag)
    if not mark then return end
    local _,_,kind=unpackMark(mark)
    local item=first(entity,"ItemComponent")
    local empty=kind~="wand" and item and get(mark,"value_bool") and get(item,"uses_remaining")==0
    EntityRemoveComponent(entity,mark)
    local callback=first(entity,"LuaComponent",hook)
    if callback then EntityRemoveComponent(entity,callback) end
    EntityRemoveTag(entity,tag)
    if empty then
        local owner=EntityGetRootEntity(entity)
        if owner~=entity and EntityHasTag(owner,"player_unit") then GameKillInventoryItem(owner,entity)
        else EntityKill(entity) end
    end
end

local function available(state,player,id)
    return EntityGetRootEntity(id)==player and not (NHEWItems and NHEWItems.lockInfo(id))
        and NHTransfers.available(state,player,id)
end

function M.capture(state,player,token)
    local rig=state.gearRig
    if rig and not EntityAddComponent2(player,"VariableStorageComponent",{_tags=rigTag,
        name=token,value_string=rigKey(state),value_int=rig.item.reserve}) then return false end
    for i,id in ipairs(NHTransfers.carried(player)) do
        if available(state,player,id) then
            local kind=NHTransfers.item_kind(id)
            local n=inspect(id,kind)
            if n then
                if first(id,"VariableStorageComponent",tag) then M.abandon(id) end
                local picked=get(first(id,"ItemComponent"),"mFramePickedUp") or -1
                local data=table.concat({scope(token),i,kind,picked,("%.17g"):format(n)},"|")
                if not EntityAddComponent2(id,"VariableStorageComponent",{_tags=tag,name=tag,value_string=data,
                    value_int=0,value_bool=NHGuns.types[kind]~=nil}) then return false end
                EntityAddTag(id,tag)
                if not EntityAddComponent2(id,"LuaComponent",{_tags=hook..",enabled_in_world,enabled_in_hand,enabled_in_inventory",
                    script_throw_item="mods/noita_hideout/files/rewind_throw.lua",execute_every_n_frame=-1}) then return false end
            end
        end
    end
    return true
end

local function current(player,id,token)
    local mark=first(id,"VariableStorageComponent",tag)
    if not mark or EntityGetRootEntity(id)~=player then return end
    local owner,serial,kind,picked,initial=unpackMark(mark)
    local item=first(id,"ItemComponent")
    if owner==scope(token) and item and picked==(get(item,"mFramePickedUp") or -1)
        and not (NHEWItems and NHEWItems.lockInfo(id)) then return mark,serial,kind,initial end
end

local function activeMark(player,id)
    if not EntityHasTag(id,tag) or not EntityHasTag(player,"nh_rewind_armed") then return end
    local watch=first(player,"VariableStorageComponent","nh_rewind_snapshot")
    if watch then return current(player,id,get(watch,"name")) end
end

-- Called only after a projectile has actually been allocated and paid for.
-- Record just the shots attributable to the original stack. A later merge
-- keeps its added rounds and cannot expand this allowance.
function M.spentRound(player,id)
    local mark,_,_,limit=activeMark(player,id)
    if mark and get(mark,"value_bool") then
        set(mark,"value_int",math.min(limit,get(mark,"value_int")+1))
        return true
    end
end

function M.reloaded(state,player,id,amount)
    local mark=activeMark(player,id)
    if not mark then return end
    local rig=first(player,"VariableStorageComponent",rigTag)
    if rig and get(rig,"value_string")==rigKey(state) then
        set(mark,"value_int",math.min(get(rig,"value_int"),get(mark,"value_int")+amount))
    end
end

function M.cancel(player,token)
    local owner=scope(token)
    for _,id in ipairs(EntityGetWithTag(tag) or {}) do
        local mark=first(id,"VariableStorageComponent",tag)
        if mark and unpackMark(mark)==owner then M.abandon(id) end
    end
    local rig=first(player,"VariableStorageComponent",rigTag)
    if rig and get(rig,"name")==token then EntityRemoveComponent(player,rig) end
end

function M.restore(state,player,token,commit)
    local matches,seen={},{}
    for _,id in ipairs(NHTransfers.carried(player)) do
        local mark,serial,kind,initial=current(player,id,token)
        if mark and available(state,player,id) and NHTransfers.item_kind(id)==kind then
            -- An externally cloned marker cannot redeem the same slot twice.
            matches[serial]=not seen[serial] and {id=id,mark=mark,kind=kind,initial=initial} or nil
            seen[serial]=true
        end
    end
    local credit=0
    for _,slot in pairs(matches) do
        if NHFirearms.items[slot.kind] and NHFirearms.items[slot.kind].magazine then
            credit=credit+get(slot.mark,"value_int")
        end
    end
    local rig=first(player,"VariableStorageComponent",rigTag)
    local frame=tonumber(token:match("/(%d+)$"))
    if credit>0 and rig and frame and get(rig,"name")==token and get(rig,"value_string")==rigKey(state) then
        local function alreadyPaid(s)
            return s.gearRig.rewindRun==s.runSerial and (s.gearRig.rewindFrame or -1)>=frame
        end
        local function balance(s)
            local n=s.gearRig.item.reserve
            return math.max(n,math.min(get(rig,"value_int"),n+credit))
        end
        if not alreadyPaid(state) then
            if not commit(function(draft)
                if rigKey(draft)~=get(rig,"value_string") then return false,"Inventory slot changed." end
                if not alreadyPaid(draft) then
                    draft.gearRig.item.reserve=balance(draft)
                    draft.gearRig.rewindRun,draft.gearRig.rewindFrame=draft.runSerial,frame
                end
                return true
            end) then return false end
        end
    end
    for _,slot in pairs(matches) do
        local id,kind=slot.id,slot.kind
        if NHGuns.types[kind] then
            local item=first(id,"ItemComponent")
            local now=get(item,"uses_remaining")
            if now>=0 then set(item,"uses_remaining",math.min(2147483647,now+get(slot.mark,"value_int"))) end
        elseif kind=="wand" then
            local ability=first(id,"AbilityComponent")
            if ability then set(ability,"mana",math.min(slot.initial,get(ability,"mana_max"))) end
        else
            local mag=first(id,"VariableStorageComponent","nh_magazine")
            if mag and get(mag,"name")==kind then
                set(mag,"value_int",slot.initial)
                local ability=first(id,"AbilityComponent")
                if ability then set(ability,"mana",slot.initial) end
            end
        end
        -- Retire each successful physical delivery before touching the next
        -- slot. A later failure cannot refund the first launcher twice.
        M.abandon(id)
    end
    M.cancel(player,token)
    return true
end
return M
