-- The snapshot lives on the original body. Both the damage callback and EW's
-- local health module can fire it before their respective death handlers run.
local W={}
local root="mods/noita_hideout/files/"
local ew=NHEW or dofile(root.."ew.lua")
local armed="nh_rewind_armed"
local recordTag="nh_rewind_snapshot"
local nativeLife="nh_rewind_native_life"
local clockKey="nh_rewind.clock"
local returnKey="nh_rewind.return"
local inventory,rescueModule
local seenPlayer,seenProfile,seenRun,hasRecord
local function remember(state,player,present)
    seenPlayer,seenProfile,seenRun,hasRecord=player,state.profile,state.runSerial,present
end
local function rescue()
    if not rescueModule then rescueModule=dofile(root.."rescue.lua") end
    return rescueModule
end
local function loadout()
    if not inventory then inventory=dofile(root.."rewind_loadout.lua") end
    return inventory
end
local function record(player)
    return EntityGetFirstComponentIncludingDisabled(player,"VariableStorageComponent",recordTag)
end
local function healthMode()
    return ew.enabled() and GlobalsGetValue("nh_ew.rewind_health","") or "local_health"
end
local function run(state)
    return tostring(state.profile).."/"..tostring(state.runSerial).."/"
end
local function lives(player,action)
    local owners={player}
    for _,child in ipairs(EntityGetAllChildren(player) or {}) do owners[#owners+1]=child end
    for _,owner in ipairs(owners) do
        -- perk.lua loads the native GameEffect and creates its HUD icon on a
        -- separate child. On reload the filename can become that of the player;
        -- the component tags still identify the exact effects captured earlier.
        local fresh="data/ui_gfx/perk_icons/respawn.png"
        if action~="capture" then
            for _,effect in ipairs(EntityGetComponentIncludingDisabled(owner,"GameEffectComponent",nativeLife) or {}) do
                if action=="restore" then
                    ComponentSetValue2(effect,"mIsSpent",false)
                    ComponentSetValue2(effect,"effect","RESPAWN")
                end
                ComponentRemoveTag(effect,nativeLife)
            end
            for _,icon in ipairs(EntityGetComponentIncludingDisabled(owner,"UIIconComponent",nativeLife) or {}) do
                if action=="restore" then ComponentSetValue2(icon,"icon_sprite_file",fresh) end
                ComponentRemoveTag(icon,nativeLife)
            end
        else
            local path=EntityGetFilename(owner)
            if path=="data/entities/misc/effect_respawn.xml" then
                for _,effect in ipairs(EntityGetComponentIncludingDisabled(owner,"GameEffectComponent") or {}) do
                    if ComponentGetValue2(effect,"effect")=="RESPAWN" and ComponentGetValue2(effect,"frames")==-1
                        and not ComponentGetValue2(effect,"mIsSpent")
                        and (ComponentGetIsEnabled(effect) or ComponentHasTag(effect,"nh_rescue_paused_life")) then
                        ComponentAddTag(effect,nativeLife)
                    end
                end
            end
            if not EntityHasTag(owner,"nh_tarot_life") and path~=root.."tarot_life.xml" then
                for _,icon in ipairs(EntityGetComponentIncludingDisabled(owner,"UIIconComponent") or {}) do
                    if ComponentGetValue2(icon,"name")=="$perk_respawn" and ComponentGetValue2(icon,"icon_sprite_file")==fresh then
                        ComponentAddTag(icon,nativeLife)
                    end
                end
            end
        end
    end
end
local function clearClock(token)
    if GlobalsGetValue(clockKey,"")==token then GlobalsSetValue(clockKey,"") end
    if GlobalsGetValue(returnKey,"")==token then GlobalsSetValue(returnKey,"") end
end
local function releasePriority(player)
    local meter=EntityGetFirstComponentIncludingDisabled(player,"VariableStorageComponent","nh_rescue")
    if meter and ComponentHasTag(meter,"nh_rewind_rescue") then ComponentRemoveTag(meter,"nh_rewind_rescue") end
    local hook=EntityGetFirstComponentIncludingDisabled(player,"LuaComponent","nh_rewind_ew_priority")
    if hook then EntityRemoveComponent(player,hook) end
    if ew.enabled() then rescue().lifePriority(player,false) end
end
function W.remaining(player)
    if not player or not EntityHasTag(player,armed) then return 0 end
    local snap=record(player)
    return snap and math.max(0,ComponentGetValue2(snap,"value_int")-GameGetFrameNum()) or 0
end
function W.start(state,player)
    local mode=healthMode()
    if mode=="shared_health" then return false,"Shared health cannot be rewound." end
    if mode~="local_health" or not ew.localBody(player) or (ew.enabled() and not ew.ready())
        or EntityHasTag(player,"polymorphed_player") then return false,"Rewind unavailable." end
    if record(player) then return false,"Rewind already active." end
    local pending=EntityGetFirstComponentIncludingDisabled(player,"VariableStorageComponent","nh_rescue")
    if pending and ComponentGetValue2(pending,"value_string")~="" then return false,"Rewind unavailable." end
    local now=GameGetFrameNum()
    local token=run(state)..tostring(now)
    if GlobalsGetValue("nh_rewind.last","")==token then return false,"Rewind already active." end
    local dm=EntityGetFirstComponentIncludingDisabled(player,"DamageModelComponent")
    local hp=dm and ComponentGetValue2(dm,"hp")
    local x,y=EntityGetTransform(player)
    if not hp or hp<=0 or not x or not y then return false,"Rewind unavailable." end
    local snap=EntityAddComponent2(player,"VariableStorageComponent",{_tags=recordTag,name=token,
        value_float=hp,value_int=now+1800,value_string=("%.12g:%.12g"):format(x,y),value_bool=false})
    if not snap then return false,"Rewind unavailable." end
    if not loadout().capture(state,player,token) then
        loadout().cancel(player,token)
        EntityRemoveComponent(player,snap)
        return false,"Rewind unavailable."
    end
    lives(player,"capture")
    GlobalsSetValue(clockKey,token)
    GlobalsSetValue("nh_rewind.last",token)
    EntityAddTag(player,armed)
    remember(state,player,true)
    if ew.enabled() then
        -- Only an armed watch needs to reserve newly acquired lives under EW.
        EntityAddComponent2(player,"LuaComponent",{_tags="nh_rewind_ew_priority",execute_every_n_frame=-1,
            script_damage_about_to_be_received=root.."rewind_watch_priority.lua"})
    end
    -- Reserve the engine's death flag immediately, including same-frame hits.
    rescue().arm(state,player,true)
    return true
end
local function move(player,x,y)
    EntitySetTransform(player,x,y)
    local motion=EntityGetFirstComponentIncludingDisabled(player,"CharacterDataComponent")
    if motion then ComponentSetValue2(motion,"mVelocity",0,0) end
end
local function loaded(x,y)
    return DoesWorldExistAt(math.floor(x)-4,math.floor(y)-7,math.ceil(x)+4,math.ceil(y)+2)
end
local function clear(x,y)
    for dy=-6,2,2 do
        if RaytracePlatforms(x-3,y+dy,x+3,y+dy) then return false end
    end
    return true
end
local offsets={{0,-1},{-1,0},{1,0},{0,1},{-1,-1},{1,-1},{-1,1},{1,1}}
local function landing(x,y,fromX,fromY)
    if clear(x,y) then return x,y end
    for radius=8,96,8 do
        for _,offset in ipairs(offsets) do
            local tx,ty=x+radius*offset[1],y+radius*offset[2]
            if loaded(tx,ty) and clear(tx,ty) then return tx,ty end
        end
    end
    -- All nearby space became solid. Keep the departure point as a fallback.
    return fromX,fromY
end
local function sampleTrail(player,snap)
    local x,y=EntityGetTransform(player)
    local point=("%.0f:%.0f"):format(x,y)
    local saved=ComponentGetValue2(snap,"value_string")
    if saved:match("([^|]+)$")==point then return end
    local origin=saved:match("^[^|]+")
    local trail={}
    for sample in saved:gmatch("|([^|]+)") do trail[#trail+1]=sample end
    if #trail==4 then table.remove(trail,1) end
    trail[#trail+1]=point
    ComponentSetValue2(snap,"value_string",origin.."|"..table.concat(trail,"|"))
end
local function fire(player,dm,snap)
    if ComponentGetValue2(snap,"value_bool") or healthMode()~="local_health" then return false end
    local saved=ComponentGetValue2(snap,"value_string")
    local x,y=saved:match("^([^:]+):([^:|]+)")
    x,y=tonumber(x),tonumber(y)
    if not x or not y then return false end
    local fx,fy=EntityGetTransform(player)
    local token=ComponentGetValue2(snap,"name")
    ComponentSetValue2(snap,"value_bool",true)
    EntityRemoveTag(player,armed)
    clearClock(token)
    ComponentSetValue2(dm,"hp",math.min(ComponentGetValue2(dm,"max_hp"),ComponentGetValue2(snap,"value_float")))
    ComponentSetValue2(dm,"kill_now",false)
    lives(player,"restore")
    releasePriority(player)
    for tx,ty in saved:gmatch("|([^:|]+):([^:|]+)") do
        EntityLoad(root.."rewind_watch_echo.xml",tonumber(tx),tonumber(ty))
    end
    EntityLoad(root.."rewind_watch_echo.xml",fx,fy)
    if loaded(x,y) then x,y=landing(x,y,fx,fy)
    else
        -- Moving the local player streams the destination. Check the saved
        -- space once its pixels actually exist, including across save/continue.
        ComponentSetValue2(snap,"value_string",("%.12g:%.12g:%.12g:%.12g"):format(x,y,fx,fy))
        ComponentSetValue2(snap,"value_int",GameGetFrameNum()+120)
        ComponentAddTag(snap,"nh_rewind_landing")
    end
    move(player,x,y)
    EntityLoad(root.."rewind_watch_echo.xml",x,y)
    GamePlaySound("data/audio/Desktop/misc.bank","misc/teleport_use",x,y)
    local grace=EntityLoad(root.."travel/transit_protection.xml",x,y)
    if grace and grace~=0 then EntityAddChild(player,grace) end
    return true
end
function W.intercept(player,dm)
    if not dm or not EntityHasTag(player,armed) or ComponentGetValue2(dm,"hp")>0 then return false end
    local snap=record(player)
    return snap and fire(player,dm,snap) or false
end
function W.update(state,player,commit)
    if not player or (seenPlayer==player and seenProfile==state.profile and seenRun==state.runSerial and hasRecord==false) then return end
    if not ew.localBody(player) then return end
    local snap=record(player)
    if not snap then
        local stale=GlobalsGetValue(clockKey,"")
        if stale~="" then clearClock(stale) end
        remember(state,player,false)
        return
    end
    local token=ComponentGetValue2(snap,"name")
    local mode=healthMode()
    local prefix=run(state)
    if token:sub(1,#prefix)~=prefix or mode=="shared_health" then
        clearClock(token)
        lives(player,"cancel")
        loadout().cancel(player,token)
        EntityRemoveTag(player,armed)
        EntityRemoveComponent(player,snap)
        releasePriority(player)
        remember(state,player,false)
        return
    end
    if mode~="local_health" then return end
    if not ComponentGetValue2(snap,"value_bool") then
        local now=GameGetFrameNum()
        if now<ComponentGetValue2(snap,"value_int") and GlobalsGetValue(returnKey,"")~=token then
            if now%12==0 then sampleTrail(player,snap) end
            return
        end
        local dm=EntityGetFirstComponentIncludingDisabled(player,"DamageModelComponent")
        if not dm or not fire(player,dm,snap) then return end
    end
    if ComponentHasTag(snap,"nh_rewind_landing") then
        local x,y,fx,fy=ComponentGetValue2(snap,"value_string"):match("^([^:]+):([^:]+):([^:]+):([^:]+)$")
        x,y,fx,fy=tonumber(x),tonumber(y),tonumber(fx),tonumber(fy)
        local px,py=EntityGetTransform(player)
        if math.abs(px-x)<=12 and math.abs(py-y)<=12 then
            if loaded(x,y) then
                local tx,ty=landing(x,y,fx,fy)
                if tx~=x or ty~=y then move(player,tx,ty) end
            elseif GameGetFrameNum()<ComponentGetValue2(snap,"value_int") then return
            elseif loaded(fx,fy) and clear(fx,fy) then move(player,fx,fy) end
        end
        ComponentRemoveTag(snap,"nh_rewind_landing")
    end
    if loadout().restore(state,player,token,commit) then
        EntityRemoveComponent(player,snap)
        remember(state,player,false)
    end
end
-- Noita serializes the real player during polymorph. Expiring the original
-- transformation restores that exact body with the snapshot and marked gear.
function W.polymorph(body,state)
    local token=GlobalsGetValue(clockKey,"")
    if token=="" or (state and token:sub(1,#run(state))~=run(state)) or healthMode()~="local_health"
        or not ew.localBody(body) then return false end
    local dm=EntityGetFirstComponentIncludingDisabled(body,"DamageModelComponent")
    local effect
    for _,kind in ipairs({"POLYMORPH","POLYMORPH_RANDOM","POLYMORPH_UNSTABLE","POLYMORPH_CESSATION"}) do
        local candidate=GameGetGameEffect(body,kind)
        if candidate and candidate~=0 then effect=candidate; break end
    end
    if not effect then return false end
    if dm and not ComponentGetValue2(dm,"wait_for_kill_flag_on_death") then ComponentSetValue2(dm,"wait_for_kill_flag_on_death",true) end
    local activation=tonumber(token:match("/(%d+)$"))
    local fatal=dm and ComponentGetValue2(dm,"hp")<=0
    if fatal or (activation and GameGetFrameNum()>=activation+1800) or GlobalsGetValue(returnKey,"")==token then
        GlobalsSetValue(returnKey,token)
        if fatal then ComponentSetValue2(dm,"hp",ComponentGetValue2(dm,"max_hp")) end
        ComponentSetValue2(effect,"frames",1)
    end
    return true
end
return W
